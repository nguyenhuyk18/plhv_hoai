﻿<?php
 /*
 if($_GET['Ten']==''){
	 echo"<script>
	window.location.href='index.php';
    </script>";
	
 }
	
	*/			ob_start();
	if(isset($_GET['Ten'])&&isset($_GET['huydon'])){
	include("Controller/cSP.php");
	$p=new cSP();
	$p->huydh();
	echo header("refresh:0,url='home.php?Ten=".$_GET['Ten']."&&xemdh'");
}
elseif(isset($_GET['Ten'])&&isset($_GET['danhan'])){
	include("Controller/cSP.php");
	$p=new cSP();
	$p->trangthaidanhan();
	echo header("refresh:0,url='home.php?Ten=".$_GET['Ten']."&&xemdh'");
}
elseif(isset($_GET['Ten'])&&isset($_GET['TenDT'])&&isset($_GET['gui'])){
	include("Controller/cTK(BH).php");
	$p=new cTKBH();
	
if(mysql_num_rows($p->che())==0){
	$p->tbl();
}
else{
	$p->updg();
}
	
	
	echo header("refresh:0,url='home.php?Ten=".$_GET['Ten']."&&TenDT=".$_GET['TenDT']."&&Soluong=".$_GET['Soluong']."&&anh=".$_GET['anh']."&&a=".$_GET['a']."'&&dgia'");
	
}
elseif(isset($_GET['tym'])){
	include("Controller/cTK(BH).php");
	$p=new cTKBH();
	$p->tym();
	echo header("refresh:0,url='home.php?chitiet&&Ten=".$_GET['Ten']."&&id=".$_GET['id']."#bl'");
	
}

				
session_start();
if(isset($_POST['cntt'])){
$a=$_POST['a'];
$_SESSION['t']=$a;
}	
function ChuyenSangTiengVietKhongDau($str)
{
$str = preg_replace("/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|� �|ặ|ẳ|ẵ)/", 'a', $str);
$str = preg_replace("/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/", 'e', $str);
$str = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $str);
$str = preg_replace("/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|� �|ợ|ở|ỡ)/", 'o', $str);
$str = preg_replace("/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/", 'u', $str);
$str = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $str);
$str = preg_replace("/(đ)/", 'd', $str);
$str = preg_replace("/(À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|� �|Ặ|Ẳ|Ẵ)/", 'A', $str);
$str = preg_replace("/(È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ)/", 'E', $str);
$str = preg_replace("/(Ì|Í|Ị|Ỉ|Ĩ)/", 'I', $str);
$str = preg_replace("/(Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|� �|Ợ|Ở|Ỡ)/", 'O', $str);
$str = preg_replace("/(Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ)/", 'U', $str);
$str = preg_replace("/(Ỳ|Ý|Ỵ|Ỷ|Ỹ)/", 'Y', $str);
$str = preg_replace("/(Đ)/", 'Đ', $str);
$str = preg_replace("/( )/", '%20', $str);
return $str;
}
					
					if(isset($_POST['cntt'])){
						$f=$_POST['f'];
						if($f==null){
							echo "<script>alert('Chưa chọn ảnh!')</script>";
						}
						else{
							include_once("Controller/cTK(KH).php");
							$p=new cTK();
							$p->Suatt();
							$t=$_SESSION['t'];
							$b=ChuyenSangTiengVietKhongDau($t);
							echo "<script>alert('Chỉnh sửa thành công')</script>";
							echo header("refresh:0,url='home.php?Ten=$b&&Info");
							
						}
					}
					ob_end_flush();
				?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script type="text/javascript" src="js/jquery.zoom.min.js"></script>
<!–[if lt IE 9]> <script src=”http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js”></script><![endif]–>

<script src="https://unpkg.com/js-image-zoom@0.4.1/js-image-zoom.js" type="application/javascript"></script>
<title>VIPU-Shop mỹ phẩm chính hãng</title>
 
<style>
.footer{
	background-color:#CCF;
	border-width:1px !important;
	border-color: #000 !important;
}
a:link{
	color: black;
}
input:disabled{
    background-color:#FFC;
}
.hinh-1{
	margin-top: 5px;
}
nb{
	color:#C30;
	font-size:18px;
}
rt{
	color:#C9C;
}
xy{
	color:#060;
	font-size:18px;
}
ts{
	color:#F93;
	font-size:18px;
}
ci{
	font-size:17px;
}
dn{
	color:#FFF;
}
xe{
	color:#FFC;
}
eff{
	color:#99F;
	font-size:22px;
}
eee{
	color:#C9C;
	font-size:18px;
}
sao{
	color:#F00;
	font-size:20px;
}
nm{
	color:#F60;
}
ph{
	color:#F63;
}
tnbl{
	color:#F36;
}
blu{
	color:#C99;
	font-size:20px;
	font-weight:50;
}
mota{
	color:#C9C;
	font-weight:200;
}
db{
	color:#96C;
	font-size:18px;
}
bd{
	color:#F00;
	font-size:20px;
	font-weight:100;
}
hs{
	color:#C99;
	font-size:25px;
}
tt{
	color: black;
	font-family:Arial, Helvetica, sans-serif;
}
te{
	color:#F63;
}
 img {
  image-rendering: pixelated;
  position:relative;
}
ac{
	color:#C96;
	font-size:18px;
}
tk{
	color:#360;
	font-size:16px;
}
tki{
	color:#066;
	font-size:18px;
}
bl{
	color:#F63;
	font-size:25px;
}
tko{
	color:#F00;
	font-size:16px;
}
mi{
	color:#99F;
	font-size:18px;
}
xh{
	color:#F60;
}
vi{
	color:#F60;
	font-size:18px;
}
stf{
	color:#C9C;
	
}
nx{
	color:#F93;
}
ncc{
	color:#F36;
	font-size:18px;
}
tde{
	color:#F60;
	font-size:16px;
}
ht{
	color:#F66;
	font-size:16px;
}
tv{
	color:#F90;
	font-width:500;
}
h3{
	color: #F33;
	font-family:cursive;
}
h4{
	font-family:"Comic Sans MS", cursive;
	color:#FC0;
}
nvm{
	color:#F60;
	font-size:500;
}
#show{
	height:600px;
	width:600px;
	top:-30px;
	left:-5px;
	background-repeat:no-repeat;
	background-size:cover;
}
#tbl{
	top:auto;
	right:-20px;
	width:450px;<?php // 320px,auto?>
}
.rounded-circle{
	background-color:#9C0;
}
th{
	background-color: #FCF;
	font-size:16px;
}
hti{
	color:#C99;
	font-size:25px;
}

xa{
	color:#0C0;
}

sa{
	color:#F00;
}
r{
	color:#FFF;
}

l{
	color:#F03;
}

ma{
	color:#F6C;
}

n{
	color:#9F0;
}

p{
	color:#9C3;
}
hh{
	color:#F33;
	font-size:25px;
}
kf{
	color:#000;
}

va{
	color:#C9C;
}
ru{
	color:#093;
}

ta{
	color: #C69;
}
z{
	color:#3C0;
}
rh{
	color:#F60;
	font-size:20px;
}
kh{
	color:#CF3;
}
kx{
	color:#F93;
	font-size:25px;
}
tx{
	color:#C99;
}
a:link{
	color:#000;
}
rf{
	color: #000;
}
li{
	list-style-type:none;
	text-decoration:none;
}
.header{
	  padding: 10px 16px;
}
.content {
  padding: 16px;
}
.sticky {
  position:fixed;
  top: 0px;
  padding-top:15px;
  left:152px;
  width:100%;
  height:100px;
  z-index:8;
  background-color:rgba(255,255,255,0.92);
  box-shadow:0.1px 0.1px 0.1px yellow;
}
#to {
  overflow: hidden;
  display: inline-block;
}
m{
	color:#096;
	font-size:17px;
}
ng{
	color:#F63;
}
dc{
	font-family:"Comic Sans MS", cursive;
	font-size:25px;
	color:#F63;
}
#to img {
  transition: 0.8s;
}
#to:hover img {
  transform: scale(1.2, 1.2);
}
#lendau{
	background:#FFF;
	background-size:cover;
	border-radius:50%;
	height:30px;
	display:flex;
	align-items:center;
	position:fixed;
	bottom:40px; <?php //5px ?>
	width:20px;
	left:1280px;
}
.hotline-phone-ring-wrap {
  position: fixed;
  bottom: 0;
  left: 0;
  z-index: 999999;
}
.hotline-phone-ring {
  position: relative;
  visibility: visible;
  background-color: transparent;
  width: 110px;
  height: 110px;
  cursor: pointer;
  z-index: 11;
  -webkit-backface-visibility: hidden;
  -webkit-transform: translateZ(0);
  transition: visibility .5s;
  left: 0;
  bottom: 0;
  display: block;
}
.hotline-phone-ring-circle {
  width: 85px;
  height: 85px;
  top: 12.75px;
  left: 153px;
  position: absolute;
  background-color:#CF6;
  border-radius: 100%;
  border: 2px solid #FF3;
  -webkit-animation: phonering-alo-circle-anim 1.2s infinite ease-in-out;
  animation: phonering-alo-circle-anim 1.2s infinite ease-in-out;
  transition: all .5s;
  -webkit-transform-origin: 50% 50%;
  -ms-transform-origin: 50% 50%;
  transform-origin: 50% 50%;
  opacity: 0.5;
}
.hotline-phone-ring-circle-fill {
  width: 55px;
  height: 55px;
  top: 28.1px;
  background-color:#9F0;
  left: 169.8px;
  position: absolute;
  background-color:#9F0;
  border-radius: 100%;
  border: 2px solid transparent;
  -webkit-animation: phonering-alo-circle-fill-anim 2.3s infinite ease-in-out;
  animation: phonering-alo-circle-fill-anim 2.3s infinite ease-in-out;
  transition: all .5s;
  -webkit-transform-origin: 50% 50%;
  -ms-transform-origin: 50% 50%;
  transform-origin: 50% 50%;
}
.hotline-phone-ring-img-circle {
  background-color:#6F0;
  width: 33px;
  height: 33px;
  top: 39px;
  left: 181px;
  position: absolute;
  background-size: 20px;
  border-radius: 100%;
  border: 2px solid transparent;
  -webkit-animation: phonering-alo-circle-img-anim 1s infinite ease-in-out;
  animation: phonering-alo-circle-img-anim 1s infinite ease-in-out;
  -webkit-transform-origin: 50% 50%;
  -ms-transform-origin: 50% 50%;
  transform-origin: 50% 50%;
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  align-items: center;
  justify-content: center;
}
.hotline-phone-ring-img-circle .pps-btn-img {
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  
}
.hotline-phone-ring-img-circle .pps-btn-img img {
	width: 20px;
	height: 20px;
}
.hotline-bar {
	display: none;
  position: absolute;
  background:#FC0;
  height: 40px;
  width: 180px;
  line-height: 40px;
  border-radius: 3px;
  padding: 0 10px;
  background-size: 100%;
  cursor: pointer;
  transition: all 0.8s;
  -webkit-transition: all 0.8s;
  z-index: 9;
  box-shadow: 0 14px 28px rgba(0, 0, 0, 0.25);
  border-radius: 20px !important;
  /* width: 175px !important; */
  left: 170px;
  bottom: 37px;
}
.hotline-bar > a {
  color: #fff;
  text-decoration: none;
  font-size: 15px;
  font-weight: bold;
  text-indent: 50px;
  display: block;
  letter-spacing: 1px;
  line-height: 40px;
  font-family: Arial;
}
.hotline-bar > a:hover,
.hotline-bar > a:active {
  color:#fff;
}
@-webkit-keyframes phonering-alo-circle-anim {
  0% {
    -webkit-transform: rotate(0) scale(0.5) skew(1deg);
    -webkit-opacity: 0.1;
  }
  30% {
    -webkit-transform: rotate(0) scale(0.7) skew(1deg);
    -webkit-opacity: 0.5;
  }
  100% {
    -webkit-transform: rotate(0) scale(1) skew(1deg);
    -webkit-opacity: 0.1;
  }
}
@-webkit-keyframes phonering-alo-circle-fill-anim {
  0% {
    -webkit-transform: rotate(0) scale(0.7) skew(1deg);
    opacity: 0.6;
  }
  50% {
    -webkit-transform: rotate(0) scale(1) skew(1deg);
    opacity: 0.6;
  }
  100% {
    -webkit-transform: rotate(0) scale(0.7) skew(1deg);
    opacity: 0.6;
  }
}
@-webkit-keyframes phonering-alo-circle-img-anim {
  0% {
    -webkit-transform: rotate(0) scale(1) skew(1deg);
  }
  10% {
    -webkit-transform: rotate(-25deg) scale(1) skew(1deg);
  }
  20% {
    -webkit-transform: rotate(25deg) scale(1) skew(1deg);
  }
  30% {
    -webkit-transform: rotate(-25deg) scale(1) skew(1deg);
  }
  40% {
    -webkit-transform: rotate(25deg) scale(1) skew(1deg);
  }
  50% {
    -webkit-transform: rotate(0) scale(1) skew(1deg);
  }
  100% {
    -webkit-transform: rotate(0) scale(1) skew(1deg);
  }
}
@media (max-width: 1000px) {

  .hotline-bar {
    display: none;
  }
}
.fb-livechat, .fb-widget{
	display: none;
}
.ctrlq.fb-button, .ctrlq.fb-close{
position: fixed; 
right: 24px; 
cursor: pointer;
}
.ctrlq.fb-button{
z-index: 999; 
background: url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQcddrlRtRMOdXpF_tFsgGZ865fHNWUjYj4-v5ke7SLRn4p7JJUHXaJJHnsPwI2JiVAVEQ&usqp=CAU') 
center no-repeat #fff; 
top:550px;
width: 60px; 
height: 60px; 
left:1427px;
text-align: center; 
bottom: 30px; 
border: 0; 
outline: 0; 
border-radius: 60px; 
-webkit-border-radius: 60px; 
-moz-border-radius: 60px; 
-ms-border-radius: 60px; 
-o-border-radius: 60px; 
box-shadow: 0 1px 6px rgba(0, 0, 0, .06), 0 2px 32px rgba(0, 0, 0, .16); 
-webkit-transition: box-shadow .2s ease; 
background-size: 80%; 
transition: all .2s ease-in-out;
}
.ctrlq.fb-button:focus, .ctrlq.fb-button:hover{
transform: scale(1.1); 
box-shadow: 0 2px 8px rgba(0, 0, 0, .09), 0 4px 40px rgba(0, 0, 0, .24) #FF6;
}
.fb-widget{
background: #fff;
z-index: 1000; 
position: fixed;
width: 360px; 
height: 435px; 
overflow: hidden; 
opacity: 0; 
bottom: 0; 
right: 24px; 
border-radius: 6px; 
-o-border-radius: 6px;
-webkit-border-radius: 6px; 
box-shadow: 0 5px 40px rgba(0, 0, 0, .16); 
-webkit-box-shadow: 0 5px 40px rgba(0, 0, 0, .16); 
-moz-box-shadow: 0 5px 40px rgba(0, 0, 0, .16); 
-o-box-shadow: 0 5px 40px rgba(0, 0, 0, .16)
}
.fb-credit{
text-align: center; 
margin-top: 8px
}

.fb-credit a{
transition: none; 
color:#FC0;
font-family: Helvetica, Arial, sans-serif; 
font-size: 12px; 
text-decoration: none; 
border: 0; 
font-weight: 400
}
.ctrlq.fb-overlay{
z-index: 0; 
position: fixed; 
height: 100vh; 
width: 100vw; 
-webkit-transition: opacity .4s, visibility .4s; 
transition: opacity .4s, visibility .4s;
top: 0; 
left: 0; 
background: rgba(0, 0, 0, .05); 
display: none
}
.ctrlq.fb-close{
z-index: 4; 
padding: 0 6px; 
background: #FF6; 
font-weight: 700; 
font-size: 11px; 
color: #F00; 
margin: 8px; 
border-radius: 3px;
}
.ctrlq.fb-close::after{
content: "X"; font-family: sans-serif
}
.bubble{
width: 20px; 
height: 20px; 
background: #c00; 
color: #fff; 
position: absolute; 
z-index: 999999999; 
text-align: center; 
vertical-align: middle; 
top: -2px; 
left: 5px; 
border-radius: 50%;
}
.zalo-chat-widget{
	top:630px;
	right:-20px;
}
.dropdown-menu{
	background-color: white;
}
a:hover{
	color:#F00;
}
a:active{
	color:#F00;
}
a:visited{
	color:#F00;
}
dg{
	color:#FFC;
}
#slideshow {
   overflow: hidden;
   height: 600px;
   width: 1000px;
   margin: 0 auto;
 }
.slide-wrapper {
   width: 3000px;
   -webkit-animation: slide 8s ease infinite;
 }
.slide {
   float: left;
   height: 400px;
   width: 1000px;
 }
 
@-webkit-keyframes slide {
   20% {margin-left: 0px;}
   30% {margin-left: -1000px;}
   50% {margin-left: -1000px;}
   60% {margin-left: -2000px;}
   80% {margin-left: -2000px;}
 }
 
 
 
 #menu ul {
 background: white;
 width: 250px;
 padding: 0;
 list-style-type: none;
 text-align: left;
}
#menu li {
 width: auto;
 height: 40px;
 line-height: 40px;
 border-bottom: 1px solid #e8e8e8;
 padding: 0 1em;
}
#menu li a {
 text-decoration: none;
 color: #333;
 font-weight: 500 !important;
 font-weight: bold;
 display: block;
}
#menu li:hover {
 background: white;
}
#menu ul li {
 position: relative;
}
#menu .sub-menu {
 position: absolute;
 left: 250px;
 top: 0;
}
#menu .sub-menu {
 position: absolute;
 left: 250px;
 top: 0px;
 display: none;
}
#menu li:hover .sub-menu {
 display: block;
}

nac{
	color:#C39;
	font-size:20px;
	font-weight: 500;
}
@media(min-width:1000px){
	.hotline-phone-ring {
    display: none !important;
	}
	.r2{
		display: none;
	}
	#show{
	height:600px;
	width:600px;
	top:-30px;
	left:-5px;
	background-repeat:no-repeat;
	background-size:cover;
}
.cde{
	display:none;
}
.ght{
	display: none;
}
.ghy{
	display: none;
}
.dt{
	display: none;
}
}
@media(max-width:1000px){
	.hotline-phone-ring {
    display: none !important;
	}
	.zalo-chat-widget{
		display: none;
	}
	a:visited {
    color: black;
}
	.dt {
    line-height: 18.4px;
    margin-top: -5px;
	width: 260px;
	margin-left: -40px;
}
	.mt{
		display: none;
	}
	.ghj{
		display: none;
	}
	.r1{
		display: none;
	}
	.tk{
		display: none;
	}
	.sticky {
  position:fixed;
  top: 0px;
  left:0px;
  width:100%;
  height:100px;
  z-index:8;
  background-color:rgba(255,255,255,0.92);
  box-shadow:0.1px 0.1px 0.1px yellow;
}
.gh{
	display: none;
}
.ttcn{
	display:none;
}
#show{
	height:300px;
	width:300px;
	top:-30px;
	left:-5px;
	margin-left:5px;
	background-repeat:no-repeat;
	background-size:cover;
}
.abc{
	display: none;
}
	
}
</style>

</head>
<body>
<div class="container h-600 border" id="con">
	<div class="row">
    	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
           <div class="row">
           <div class="col-xs-12 col-sm-12 col-md-12 col-ld-12">
           		<div class="row abc">
                	<div class="col-xs-2 col-sm-2 col-md-2 col-ld-2">
                    	<center><h3><n><img src="img/logo.png"
                         height="200px" width="200px"/></n></h3></center>
                    </div>
                    <div class="col-xs-10 col-sm-10 col-md-10 col-ld-10">
                    	<center><h3><n><img src="img/bne.jpg" height="265px" width="100%"/></n></h3></center>
                    </div>           
                 </div>
                 <div class="row cde">
                	<div class="col-xs-12 col-sm-12 col-md-12 col-ld-12">
                    	<center><h3><n><img src="img/logo.png" height="100px" width="100px"/></n></h3></center>
                        <center><nac>Shop Mỹ Phẩm VIPU</nac></center>
                        <br/>
                        <br/>
                    </div>
                            
                 </div>
                <?php if(isset($_GET['s'])||isset($_GET['gt'])||isset($_GET['loc'])||isset($_GET['themgiohang'])||isset($_GET['Info'])
				||isset($_GET['id_nhacungcap'])||isset($_GET['voice'])||isset($_GET['page'])||isset($_GET['chitiet'])||isset($_GET['suainfo'])||	
				isset($_GET['hm'])||isset($_GET['xemdh'])||isset($_GET['dxuat'])||isset($_GET['xemctdh'])||isset($_GET['lienhe'])||isset($_GET['hotro'])||isset($_GET['huydon'])||isset($_GET['abc'])||isset($_GET['danhan'])||isset($_GET['dgia'])||isset($_GET['gui'])){
					
				}
				else{?>
               <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                 <div class="row">
                <?php /* <div id="slideshow" class="r2">
  <div class="slide-wrapper">
    <div class="slide"><img src="img/h1.jpg" height="400px" width="400px"></div>
    <div class="slide"><img src="https://thegioidohoacom.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2019/01/10045250/my-pham-lasalsa-luon-la-lua-chon-yeu-thich-cua-phai-dep-1.jpg" height="400px" width="400px"></div>
       <div class="slide"><img src="img/h3.jpg" height="400px" width="400px"></div>
  </div>
  </div>
  */?>
                 	<div id="slideshow" class="r1">
  <div class="slide-wrapper">
    <div class="slide"><img src="img/h1.jpg" height="800px" width="100%"></div>
    <div class="slide"><img src="https://thegioidohoacom.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2019/01/10045250/my-pham-lasalsa-luon-la-lua-chon-yeu-thich-cua-phai-dep-1.jpg" height="800px" width="100%"></div>
       <div class="slide"><img src="img/h3.jpg" height="800px" width="100%"></div>
  </div>
  </div>

                 </div>
    

                 <?php }?>
                 </div>
                 
            <p></p>
         <div class="row p-2">
           <div class="row header" id="Follo">
           &nbsp;&nbsp;&nbsp;&nbsp;<?php //Hiển thị home?><a href="home.php?Ten=<?php if($_GET['Ten']!=null){
		   echo $_GET['Ten'];
		   }
		   else{
			   echo "user".rand(100000,1000000000);
		   }?>&&hm"><center><img src="img/nha.jpg" height="40px" width="40px"/><br /></a></center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php //Hiển thị danh mục loại mỹ phẩm?>
           <div class="dropdown">
  <button class=" btn btn-light dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <img src="img/bt.png" height="35px" width="25px" />
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
  	<?php
	//Hiển thị loại mỹ phẩm
	?>
<div id="menu" class="mt">
<ul>
<li><a href="#"><img src="https://tse3.mm.bing.net/th?id=OIP.kMostY0ayV4NovPB_wt2ogHaHa&pid=Api&P=0&h=180" height="30px" width="30px" />Trang Điểm  
</a>
<ul class="sub-menu">
<?php include_once("Controller/cCH.php");
$p=new cCH();
$tdiem=$p->laydanhmuctrangdiem();
while($cot=mysql_fetch_assoc($tdiem)){
?><li><a href="home.php?Ten=<?php echo $_GET['Ten']; ?>&&loaimypham=<?php echo $cot['loaimypham']; ?>"><?php echo $cot['loaimypham'];?></a></li>
<?php
}
?>
</ul>
</li>
<li><a href="#"><img src="https://tse3.mm.bing.net/th?id=OIP.kMostY0ayV4NovPB_wt2ogHaHa&pid=Api&P=0&h=180" height="30px" width="30px" />Chăm Sóc Da</a>
<ul class="sub-menu">
<?php include_once("Controller/cCH.php");
$p=new cCH();
$da=$p->laydanhmucchamsocda();
while($cot=mysql_fetch_assoc($da)){
?><li><a href="home.php?Ten=<?php echo $_GET['Ten']; ?>&&loaimypham=<?php echo $cot['loaimypham']; ?>"><?php echo $cot['loaimypham'];?></a></li>
<?php
}
?>
</ul>
</li>
<li><a href="#"><img src="https://tse3.mm.bing.net/th?id=OIP.kMostY0ayV4NovPB_wt2ogHaHa&pid=Api&P=0&h=180" height="30px" width="30px" />Chăm Sóc Tóc</a>
<ul class="sub-menu">
<?php include_once("Controller/cCH.php");
$p=new cCH();
$toc=$p->laydanhmucchamsoctoc();
while($cot=mysql_fetch_assoc($toc)){
?><li><a href="home.php?Ten=<?php echo $_GET['Ten']; ?>&&loaimypham=<?php echo $cot['loaimypham']; ?>"><?php echo $cot['loaimypham'];?></a></li>
<?php
}
?>
</ul>
</li>
<li><a href="#"><img src="https://tse3.mm.bing.net/th?id=OIP.kMostY0ayV4NovPB_wt2ogHaHa&pid=Api&P=0&h=180" height="30px" width="30px" />Phụ Kiện</a>
<ul class="sub-menu">
<?php include_once("Controller/cCH.php");
$p=new cCH();
$phukien=$p->laydanhmucphukien();
while($cot=mysql_fetch_assoc($phukien)){
?><li><a href="home.php?Ten=<?php echo $_GET['Ten']; ?>&&loaimypham=<?php echo $cot['loaimypham']; ?>"><?php echo $cot['loaimypham'];?></a></li>
<?php
}
?>
</ul>
</li>
<li><a href="#"><img src="https://tse3.mm.bing.net/th?id=OIP.kMostY0ayV4NovPB_wt2ogHaHa&pid=Api&P=0&h=180" height="30px" width="30px" />Nước Hoa</a>
<ul class="sub-menu">
<?php include_once("Controller/cCH.php");
$p=new cCH();
$nuochoa=$p->laydanhmucnuochoa();
while($cot=mysql_fetch_assoc($nuochoa)){
?><li><a href="home.php?Ten=<?php echo $_GET['Ten']; ?>&&loaimypham=<?php echo $cot['loaimypham']; ?>"><?php echo $cot['loaimypham'];?></a></li>
<?php
}
?>
</ul>
</li>
<li>&nbsp;&nbsp;&nbsp;<img src="https://tse2.mm.bing.net/th?id=OIP.DhEEqhIPRxejuDGfALvI7wHaHa&pid=Api&P=0&h=180" height="10px" width="10px" />&nbsp;Về Chúng Tôi</li>
<li>&nbsp;&nbsp;&nbsp;<img src="https://tse2.mm.bing.net/th?id=OIP.DhEEqhIPRxejuDGfALvI7wHaHa&pid=Api&P=0&h=180" height="10px" width="10px" />&nbsp;Sự Kiện</li>
<li>&nbsp;&nbsp;&nbsp;<img src="https://tse2.mm.bing.net/th?id=OIP.DhEEqhIPRxejuDGfALvI7wHaHa&pid=Api&P=0&h=180" height="10px" width="10px" />&nbsp;Tin Tức</li>
<li>&nbsp;&nbsp;&nbsp;<img src="https://tse2.mm.bing.net/th?id=OIP.DhEEqhIPRxejuDGfALvI7wHaHa&pid=Api&P=0&h=180" height="10px" width="10px" />&nbsp;Tuyển Dụng</li>
</ul>
</div>

  	<?php
	//Hiển thị loại mỹ phẩm
	?>
    
<div id="" class="dt">
<ul>
<li><a href="#"><img src="https://tse3.mm.bing.net/th?id=OIP.kMostY0ayV4NovPB_wt2ogHaHa&pid=Api&P=0&h=180" height="30px" width="30px" />Trang Điểm  
</a>
<ul class="sub-menu">
<?php include_once("Controller/cCH.php");
$p=new cCH();
$tdiem=$p->laydanhmuctrangdiem();
while($cot=mysql_fetch_assoc($tdiem)){
?><li><a href="home.php?Ten=<?php echo $_GET['Ten']; ?>&&loaimypham=<?php echo $cot['loaimypham']; ?>"><?php echo $cot['loaimypham'];?></a></li>
<?php
}
?>
</ul>
</li>
<li><a href="#"><img src="https://tse3.mm.bing.net/th?id=OIP.kMostY0ayV4NovPB_wt2ogHaHa&pid=Api&P=0&h=180" height="30px" width="30px" />Chăm Sóc Da</a>
<ul class="sub-menu">
<?php include_once("Controller/cCH.php");
$p=new cCH();
$da=$p->laydanhmucchamsocda();
while($cot=mysql_fetch_assoc($da)){
?><li><a href="home.php?Ten=<?php echo $_GET['Ten']; ?>&&loaimypham=<?php echo $cot['loaimypham']; ?>"><?php echo $cot['loaimypham'];?></a></li>
<?php
}
?>
</ul>
</li>
<li><a href="#"><img src="https://tse3.mm.bing.net/th?id=OIP.kMostY0ayV4NovPB_wt2ogHaHa&pid=Api&P=0&h=180" height="30px" width="30px" />Chăm Sóc Tóc</a>
<ul class="sub-menu">
<?php include_once("Controller/cCH.php");
$p=new cCH();
$toc=$p->laydanhmucchamsoctoc();
while($cot=mysql_fetch_assoc($toc)){
?><li><a href="home.php?Ten=<?php echo $_GET['Ten']; ?>&&loaimypham=<?php echo $cot['loaimypham']; ?>"><?php echo $cot['loaimypham'];?></a></li>
<?php
}
?>
</ul>
</li>
<li><a href="#"><img src="https://tse3.mm.bing.net/th?id=OIP.kMostY0ayV4NovPB_wt2ogHaHa&pid=Api&P=0&h=180" height="30px" width="30px" />Phụ Kiện</a>
<ul class="sub-menu">
<?php include_once("Controller/cCH.php");
$p=new cCH();
$phukien=$p->laydanhmucphukien();
while($cot=mysql_fetch_assoc($phukien)){
?><li><a href="home.php?Ten=<?php echo $_GET['Ten']; ?>&&loaimypham=<?php echo $cot['loaimypham']; ?>"><?php echo $cot['loaimypham'];?></a></li>
<?php
}
?>
</ul>
</li>
<li><a href="#"><img src="https://tse3.mm.bing.net/th?id=OIP.kMostY0ayV4NovPB_wt2ogHaHa&pid=Api&P=0&h=180" height="30px" width="30px" />Nước Hoa</a>
<ul class="sub-menu">
<?php include_once("Controller/cCH.php");
$p=new cCH();
$nuochoa=$p->laydanhmucnuochoa();
while($cot=mysql_fetch_assoc($nuochoa)){
?><li><a href="home.php?Ten=<?php echo $_GET['Ten']; ?>&&loaimypham=<?php echo $cot['loaimypham']; ?>"><?php echo $cot['loaimypham'];?></a></li>
<?php
}
?>
</ul>
</li>
<p></p>
<li>&nbsp;&nbsp;&nbsp;<img src="https://tse2.mm.bing.net/th?id=OIP.DhEEqhIPRxejuDGfALvI7wHaHa&pid=Api&P=0&h=180" height="10px" width="10px" />&nbsp;Về Chúng Tôi</li>
<p></p>
<li>&nbsp;&nbsp;&nbsp;<img src="https://tse2.mm.bing.net/th?id=OIP.DhEEqhIPRxejuDGfALvI7wHaHa&pid=Api&P=0&h=180" height="10px" width="10px" />&nbsp;Sự Kiện</li>
<p></p>
<li>&nbsp;&nbsp;&nbsp;<img src="https://tse2.mm.bing.net/th?id=OIP.DhEEqhIPRxejuDGfALvI7wHaHa&pid=Api&P=0&h=180" height="10px" width="10px" />&nbsp;Tin Tức</li>
<p></p>
<li>&nbsp;&nbsp;&nbsp;<img src="https://tse2.mm.bing.net/th?id=OIP.DhEEqhIPRxejuDGfALvI7wHaHa&pid=Api&P=0&h=180" height="10px" width="10px" />&nbsp;Tuyển Dụng</li>
<p></p>
<li><form><input type="text" name="s" placeholder="Tìm kiếm sản phẩm" size="20" height="10px"/>&nbsp; &nbsp;<input type="image" name="submit" src="https://tse1.mm.bing.net/th?id=OIP.slNTY6J-DQveUD89CZZ5jgAAAA&pid=Api&P=0&h=180" height="17px" width="17px" value="Tìm kiếm"/>&nbsp;</form></li>
</ul>
</div>

  <form action="#" method="get">
    <?php //Hiển thị loại mỹ phẩm
					
					?>
  </a>
  <input type="hidden" name="Ten" value="<?php echo $_GET['Ten']; ?>" />
  </form>
  </div>
</div>
&nbsp;&nbsp;&nbsp;<?php include_once("Controller/cTK(KH).php");
				$p=new cTK();
				$u=mysql_fetch_assoc($p->InfoKhachHang());?>   
<?php
$_SESSION['id_KH']=$u['id_TK'];
?>   
            &nbsp;&nbsp;&nbsp;<a href="giohang.php?Ten=<?php echo $_GET['Ten']; ?>&&id_KH=<?php echo $u['id_TK'];?>"><center><nm class="ghy">
            <div style="position: relative;background: url(img/gh.jpg); width:40px; height:40px;background-repeat:round">
            <p style="position: absolute;top:-0.8em; right: -0.5em; width: 30px; height:30px; padding: 4px;font-weight: bold; font-size: 15px;" class="rounded-circle btn btn-warning">
                   </nm><r><?php
						include_once("View/vCart.php");
				   		include_once("Controller/cSP.php");
						$p=new cSP();
						if(preg_match("/^user[0-9]{1,15}/",$_GET['Ten'])){
							$hien=$p->demvd();
						}
						else{
						$hien=$p->dem();
						}
						while($cot=mysql_fetch_assoc($hien)){
							echo $cot['soluong'];
						}
						
                      ?>
                     </r>
                     
                 </p>
 
           </div>
 </center>
             </p><center><ca class="ghy">Giỏ hàng</></ca></center></a>

  <a>&nbsp;&nbsp;&nbsp;
  
          <?php /*?> 	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="home.php"><center><img src="img/nha.jpg" height="40px" width="40px"/></center>
            <center>Home</center></a>
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="dnhap.php"><center><img src="img/ad.png" height="40px" width="40px"/></center>
             <center>Admin</center></a>
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
       		 <a href="home.php?vitri"><center><img src="img/map1.jpg" height="40px" width="40px"/></center>
             <center>Vị trí</center></a>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             <?php */?>
              <form action="#" method="get">
              &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <?php 
                include_once("View/vCH.php");                  
				?>
          <?php
if(isset($_GET['gt'])){
	$gt=$_GET['gt'];
	?>
	&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="s" value="<?php echo $gt ?>" size="10" class="tk"/>
    <?php
}
else{
?>
                    	&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="s" placeholder="Tìm kiếm sản phẩm" size="15" class="tk"/>&nbsp; &nbsp;<input type="image" name="submit" src="https://tse1.mm.bing.net/th?id=OIP.slNTY6J-DQveUD89CZZ5jgAAAA&pid=Api&P=0&h=180" height="17px" width="17px" value="Tìm kiếm" class="tk"/>
                        <input hidden="text" name="Ten" value="<?php echo $_GET['Ten'] ?>" />
<?php
}
?>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="home.php?voice&&Ten=<?php echo $_GET['Ten']; ?>"><img src="img/mc.png" width="25" height="25" class="tk" /></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php /* Lọc:&nbsp;&nbsp;&nbsp;&nbsp;
 				<?php //Lọc?>
                          
                           
                    			<select id='loc' onchange="window.location.href=this.value;">
        <option value="#"><?php 
			if(isset($_GET['loc'])){
				if($_GET['loc']==1){
					echo "Android OS";
					}
				elseif($_GET['loc']==null){
					echo "Chọn";
					}
				else{
					echo "Iphone OS";
				}
			}
			else{
					echo "Chọn";
			}
				
		?></option>
        
        <?php echo $t=$_GET['Ten'];?>
        <option value="home.php?Ten=<?php echo $t;?>&&loc=1" >Android</option>;
         <option value="home.php?Ten=<?php echo $t;?>&&loc=2" >Iphone</option>;
                        
                       </select>&nbsp;&nbsp;<select onchange="window.location.href=this.value;">
        <option value="#"><?php 
			if(isset($_GET['mingia'])&&isset($_GET['maxgia'])){
					if($_GET['mingia'] < 2000000){
						echo "< &nbsp;".number_format($_GET['maxgia']/1000000,0)."&nbsp;triệu";
					}
					elseif($_GET['mingia'] < 5000000){
						echo "Từ&nbsp;".number_format($_GET['mingia']/1000000,0)."&nbsp;triệu"."-".
						number_format($_GET['maxgia']/1000000,0)."&nbsp;triệu";
					}
					elseif($_GET['mingia'] < 10000000){
						echo "Từ&nbsp;".number_format($_GET['mingia']/1000000,0)."&nbsp;triệu"."-".
						number_format($_GET['maxgia']/1000000,0)."&nbsp;triệu";
					}
					elseif($_GET['mingia'] < 20000000){
						echo "Từ&nbsp;".number_format($_GET['mingia']/1000000,0)."&nbsp;triệu"."-".
						number_format($_GET['maxgia']/1000000,0)."&nbsp;triệu";
					}
					elseif($_GET['mingia'] < 100000000){
						echo "> &nbsp;".number_format($_GET['mingia']/1000000,0)."&nbsp;triệu";
					}
					
					}
			
			else{
					echo "Chọn";
			}
				
		?></option>
        
        <?php echo $t=$_GET['Ten'];?>
        <option value="home.php?Ten=<?php echo $_GET['Ten'];?>&&loc=<?php echo $_GET['loc']?>&&mingia=0&&maxgia=2000000" >< 2 triệu</option>;
        <option value="home.php?Ten=<?php echo $_GET['Ten'];?>&&loc=<?php echo $_GET['loc']?>&&mingia=2000000&&maxgia=5000000" >2 triệu - 5 triệu</option>;
        <option value="home.php?Ten=<?php echo $_GET['Ten'];?>&&loc=<?php echo $_GET['loc']?>&&mingia=5000000&&maxgia=10000000" >5 triệu - 10 triệu</option>;
        <option value="home.php?Ten=<?php echo $_GET['Ten'];?>&&loc=<?php echo $_GET['loc']?>&&mingia=10000000&&maxgia=20000000" >10 triệu - 20 triệu</option>;
         <option value="home.php?Ten=<?php echo $_GET['Ten']?>&&loc=<?php echo $_GET['loc']?>&&mingia=20000000&&maxgia=100000000" > > 20 triệu</option>;
                        
                       </select>
                       <br />
					   */?>
                       
                            </form>
                           
                <?php //Giỏ hàng 
				include_once("Controller/cTK(KH).php");
				$p=new cTK();
				$u=mysql_fetch_assoc($p->InfoKhachHang());?>   
<?php
$_SESSION['id_KH']=$u['id_TK'];
?>   
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          	<a href="giohang.php?Ten=<?php echo $_GET['Ten']; ?>&&id_KH=<?php echo $u['id_TK'];?>"><center><nm class="gh">
            <div style="position: relative;background: url(img/gh.jpg); width:40px; height:40px;background-repeat:round">
            <p style="position: absolute;top:-0.8em; right: -0.5em; width: 30px; height:30px; padding: 4px;font-weight: bold; font-size: 15px;" class="rounded-circle btn btn-warning">
                   </nm><r><?php
						include_once("View/vCart.php");
				   		include_once("Controller/cSP.php");
						$p=new cSP();
						if(preg_match("/^user[0-9]{1,15}/",$_GET['Ten'])){
							$hien=$p->demvd();
						}
						else{
						$hien=$p->dem();
						}
						while($cot=mysql_fetch_assoc($hien)){
							echo $cot['soluong'];
						}
						
                      ?>
                     </r>
                     
                 </p>
 
           </div>
 </center>
             </p><center><nm class="gh">Giỏ hàng</></nm></center></a>&nbsp;&nbsp;<?php //Xuất ảnh đại diện
			 include_once("Controller/cTK(KH).php");
			 $p=new cTK();
			 $co=$p->InfoKhachHang();
			 $cot=mysql_fetch_array($co);
			 
			 ?> 
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             <center><?php $ttt=mysql_fetch_assoc($p->tentontai());
			  if($_GET['Ten']==null||$ttt['Username']==null){
				 ?>
				 <div class="dropdown ttcn">
   <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown">
   <img src="img/andanh.png" height="30px" width="30px" class="img-circle" /><p></p>
   </button>
   <ul class="dropdown-menu">
   	 <li><a tabindex="-1" href="SignUp.php"><tt>Đăng Ký</tt></a></li>
     <li><a tabindex="-1" href="SignIn.php"><tt>Đăng Nhập</tt></a></li>
   </ul>
 </div>
                 <?php
			 }
			 else{?><div class="dropdown ttcn">
   <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown">
   <a href="home.php?Ten=<?php echo $_GET['Ten'] ?>&&Info"><img src="img/<?php echo $cot['Anh']; ?>" height="30px" width="30px" class="img-circle" /></a><p></p><?php echo $cot['Username']; ?>
   </button>
   <ul class="dropdown-menu">
     <li><a tabindex="-1" href="home.php?Ten=<?php echo $_GET['Ten'] ?>&&Info"><tt>Thông Tin Cá Nhân</tt></a></li>
     <li><a tabindex="-1" href="home.php?Ten=<?php echo $_GET['Ten'] ?>&&xemdh"><tt>Đơn Hàng</tt></a></li>
     <li><a tabindex="-1" href="home.php?Ten=<?php echo $_GET['Ten'] ?>&&lienhe"><tt>Liên Hệ</tt></a></li>
     <li><a tabindex="-1" href="home.php?Ten=<?php echo $_GET['Ten'] ?>&&hotro"><tt>Hỗ Trợ</tt></a></li>
     <li><a tabindex="-1" href="home.php?Ten=<?php echo "user".rand(100000,1000000000); ?>&&dxuat"><tt>Đăng Xuất</tt></a></li>
   </ul>
 </div>
             <?php }?></center>
             </div>
           </div>
        </div>
        </div>
           <p></p>
            <div class="row">
            	<div class="col-xs-0 col-sm-0 col-md-0 col-lg-0">
                <br />
                <br />
                <p></p>
                <p></p>
                <p></p>
                <p></p>
                <table class="table table-bordered col-xs-3 col-sm-3 col-md-3 col-lg-3">
                	<thead>
                	<?php
					include_once("View/vCH.php");
					?>
                   
                    </thead>
                </table>
                </div>
                
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                 <?php //Xem tệp ?>
             	 <?php
			 if(isset($_GET['download'])){
				 ?>
				 <table class="table table-bordered">
             	<thead>
                  <tr>
                  	<th><center><l>STT</l></center></th>
                    <th><center><l>Tên tệp</l></center></th>
                    <th><center><l>Download</l></center></th>
                  </tr>
                  <tr>	
                  <?php
				include_once("Controller/cSP.php");
				$p=new cSP();
				$hien=$p->xemtep();
				while($cot=mysql_fetch_assoc($hien)){
			    ?>
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             <td><center><?php echo $cot['id']?></center></td>
             <td><center><?php echo $cot['tentep']?></center></td>
       <td><center><a href="taixuong.php?file=<?php echo $cot['tentep']?>"><img src="img/down.jpg" height="35px" width="35px"/></a></center></td>
        		  </tr>
             <?php
				}
				?>
                </thead>
             <table>
                <?php
				
			 }
			 elseif(isset($_GET['vitri'])){
				 ?>
<?php ?>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15668.432383260239!2d106.71482975648472!3d10.955206652686226!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x19dc9ebc49bd622b!2sHuy%20Phong!5e0!3m2!1svi!2s!4v1641553815150!5m2!1svi!2s" width="100%" height="600px" style="border:0;" allowfullscreen="True" loading="lazy"></iframe>
                 <?php
			 }
			 elseif(isset($_GET['voice'])){
				 include_once("voice.php");
			 }
			 elseif(isset($_GET['suainfo'])){
				?>
                <center>
                <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2" >
                </div>
                <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">
                <br />
                <br />
                <center><dc>Sửa Thông Tin Cá Nhân</dc></center>
                <br />
               
                	<form action="#" method="POST">
                    <input type="hidden" name="id" value="<?php echo $cot['id_TK'];?>" />
                    	<table class="table table-bordered col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        	<thead>
                            	<tr>
                                	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<ht>Họ Tên:</ht></td>
                                    <td class="colspan='2'"><center><input type="text" name="a" value="<?php echo $cot['Username'] ?>" required="required"></center></td>
                                </tr>
                                <tr>
                                	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<ht>Email:</ht></td>
                                    <td class="colspan='2'"><center><input type="text"  name="b" value="<?php echo $cot['Email'] ?>" required="required" disabled="disabled"/></center></td>
                                </tr>
                                <tr>
                                	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<ht>Số Điện Thoại:</ht></td>
                                    <td class="colspan='2'"><center><input type="text" name="c" value="<?php echo $cot['SoDienThoai'] ?> " required="required"  /></center></td>
                                </tr>
                                <tr>
                                	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<ht>Địa Chỉ:</ht></td>
                                    <td class="colspan='2'"><center><input type="text" name="d" value="<?php echo $cot['DiaChi'] ?>" required="required" size="35" /></center></td>
                                </tr>
                                <tr>
                                	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<ht>Ảnh Đại Diện:</ht></td>
                                    <td class="colspan='2'"><center><img src="img/<?php echo $cot['Anh']?>" height="50px" width="50px" required="required" /><br /><br /><input type="file" name="f" /></center><br /><br /></td>
                                 
                                </tr>
                                <tr>
                                	
                                	<td colspan="2"><center><input type="submit" name="cntt" value="Cập Nhật" class="btn-success" /></center></td>
                                </tr>
                            </thead>
                        </table>
                   
                  </div>
                  </form>
                  <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2" >
                </div>
                </center>
                <?php 
			 }
			 elseif(isset($_GET['hotro'])){
				 ?>
                 <div class="row col-xs-12 col-sm-12 col-md-12 col-lg-12">
                 	<div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">
                    </div>
                    <div class="col-xs-10 col-sm-10 col-md-10 col-lg-10 border">
                    <p></p>
                    <center><hti>Gửi câu hỏi cần hỗ trợ bên dưới !</hti></center>
                    <br />
                    <form action="#" method="post">
                    	<center><textarea name="chs" placeholder="Nhập câu hỏi để hỏi đáp ..."></textarea></center>
                        <p></p>
                        <?php
						$p=new cTK();
						$u=mysql_fetch_assoc($p->InfoKhachHang());
						
						?>
                        <input type="hidden" name="ten" value="<?php echo $_GET['Ten']; ?>"  />
                        <input type="hidden" name="id" value="<?php
						 echo $u['id_TK']; ?>"/>
                        <center><input type="submit" value="Gửi" name="ch" /></center>
                    </form>
                    <p></p>
                    <center>
                    	<?php if(isset($_POST['ch'])){
							include_once("Controller/cCus.php");
							$p=new cKH();
							$p->chph();
							
							?>
                           <img src="img/tichxanh.png" height="30px" width="30px" /> Đã gửi câu hỏi !<?php
						}
						?>
                    </center>
                    <br />
                    <hr />
                    <center><tt><hh>Góc Giải Đáp </hh></tt></center>
                    <br />
                    <?php 
					include_once("Controller/cCus.php");
					$p=new cKH();
					$a=$p->hienchph();
					while($r=mysql_fetch_assoc($a)){
					?>
                    <br />
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<ng><?php echo date($r['ngayguicauhoi']); ?> - <?php echo $_GET['Ten']; ?></ng>
                    
                    <p></p>
                    &nbsp; <img src="img/<?php echo $r['Anh']?>" height="40px" width="40px" class="rounded-circle"/> &nbsp;&nbsp; <m><?php echo $r['cauhoi'] ?></m> 
                    <br />
                    <?php
						if($r['phanhoi']==null){
						}
						else{
					?>
                    
                    <p align="right">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<kf><ng> <?php echo $r['tennv']; ?> - <?php echo $r['ngayphanhoi'];?></ng>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</kf></p><p align="right">&nbsp;&nbsp;&nbsp;<m><?php echo $r['phanhoi'] ?></m>&nbsp;&nbsp;&nbsp; <img src="img/<?php echo $r['anhnv']?>" height="40px" width="40px" class="rounded-circle"/></p>
                    <?php
					}
					
					
					}
					?>
                    <br />
                    <br />
                    </div>
                    <div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">
                    </div>
                 </div>
                 <?php
			 }
			 
			 elseif(isset($_GET['dgia'])||isset($_GET['gui'])){
				 ?>
                 <div class="row col-xs-12 col-sm-12 col-md-12 col-lg-12">
                 	<div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">
                    </div>
                    <div class="col-xs-10 col-sm-10 col-md-10 col-lg-10 border">
                    	<p></p><tt><center><bl>Đánh Giá Về Sản Phẩm</bl></center></tt>
                        <p></p>
                        <?php
							include("Controller/cTK(BH).php");
							$p=new cTKBH();
							$u=$p->idaa();
							
							$cot=mysql_fetch_assoc($u);
							include_once("Controller/cTK(KH).php");
							$p=new cTK();
							$r=mysql_fetch_assoc($p->InfoKhachHang());
							
						?>
                        <p></p>
                        &nbsp;<xy>Người Dùng:</xy> &nbsp;&nbsp; <ts><?php  echo $_GET['Ten']?></ts>
                        <p></p>
                        <?php
						if(isset($_GET['a'])){
						}
						else{
						?>
                        &nbsp;<xy>Ảnh:</xy> &nbsp;&nbsp; <ts><img src="img/<?php  echo $cot['anh']?>" height="75px" width="75px" /></ts>
                        <p></p>
                        &nbsp;<xy>Tên SP:</xy> &nbsp;&nbsp; <ts><?php  echo urldecode($_GET['TenDT']);?></ts>
                        <p></p>
                        &nbsp;<xy>Số lượng mua:</xy> &nbsp;&nbsp; <ts>x <?php  echo $_GET['Soluong'];?> &nbsp;cái</ts>
                        <p></p>
                        <?php
						}
						?>
                        <hr />
                        <p></p>
                        <form action="#" method="get">
                        <xy>Nhận Xét: &nbsp; <input name="text" placeholder="Viết đánh giá..." size="75" required="required" /></xy>
                        <p></p>
                        <xy>Bình Chọn:</xy>&nbsp;&nbsp;<select name="sao">
                        	<option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>&nbsp; <img src="img/sao.jfif" height="25px" width="25px" />
                        <p></p>
                        <xy>Ảnh Thực Tế:</xy><center><xy><input type="file" name="f" required="required"  /></xy></center>
                        <p></p>
                        <p></p>
                        <input type="hidden" value="<?php echo $cot['anh']?>" name="a" />
                        <input type="hidden" value="<?php echo $r['Anh']?>" name="anh" />
                        <input type="hidden" value="<?php echo $_GET['Ten']?>" name="Ten" />
                        <input type="hidden" value="<?php echo $_GET['TenDT']?>" name="TenDT" />
                        <input type="hidden" value="<?php echo $_GET['Soluong']?>" name="Soluong" />
                        <input type="hidden" value="<?php echo $_GET['TenDT']?>" name="TenDT" />
                        <input type="hidden" value="<?php echo $cot['id_dt']?>" name="id" />
                        <center><xy>
                        <?php
						if(isset($_GET['a'])){
							?>
                            <p></p>
                            <br />
                            
                            <img src="img/tichxanh.png" height="35px" width="35px" /> <rt>Cảm ơn bạn đã gửi đánh giá !</rt>
                            <br />
                            <p></p>
                            <?php
						}
						else{
						?>
                        <input type="submit" name="gui" value="Gửi" /></xy>
                        <?php
			 }
			 ?></center>
                        <p></p>
                        </form>
                    </div>
                    <div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">
                    </div>
                 </div>
                 <?php
			 }
			 elseif(isset($_GET['lienhe'])){
				 ?>
                 <div class="row col-xs-12 col-sm-12 col-md-12 col-lg-12">
                 	<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                 	
                 	</div>
                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 border">
                    	<hs>Shop Mỹ Phẩm VIPU </hs>
                        <br />
                        <p></p>
                        <eff>Thông tin liên hệ:</eff>
                        
                        <br />
                        <p></p>
                        <eee>Email :</eee> <nb>phucable@gmail.com</nb>
                        <br />
                        <p></p>
                        <eee>Hotline : </eee> <nb>1900 348 348</nb>
                        <br />
                        <p></p>
                        <eee>Mã QRCode (Zalo) Shop : </eee><br /><center><img  src="img/qrme.jpg" height="100px" width="100px" /></center>
                        <p></p>
                 		
                 	</div>
                    <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                 	
                 	</div>
                 
                 </div>
                 <?php
			 }
			 elseif(isset($_GET['xemctdh'])){
				 ?>
                 <center>
                 <div class="row col-xs-12 col-sm-12 col-md-12 col-lg-12">
               		<div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">
                    </div>
                    <div class="col-xs-10 col-sm-10 col-md-10 col-lg-10 border">
                    <br />
                    	<tt><kx>Thông Tin Đơn Hàng </kx></tt>
                    <br />
                    <br />
                    <?php
							$p=new cSP();
							$cx=$p->kg();
							$c=mysql_fetch_assoc($cx);
							?>
                    <p align="left"><tt><tx>Họ tên người nhận: </tx></tt><ru><?php echo $c['tenkhac']?></ru></p>
                    <p align="left"><tt><tx>Địa chỉ nhận hàng: </tx></tt><ru><?php echo $c['diachi']?></ru></p>
                    <p align="left"><tt><tx>Số điện thoại: </tx></tt><ru>+84 <?php echo $c['sdt']?></ru></p>
                    <p align="left"><tt><tx>Ghi chú: </tx></tt><ru><?php echo $c['ghichu']?></ru></p>
                    <br />
                 	<table class="table table-bordered col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    	<thead>
                        	<tr>
                            <?php
								if($c['trangthai']==5){
									?>
                                <th><nm><center>STT</center></nm></th>
                                <th><nm><center>Tên Mỹ Phẩm</center></nm></th>
                                <th><nm><center>Ảnh</center></nm></th>
                                <th><nm><center>Số Lượng</center></nm></th>
                                <th><nm><center>Trạng Thái</center></nm></th>
                                <th><nm><center>Đánh Giá</center></nm></th>
                                    <?php
								}
								else{
							?>
                            	<th><nm><center>STT</center></nm></th>
                                <th><nm><center>Tên Mỹ Phẩm</center></nm></th>
                                <th><nm><center>Ảnh</center></nm></th>
                                <th><nm><center>Số Lượng</center></nm></th>
                                <th><nm><center>Thành Tiền</center></nm></th>
                                <th><nm><center>Phương Thức Thanh Toán</center></nm></th>
                            </tr>
                            <?php
								}
							$p=new cSP();
							$cx=$p->kg();
							$a=1;
							while($c=mysql_fetch_assoc($cx)){
								
								?>
                                <tr>	
                                	<td><p></p><center><kmd><?php echo $a++; ?></kmd></center></td>
                                    <td><p></p><center><kmd><?php echo $c['tenmypham']; ?></kmd></center></td>
                                    <td><center><kmd><img src="img/<?php echo $c['anh'] ?>" height="50px" width="50px"/></kmd></center></td>
                                    <td><p></p><center><kmd>x <?php echo $c['soluong'];
										?></kmd></center></td>
                                         <?php
								if($c['trangthai']==5){
									?>
                                    <td><p></p><center><?php echo "Đã Nhận Hàng"?></center></td>
                                    <td><p></p><center><button class="btn-info"><a href="home.php?Ten=<?php echo $_GET['Ten'] ?>&&TenDT=<?php
                                    echo $c['tendt']?>&&Soluong=<?php echo $c['soluong'];?>&&dgia"><dg>Đánh Giá</dg></a></button></center></td>
                                    <?php
								}
								else{
									?>
                                    <td><p></p><center><kmd><?php echo number_format($c['thanhtien'],0,",",".");?>&nbsp; VNĐ</kmd></center></td>
                                    <td><p></p><center><kmd><?php echo $c['phuongthucthanhtoan']?></kmd></center></td>
                                   <?php
								}
								   ?>
                                </tr>
                                
                                <?php
							}
							$a++;
							?>
                            <tr>
                            	<td class="btn-outline-light" colspan="6">
                                <?php 
								$p=new cSP();
								$tie=mysql_fetch_assoc($p->kh());
								
								?>
                                  <?php
								$p=new cSP();
								$cx=$p->kg();
								$c=mysql_fetch_assoc($cx);
								if($c['trangthai']==5){
								}
								else{
									?>
                                <h4><p align="right" ><tie><tt>Tổng tiền:&nbsp;</tt><?php echo number_format($tie['tongtien'],0,",",".") ?></tie>&nbsp; VNĐ</p></h4>
                                <?php
								}
								?>
                                </td>
                                </tr>
                        </thead>
                    </table>
                    <center><a href="home.php?Ten=<?php echo $_GET['Ten']; ?>&&xemdh"><img src="img/back.jpg" height="35px" width="35px" /></a></center>
                    </div>
                    <br />
                    
               		<div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">
                    </div>
                 </div>
                 </center>
                 
                 <?php
			 }
			 elseif(isset($_GET['xemdh'])||isset($_GET['danhan'])){
				 ?>
                 <center>
                 <div class="row col-xs-12 col-sm-12 col-md-12 col-lg-12">
               		<div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">
                    </div>
                    <div class="col-xs-10 col-sm-10 col-md-10 col-lg-10">
                    <br />
                    <br />
                 	<table class="table table-bordered col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    	<thead>
                        	<tr>
                            	<th><nm><center>STT</center></nm></th>
                            	<th><nm><center>Tên Đơn Hàng</center></nm></th>
                                <th><nm><center>Ngày Đặt</center></nm></th>
                                <th><nm><center>Trạng Thái</center></nm></th>
                                <th><nm><center>Chi Tiết</center></nm></th>
                                <th><nm><center>Hủy Đơn Hàng</center></nm></th>
                            </tr>
                            <?php
							$p=new cSP();
							$cx=$p->df();
							$a=1;
							while($c=mysql_fetch_assoc($cx)){
								?>
                                <tr>	
                                	<td><center><kmd><?php echo $a++; ?></kmd></center></td>
                                	<td><center><img src="img/dh.png" height="20px" width="20px" />&nbsp;<kmd><?php echo $c['tendonhang'] ?></kmd></center></td>
                                    <td><center><kmd><?php echo $c['ngaydat'] ?></kmd></center></td>
                                    <td><center><kmd><?php if ($c['trangthai']==0){
										echo "Chờ Xác Nhận";
									}
									elseif($c['trangthai']==1){
										echo "Đang Chẩn Bị Hàng";
									}
									elseif($c['trangthai']==2){
										echo "Đang Xử Lý Vận Chuyển";
									}
									elseif($c['trangthai']==3){
										echo "Đang Giao Hàng";
									}
									elseif($c['trangthai']==4){
										?>
                                        <button class="btn-info"><a href="home.php?Ten=<?php echo $_GET['Ten']?>&&TenDH=<?php echo $c['tendonhang'] ?>&&danhan"><dn>Đã Nhận Hàng ?</dn></a></button>
                                        <?php
									}
									elseif($c['trangthai']==5){
										echo "Đã Nhận";
									}?></kmd></center></td>
                                    <td><center><button class="btn-info"><a href="home.php?Ten=<?php echo $_GET['Ten']?>&&TenDH=<?php echo $c['tendonhang']?>
                                    &&xemctdh"><xe>Xem</xe></a></button></center></td>
                                    <td><?php
									
									
									if($c['trangthai']!=0){
										?>
                                        <center><a href="home.php?Ten=<?php echo $_GET['Ten'] ?>&&huydon=<?php echo $c['tendonhang'] ?>"><button class="btn-outline-dark" disabled="disabled">Hủy</button></a></center>
                                        <?php
									}
									else{
                                    ?><center><a href="home.php?Ten=<?php echo $_GET['Ten'] ?>&&huydon=<?php echo $c['tendonhang'] ?>"><button class="btn-danger">Hủy</button></a></center>
                                    <?php }
									 ?></td>
                                </tr>
                                <?php
							}
							$a++;
							?>
                        </thead>
                    </table>
                    </div>
                    
                    
               		<div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">
                    </div>
                 </div>
                 </center>
                 <?php
				 
			 }
			 elseif(isset($_GET['Info'])){
				 //Xem thông tin cá nhân
				?>
                <center>
                <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2" >
                </div>
                <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">
                <br />
                <br />
                <center><dc>Thông tin cá nhân</dc></center>
                <br />
                	
                    	<table class="table table-bordered col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        	<thead>
                            	<tr>
                                	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<ht>Họ Tên:</ht></td>
                                    <td class="colspan='2'"><center><input type="text" value="<?php echo $cot['Username'] ?>" disabled="disabled" /></center></td>
                                </tr>
                                <tr>
                                	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<ht>Email:</ht></td>
                                    <td class="colspan='2'"><center><input type="text" value="<?php echo $cot['Email'] ?>" disabled="disabled" /></center></td>
                                </tr>
                                <tr>
                                	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<ht>Số Điện Thoại:</ht></td>
                                    <td class="colspan='2'"><center><input type="text" value="<?php echo $cot['SoDienThoai'] ?>" disabled="disabled" /></center></td>
                                </tr>
                                <tr>
                                	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<ht>Địa Chỉ:</ht></td>
                                    <td class="colspan='2'"><center><input type="text" value="<?php echo $cot['DiaChi'] ?>" disabled="disabled" size="35" /></center></td>
                                </tr>
                                <tr>
                                	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<ht>Ảnh Đại Diện:</ht></td>
                                    <td class="colspan='2'"><center><img src="img/<?php echo $cot['Anh']?>" height="50px" width="50px" /></center></td>
                                </tr>
                                <tr>
                                	<td colspan="2"><a href="home.php?Ten=<?php echo $_GET['Ten']; ?>&&suainfo"><center><button type="button" class="btn-warning">Chỉnh Sửa</button></center></a></td>
                                </tr>
                            </thead>
                        </table>
                   
                  </div>
                  <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2" >
                </div>
                </center>
                <?php
			 }
			 elseif(isset($_GET['chitiet'])&&isset($_GET['id'])){
				 include_once("Controller/cSP.php");
				 $p=new cSP();
				 $hien=$p->Chitiet();
				 while($cot=mysql_fetch_assoc($hien)){
					 ?>
                     <table>
                     	<thead>
                     	<tr>
                        	<td colspan="3"><center></center></td>
                            <td colspan="9"></td>
                        </tr>
                       
                     	<tr>
                              	<td colspan="1">
                              
                                <div id="img-container">
                                <br/>
                                
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="img/<?php echo $cot['anh']?>" height="300px" width="300px" class="img-thumbnail" />
                                 <div>
                              
                            <br />
                            <br />
                             
                            	 <div class="row">
                                 	<div class="col-sm-3">
                               <img src="img/<?php if($cot['anh1']!=null){
								   echo $cot['anh1'];
								   }
								   else{
									   echo $cot['anh'];
								   }
								    ?>" width="50" height="50" onmouseover="update(this)" onmouseout="unDo()" class="img-thumbnail"/>
                                    </div>
                                    <div class="col-sm-3">
                                <img src="img/<?php if($cot['anh2']!=null){
								   echo $cot['anh2'];
								   }
								   ?>" width="50" height="50" onmouseover="update(this)" onmouseout="unDo()" class="img-thumbnail"/>
                                    </div>
                                    <div class="col-sm-3">
                                 <img src="img/<?php if($cot['anh3']!=null){
								   echo $cot['anh3'];
								   }
								   ?>" width="50" height="50" onmouseover="update(this)" onmouseout="unDo()" class="img-thumbnail"/>
                                    </div>
                                    <div class="col-sm-3">
                                 <img src="img/<?php if($cot['anh4']!=null){
								   echo $cot['anh4'];
								   }
								   ?>" width="50" height="50" onmouseover="update(this)" onmouseout="unDo()" class="img-thumbnail"/>
                                    </div>
                                 </div>
                            </td>
                            <td colspan="11"><rh><?php echo $cot['tenmypham']?></rh><br/>
                            <mi><strong>Giá:&nbsp;&nbsp;</strong><?php echo number_format($cot['gia'],0,",",".") ?>VNĐ</mi><br /><p></p><vi><strong><mota>Mô tả:<?php echo $cot['mota'] ?></mota></strong><br /><p></p><ncc><strong>Thương Hiệu:</strong>&nbsp;</strong><?php
							$com=mysql_fetch_assoc($p->ChitietSaPham());
							$p=new cTK();
							$u=mysql_fetch_assoc($p->InfoKhachHang());
							if($com['tenthuonghieu']==null){
								echo "Thương hiệu khác";
							}
							else{
								echo $com['tenthuonghieu'];
							}?><ncc></ncc></br></vi>
                            <tki>Hiện có:</tki>&nbsp;&nbsp;&nbsp;&nbsp;<tko><?php echo $cot['tonkho'];?></tko>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;<ac>Thêm giỏ hàng :</ac>&nbsp;<?php 
			  if($cot['tonkho']==0){
				  ?>
                  <img src="img/banhet.jpg" height="55px" width="55px"/>
                  <?php
			  }
			  else{?> <a href="home.php?Ten=<?php echo $_GET['Ten']?>&&id_KH=<?php 
				 if(preg_match("/^user[0-9]{1,15}/",$_GET['Ten'])){
					echo $_GET['Ten'];
				}
				else{
					
				    echo $u['id_TK']; 
				}?>&&themgiohang=<?php echo $cot['id_mypham']?>"><img src='img/ac.png' height="55px" width="55px"/>
                </a><?php } ?><br /><db>Đã bán:&nbsp;&nbsp;&nbsp;</db><bd><?php $p=new cSP;
				$r=mysql_fetch_assoc($p->daban());
				echo $r['daban']; ?></bd>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<sao><?php include("Controller/cTK(BH).php");
				$p=new cTKBH();
				$ur=$p->sosaosp();
				$sao=mysql_fetch_assoc($ur);
				if($sao['sosao']==0){
				echo 0;}
				else{
					echo number_format($sao['sosao'],1);
				}?>&nbsp;&nbsp;&nbsp;<img src="img/sao.jfif" height="20px" width="20px"/></sao>&nbsp; &nbsp; (&nbsp;<a href="#bl" id="a"><ci><?php  if(isset($_GET['id'])){
				include_once("Controller/cTK(BH).php");
				$p=new cTKBH();
				$si=mysql_fetch_assoc($p->songuoibinhluan()); echo $si['snbl'];}?>&nbsp;&nbsp;<nbl>bình luận</nbl></a></ci>&nbsp;)</td>
                            <td>
                            <br />
                            <br />
                            <br />
                            <br />
                            <br />
                            <br />
                            <br />
                            <br />
                            <br />
                            <br />
                            <br />
                            <p></p>
                          
                        
                            </td>
                            
                            
                            <tr>
                                 
                                
                                <td colspan="3">
                                <br/>
                                <div id="show" class="col-sm-12">
                                  
                                </div>
                                </td>
                                <td colspan="6" class="col-sm-12">
                              
                                </td>
                        </tr>
                        <tr>
                        	<?php //cái này doi hình ?>
                        </tr>
                        </thead>
                     </table>
<script>
var options = {
	height:200,
    width:200,
    zoomWidth:200,
    offset: {vertical: 0, horizontal: 10}
};
new ImageZoom(document.getElementById("img-container"), options);
 
</script>
<script>
var options = {
	height:200,
    width:200,
    zoomWidth:200,
    offset: {vertical: 0, horizontal: 10}
};
new ImageZoom(document.getElementById("show"), options);
 
</script>

<br />
<hr />
<n id="bl"></n>
<blu>Bình Luận&nbsp;(&nbsp;<?php echo $si['snbl'] ?>&nbsp;)</blu>
<br />
<?php
include_once("Controller/cTK(BH).php");
$p=new cTKBH();
$as=$p->xuatbl();
while($ii=mysql_fetch_assoc($as)){
	

?>
<br />
<br />
<p></p>
&nbsp;&nbsp;<img src="img/<?php echo $ii['anh']?>" height="35px" width="35px" class="rounded-circle" />&nbsp;&nbsp;<tnbl><?php echo $ii['tenkhachhang'] ?>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $ii['ngaybinhluan'] ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<ss><?php echo $ii['sosao'] ?></ss>&nbsp;<img src="img/sao.jfif" height="20px" width="20px" /></tnbl><br />
<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="img/<?php echo $ii['anhthucte'] ?>" height="60px" width="75px" /> &nbsp;<?php echo $ii['tendt'] ?> &nbsp; &nbsp; &nbsp; Số lượng:&nbsp;<?php echo $ii['soluong'] ?><br />
<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
Nội dung :&nbsp;<?php echo $ii['noidungbinhluan']?> &nbsp; &nbsp;<?php

	if($ii['luotyeuthich']>0){
		?>
		<a href="home.php?Ten=<?php echo $_GET['Ten']?>&&id=<?php echo $_GET['id']?>&&tym&&idbl=<?php echo $ii['id_binhluan']?>"><img src="img/tim.jfif" height="20px" width="20px" /></a>&nbsp;&nbsp;<?php echo $ii['luotyeuthich']?>
        <?php
	}
	else{
?> <a href="home.php?Ten=<?php echo $_GET['Ten']?>&&id=<?php echo $_GET['id']?>&&tym&&idbl=<?php echo $ii['id_binhluan']?>"><img src="img/kotim.jfif" height="20px" width="20px" /></a>&nbsp;&nbsp;0 

<?php
	}
	?>
    <?php if($ii['phanhoi']!=null){?>
    <br />
    <br />
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="img/rely.jfif" height="20px" width="20px" />&nbsp;<ph>Phản hồi từ shop </ph>
    <br />
    <br />
    <div class="row col-xs-12 col-sm-12 col-md-12 col-lg-12">
    <div class="row col-xs-1 col-sm-1 col-md-1 col-lg-1">
    
    </div>
    <div class="row col-xs-5 col-sm-5 col-md-5 col-lg-5 border btn-light">
    <?php echo $ii['phanhoi']?>
    </div>
	</div>
    
   
    
    <?php
	}
	else{
	}
	?><br /><br />
    <?php
}
?>
                     <?php
				 }
				 
				 ?>
                 <?php
			 }
			 else{
			 ?>
                <center></center>
                <table class="table table-bordered col-xs-12 col-sm-12 col-md-12 col-ld-12">
                	<thead>
                	<?php
					include_once("View/vSP.php");
					?>
                    
                    <thead>
                    
                </table>
                <br />
                <br />
                 <center>
                <?php
				
				$p=new Xuatphantrang();
				$p->page();
			
				
				?>
               </center>
               <br />
                <table class="table table-bordered col-xs-12 col-sm-12 col-md-12 col-ld-12">
                	<thead>
                    <br />
                    
                   
                    	<tr>
                        	<br />
                           
                        	<sd><h3><center>Sản Phẩm Mới Nhất</center></h3></sd>
                        </tr>
                        <tr>
                        
                      
                	<?php
					           include("slider1.php");
					?>
                    		
                    	</tr>
                    
                    <thead>
                    
                </table>
                            <br />
                <table class="table table-bordered col-xs-12 col-sm-12 col-md-12 col-ld-12">
                	<thead>
                    <br />
                    
                   
                    	<tr>
                        	<br />
                           
                        	<sd><h3><center>Sản Phẩm Khuyến Mãi</center></h3></sd>
                        </tr>
                        <tr>
                        
                      
                	<?php
					           include("slider.php");
					?>
                    		
                    	</tr>
                    
                    <thead>
                    
                </table>
                  
                <?php
			 }
			 ?>
                </div>
               
            </div>
       		 <p></p>
             <br/>
             <br/>
             <br/>
             <br />
<br />
             
    <div class="row">
        	<div class="zalo-chat-widget" data-oaid="467730204912564473" data-welcome-message="Rất vui khi được hỗ trợ bạn!" 	  data-autopopup="0" data-width="200" data-height="200"></div> 
<script src="https://sp.zalo.me/plugins/sdk.js"> </script> 
    		<div>
    <div class="hotline-phone-ring-wrap">
	<div class="hotline-phone-ring">
		<div class="hotline-phone-ring-circle"></div>
		<div class="hotline-phone-ring-circle-fill"></div>
		<div class="hotline-phone-ring-img-circle">
		<a href="tel:0359246276" class="pps-btn-img">
			<img src="img/dt.png" alt="Gọi điện thoại" width="50">
		</a>
		</div>
	</div>
	<div class="hotline-bar">
		<a href="tel:0325927624">
			<span class="text-hotline">0325.927.624</span>
		</a>
	</div>
</div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-ld-12" id="lendau">
            	<i class="fas fa-chevron-up"><center><input type="image" src="img/mt.jpg" height="20px" width="30px"/></center><center>Top</center></i>
            </div>
            </div>
  			<div class="footer col-xs-12 col-sm-12 col-md-12 col-ld-12 border ght">
            	<div class="col-xs-12 col-sm-12 col-md-12 col-ld-12">
                	<p></p>
        	<center><img src="img/logo.png" height="100px" width="100px" /></center>
            <p> <nx>Về Chúng Tôi</nx> </p>
            <p> <nx>Giới thiệu:</nx><a href="#"> Nhà bán lẻ Mỹ Phẩm VIPU</a></p>
            <p> <nx>Số điện thoại:</nx> <a href="tel:0325927624">0325927624</a></p>
            <p> <nx>Email:</nx> <a href="mailto:phucable@gmail.com">phucable@gmail.com</a></p>
            <p> <nx>Địa chỉ: </nx><rf> ..., Phường xxx, Quận xxx, TP.HCM </rf> </p>
                </div>
            </div>
            <div class="footer col-xs-12 col-sm-12 col-md-12 col-ld-12 border ghj">
	<div class="row">
    	<div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        <p></p>
        	<center><img src="img/logo.png" height="100px" width="100px" /></center>
            <p> <nx>Về Chúng Tôi</nx> </p>
            <p> <nx>Giới thiệu:</nx><a href="#"> Nhà bán lẻ Mỹ Phẩm VIPU</a></p>
            <p> <nx>Số điện thoại:</nx> <a href="tel:0325927624">0325927624</a></p>
            <p> <nx>Email:</nx> <a href="mailto:phucable@gmail.com">phucable@gmail.com</a></p>
            <p> <nx>Địa chỉ: </nx><rf> ..., Phường xxx, Quận xxx, TP.HCM </rf> </p>
        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        ... ( Nội dung )
        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        ... ( Nội dung )
        </div>
    </div>
    
</div>
             
             
    </div>

</div>


<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.9">
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js">
</script>
<script>
	function update(img){
		var src=img.src;
		document.getElementById('show').style.backgroundImage="url("+src+")";
		document.getElementById('show').style.backgroundRepeat="no-repeat";
		
	}
</script>
<script>
jQuery(document).ready(function($){function detectmob(){if( navigator.userAgent.match(/Android/i) || navigator.userAgent.match(/webOS/i) || navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/iPod/i) || navigator.userAgent.match(/BlackBerry/i) || navigator.userAgent.match(/Windows Phone/i) ){return true;}else{return false;}}var t={delay: 125, overlay: $(".fb-overlay"), widget: $(".fb-widget"), button: $(".fb-button")}; setTimeout(function(){$("div.fb-livechat").fadeIn()}, 0 * t.delay); if(!detectmob()){$(".ctrlq").on("click", function(e){e.preventDefault(), t.overlay.is(":visible") ? (t.overlay.fadeOut(t.delay), t.widget.stop().animate({bottom: 0, opacity: 0}, 2 * t.delay, function(){$(this).hide("slow"), t.button.show()})) : t.button.fadeOut("medium", function(){t.widget.stop().show().animate({bottom: "30px", opacity: 1}, 2 * t.delay), t.overlay.fadeIn(t.delay)})})}});</script>
<script>
window.onscroll = function() {myFunction()};

var header = document.getElementById("Follo");

var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
$(document).ready(function(){
	$(window).scroll(function(){
		if($(this).scrollTop()){
			$('#lendau').fadeIn();
		}
		else{
			$('#lendau').fadeOut();
		}
	})
	$('#lendau').click(function(){
		$('html,body').animate({
			scrollTop:0
		},10);
	})
	
})


</script>
</body>
</html>

