-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Serveur: localhost
-- Généré le : Sam 10 Décembre 2022 à 18:03
-- Version du serveur: 5.0.45
-- Version de PHP: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de données: `phone`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `dienthoai`
-- 

CREATE TABLE `dienthoai` (
  `id_dt` int(10) NOT NULL auto_increment,
  `tendt` varchar(100) NOT NULL,
  `anhurl` varchar(500) NOT NULL,
  `gia` int(15) NOT NULL,
  `giamgia` float NOT NULL,
  `anh` varchar(50) NOT NULL,
  `anh1` varchar(50) NOT NULL,
  `anh2` varchar(50) NOT NULL,
  `anh3` varchar(50) NOT NULL,
  `anh4` varchar(50) NOT NULL,
  `mota` varchar(1000) NOT NULL,
  `congnghemanhinh` varchar(50) NOT NULL,
  `dophangiai` varchar(50) NOT NULL,
  `kichthuocmanhinh` varchar(50) NOT NULL,
  `dosangtoida` varchar(50) NOT NULL,
  `chatlieukinh` varchar(50) NOT NULL,
  `dophangiaicamsau` varchar(50) NOT NULL,
  `quayphimcamsau` varchar(50) NOT NULL,
  `denflash` varchar(50) NOT NULL,
  `tinhnangcamsau` varchar(1000) NOT NULL,
  `dophangiaicamtruoc` varchar(50) NOT NULL,
  `tinhnangcamtruoc` varchar(1000) NOT NULL,
  `hedieuhanh` varchar(50) NOT NULL,
  `chipxulyCPU` varchar(50) NOT NULL,
  `tocdoCPU` varchar(50) NOT NULL,
  `chipdohoaGPU` varchar(50) NOT NULL,
  `ram` varchar(50) NOT NULL,
  `bonhotrong` varchar(50) NOT NULL,
  `thenho` varchar(50) NOT NULL,
  `danhba` varchar(50) NOT NULL,
  `mangdidong` varchar(50) NOT NULL,
  `sim` varchar(50) NOT NULL,
  `wifi` varchar(50) NOT NULL,
  `gps` varchar(50) NOT NULL,
  `bluetooth` varchar(50) NOT NULL,
  `congketnoi` varchar(50) NOT NULL,
  `tainghe` varchar(50) NOT NULL,
  `dungluongpin` varchar(50) NOT NULL,
  `loaipin` varchar(50) NOT NULL,
  `congnghepin` varchar(50) NOT NULL,
  `hotrosactoida` varchar(50) NOT NULL,
  `baomatnangcao` varchar(50) NOT NULL,
  `khangnuoc,bui` varchar(50) NOT NULL,
  `thoidiemramat` datetime NOT NULL,
  `tonkho` int(15) NOT NULL default '0',
  `id_loai` varchar(10) NOT NULL,
  `id_nhacungcap` varchar(10) NOT NULL,
  PRIMARY KEY  (`id_dt`),
  KEY `id_loai` (`id_loai`,`id_nhacungcap`),
  KEY `id_nhacungcap` (`id_nhacungcap`),
  KEY `id_loai_2` (`id_loai`),
  KEY `id_nhacungcap_2` (`id_nhacungcap`),
  KEY `id_nhacungcap_3` (`id_nhacungcap`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

-- 
-- Contenu de la table `dienthoai`
-- 

INSERT INTO `dienthoai` (`id_dt`, `tendt`, `anhurl`, `gia`, `giamgia`, `anh`, `anh1`, `anh2`, `anh3`, `anh4`, `mota`, `congnghemanhinh`, `dophangiai`, `kichthuocmanhinh`, `dosangtoida`, `chatlieukinh`, `dophangiaicamsau`, `quayphimcamsau`, `denflash`, `tinhnangcamsau`, `dophangiaicamtruoc`, `tinhnangcamtruoc`, `hedieuhanh`, `chipxulyCPU`, `tocdoCPU`, `chipdohoaGPU`, `ram`, `bonhotrong`, `thenho`, `danhba`, `mangdidong`, `sim`, `wifi`, `gps`, `bluetooth`, `congketnoi`, `tainghe`, `dungluongpin`, `loaipin`, `congnghepin`, `hotrosactoida`, `baomatnangcao`, `khangnuoc,bui`, `thoidiemramat`, `tonkho`, `id_loai`, `id_nhacungcap`) VALUES 
(1, 'Điện thoại Xiaomi Redmi Note 11', 'https://cdn.tgdd.vn/Products/Images/42/245261/xiaomi-redmi-note-11-xanh-nhat-thumb-200x200.jpg', 5490000, 0, 'xm.jpg', 'xm11_1.jpg', 'xm11_2.jpg', 'xm11_3.jpg', 'xm11.jpg', '-Kiểu dáng phong cách mới,...', 'AMOLED', 'Full HD+ (1080 x 2400 Pixels)', '6.43" - Tần số quét 90 Hz', '1000 nits', ' Kính cường lực Corning Gorilla Glass 3', 'Chính 50 MP & Phụ 8 MP, 2 MP, 2 MP', ' FullHD 1080p@30fps', ' Có', '-AI Camera<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-Ban đêm<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-Bộ lọc ', '13 MP', '-Bộ lọc màu<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-Flash màn hình', 'Android 11', 'Snapdragon 680 8 nhân', '2.4 GHz', 'Adreno 610', '6 GB', '128 GB', 'MicroSD, hỗ trợ tối đa 1 TB', 'Không giới hạn', 'Hỗ trợ 4G', '2 Nano SIM', 'Wi-Fi 802.11 a/b/g/n/acWi-Fi Direct', '-GPS<br/>-GALILEO', 'v5.0', 'Type-C', '3.5 mm', '5000 mAh', 'Li-Ion', 'Sạc pin nhanh', '33 W', '-Mở khoá khuôn mặt<br/>-Mở khoá vân tay cạnh viền', 'Không có', '2022-01-14 00:00:00', 997, '1', '3'),
(2, 'Samsung Galaxy Note 10 Plus (10+)', 'https://cdn.tgdd.vn/Products/Images/42/206176/samsung-galaxy-note-10-plus-silver-new-200x200.jpg', 7790000, 3, 'ssu.jpg', 'rr.jpg', 'not103.jpg', 'not102.jpg', 'ssung1.jpg', 'Thiết kế sang trọng,kiểu dáng ấn tượng <br/> chuẩn phong cách,đẹp,bắt mắt,...', 'Dynamic AMOLED capacitive touchscreen, 16M colors', '1440 x 3040 pixels, 19:9 ratio (~498 ppi density)', '6.8 inches, 114.0 cm2 (~91.0% screen-to-body ratio', '', '', '', '', '', '', '', '', 'Android 9.0 (Pie); One UI', '', 'Octa-core (1x2.8 GHz Kryo 485 & 3x2.4 GHz Kryo 485', 'Qualcomm SDM855 Snapdragon 855 (7 nm) ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2022-12-03 00:00:00', 929, '1', '1'),
(3, 'Điện thoại OPPO Reno8 Z 5G ', 'https://cdn.tgdd.vn/Products/Images/42/282901/oppo-reno8-z-5g-vang-thumb-2-200x200.jpg', 10490000, 2, 'oppo.jpg', 'oppo1.jpg', 'oppo2.jpg', 'oppo3.jpg', 'oppo4.jpg', 'Điện thoại thiết kế đẹp,...', 'AMOLED6.43"Full HD+', '', '', '', '', 'Chính 64 MP & Phụ 2 MP, 2 MP', '', '', '', '16 MP', '', 'Android 12', '', '', 'Snapdragon 695 5G', '', '', '', '', '', '2 Nano SIMHỗ trợ 5G', '', '', '', '', '', '4500 mA', '', '', '33 W', '', '', '2021-12-11 00:00:00', 522, '1', '2'),
(4, 'Điện thoại Realme 9 Pro+ 5G', 'https://cdn.tgdd.vn/Products/Images/42/250190/realme-9-pro-thumb-200x200.jpg', 9990000, 10, 'r.jpg', 'r1.jpg', 'r2.jpg', 'r3.jpg', 'r4.jpg', 'Điện thoại với phong cách ấn tượng,...', 'Super AMOLED6.4"Full HD+', '', '', '', '', 'Chính 50 MP & Phụ 8 MP, 2 MP', '', '', '', '16 MP', '', ' Android 12', 'MediaTek Dimensity 920 5G', '', '', '', '', '', '', '', '2 Nano SIMHỗ trợ 5G', '', '', '', '', '', '4500 mAh', '', '', '60 W', '', '', '2020-08-15 00:00:00', 997, '1', '5'),
(5, 'Điện thoại Samsung Galaxy A23 4GB ', 'https://cdn.tgdd.vn/Products/Images/42/272016/sam-sung-galaxy-a23-5g-xanh-thumb-200x200.jpg', 5690000, 0, 'sab.jpg', '1.jpg', '2.jpg', '3.jpg', '4.jpg', 'Điện thoại với kiểu dáng thanh lịch,...', 'PLS TFT LCD6.6"Full HD+', '', '', '', '', 'Chính 50 MP & Phụ 5 MP, 2 MP, 2 MP', '', '', '', '', '8MP', 'Android 12', 'Snapdragon 680', '', '', '4 GB', '', '', '', '', '2 Nano SIMHỗ trợ 4G', '', '', '', '', '', '5000mAh', '', '', '25W', '', '', '2021-05-30 00:00:00', 961, '1', '1'),
(6, 'Điện Thoại Iphone 14', 'https://cdn.tgdd.vn/Products/Images/42/289670/iPhone-14-thumb-tim-200x200.jpg', 33990000, 15, 'ipho.png', 'ipo1.jpg', 'ipo2.jpg', 'ipo3.jpg', 'ipo4.jpg', 'Điện thoại sang trọng,thời thượng,quý phái,...', 'OLED6.7"Super Retina XDR', '', '', '', '', '3 camera 12 MP', '', '', '', '12 MP', '', 'iOS 15', '', '', 'Apple A15 Bionic', '', '', '', '', '', '1 Nano SIM & 1 eSIMHỗ trợ 5G', '', '', '', '', '', '4352mAAh', '', '', '20W', '', '', '2022-12-05 00:00:00', 996, '2', '4'),
(7, 'Điện thoại OPPO Reno7 Z 5G ', 'https://cdn.tgdd.vn/Products/Images/42/271717/oppo-reno7-z-5g-thumb-1-1-200x200.jpg', 9990000, 10, 'op1.jpg', 'op2.jpg', 'op3.jpg', 'op41.jpg', 'op4.jpg', 'Thiết kế trẻ trung,thời thượng,...', 'AMOLED', ' Full HD+ (1080 x 2400 Pixels)', '6.43" - Tần số quét 60 Hz', '600 nits', ' Kính cường lực Schott Xensation UP', 'Chính 64 MP & Phụ 2 MP, 2 MP', 'FullHD 1080p@30fps,HD 720p@120fps ,HD 720p@30fps', 'Có', 'AI Camera , Ban đêm (Night Mode) , Bộ lọc màu , Chuyên nghiệp (Pro) , Chụp bằng cử chỉ , Google Lens , HDR  ,Hiệu ứng Bokeh , Làm đẹp , Quay chậm (Slow Motion) , Quay video hiển thị kép , Siêu cận (Macro),  Siêu độ phân giải  ,Toàn cảnh (Panorama), Trôi nhanh thời gian (Time Lapse) , Xóa phông,Zoom kỹ thuật số', '16 MP', 'Bộ lọc màu , Chụp đêm , Flash màn hình', 'Android 11', 'Snapdragon 695 5G 8 nhân', '2.2 GHz', 'Adreno 619', '8 GB', '128 GB', '115 GB', ' MicroSD, hỗ trợ tối đa 1 TB', 'Hỗ trợ 5G', '2 Nano SIM (SIM 2 chung khe thẻ nhớ)', '', '', '', '', '3.5 mm', '4500 mAh', 'Li-Po', 'Sạc siêu nhanh SuperVOOC', '33W', '', '', '2022-10-10 22:59:19', 998, '1', '2'),
(8, 'Điện thoại OPPO Find X5 Pro 5G', 'https://cdn.tgdd.vn/Products/Images/42/250622/oppo-find-x5-pro-den-thumb-200x200.jpg', 32990000, 0, 'oop1.jpg', 'ooop2.jpg', 'ooop3.jpg', 'ooop4.jpg', 'ooop5.jpg', 'Thiết kế đẹp,chuẩn phong cách,...', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2022-10-10 23:35:39', 980, '1', '2'),
(9, 'Điện thoại Samsung Galaxy Z Flip4 128GB', 'https://cdn.tgdd.vn/Products/Images/42/258047/samsung-galaxy-z-flip4-5g-128gb-thumb-tim-200x200.jpg', 23990000, 12, 'ssf.jpg', 'ssf1.jpg', 'ssf2.jpg', 'ssf3.jpg', 'ssf4.jpg', 'Dành cho giới thượng lưu,...', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2022-10-10 23:41:01', 1000, '1', '1'),
(10, 'Điện thoại iPhone 13 Pro Max 128GB ', 'https://cdn.tgdd.vn/Products/Images/42/250261/iphone-13-pro-max-xanh-la-thumb-200x200.jpg', 33990000, 0, 'p1.jpg', 'p2.jpg', 'p3.jpg', 'p4.jpg', 'p5.jpg', 'Dành cho giới thượng lưu,...', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2022-10-10 23:49:57', 1000, '2', '4'),
(11, 'Điện thoại Xiaomi 11 Lite 5G NE ', 'https://cdn.tgdd.vn/Products/Images/42/248353/xiaomi-mi-11-lite-ne-200x200.jpg', 9490000, 0, 'xmi1.jpg', 'xmi2.jpg', 'xmi3.jpg', 'xmi4.jpg', 'xmi5.jpg', 'Thiết kế thời thượng,trẻ trung,...', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2022-10-11 00:09:09', 999, '1', '3'),
(12, 'Điện thoại Vivo V25 5G ', 'https://cdn.tgdd.vn/Products/Images/42/283148/vivohttps://cdn.tgdd.vn/Products/Images/42/283148/vivo-v25-5g-vang-thumb-1-1-200x200.jpg', 10490000, 0, 'vv1.jpg', 'vv2.jpg', 'vv3.jpg', 'vv4.jpg', 'vv5.jpg', 'Điện thoại màu sắc tươi mới,...', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2022-10-11 22:37:55', 1000, '1', '6'),
(13, 'Điện thoại OPPO Reno 8 Pro 5G', 'https://cdn.tgdd.vn/Products/Images/42/260546/oppo-reno8-pro-thumb-xanh-1-200x200.jpg', 18990000, 5, 'a1.jpg', 'a2.jpg', 'a3.jpg', 'a4.jpg', 'a5.jpg', 'Thiết kế đẹp,chuẩn phong cách,...', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2022-10-23 15:35:57', 903, '1', '1'),
(14, 'Điện thoại Samsung Galaxy S21 FE 5G', 'https://cdn.tgdd.vn/Products/Images/42/233090/Samsung-Galaxy-S21-FE-vang-200x200.jpg', 16990000, 23, 'aa5.jpg', 'aa1.jpg', 'aa2.jpg', 'aa3.jpg', 'aa4.jpg', 'Thiết kế gọn nhẹ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2022-11-02 09:15:37', 0, '1', '1');

-- --------------------------------------------------------

-- 
-- Structure de la table `donhang`
-- 

CREATE TABLE `donhang` (
  `id_donhang` int(10) NOT NULL auto_increment,
  `tendonhang` varchar(100) NOT NULL,
  `tenkhachhang` varchar(30) NOT NULL,
  `tenkhac` varchar(100) NOT NULL,
  `tendt` varchar(100) NOT NULL,
  `anhurl` varchar(500) NOT NULL,
  `anh` varchar(50) NOT NULL,
  `soluong` int(12) NOT NULL,
  `thanhtien` varchar(30) NOT NULL,
  `ngaydat` datetime NOT NULL,
  `email` varchar(50) NOT NULL,
  `diachi` varchar(100) NOT NULL,
  `sdt` int(15) NOT NULL,
  `ghichu` varchar(200) NOT NULL,
  `phuongthucthanhtoan` varchar(100) NOT NULL,
  `tinhtrang` varchar(100) NOT NULL default '0',
  `trangthai` varchar(15) NOT NULL default '0',
  `id_giohang` int(10) NOT NULL,
  PRIMARY KEY  (`id_donhang`),
  KEY `id_giohang` (`id_giohang`),
  KEY `id_giohang_2` (`id_giohang`),
  KEY `id_giohang_3` (`id_giohang`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=25 ;

-- 
-- Contenu de la table `donhang`
-- 

INSERT INTO `donhang` (`id_donhang`, `tendonhang`, `tenkhachhang`, `tenkhac`, `tendt`, `anhurl`, `anh`, `soluong`, `thanhtien`, `ngaydat`, `email`, `diachi`, `sdt`, `ghichu`, `phuongthucthanhtoan`, `tinhtrang`, `trangthai`, `id_giohang`) VALUES 
(17, 'DHSP3.09-12-22 11:56', 'Nguyen Duc Tai', 'Nguyễn Đức Tài', 'Điện Thoại Iphone 14', 'https://cdn.tgdd.vn/Products/Images/42/289670/iPhone-14-thumb-tim-200x200.jpg', 'ipho.png', 3, '86674500', '2022-12-09 11:56:31', 'ndt@gmail.com', 'Thuận Giao, Thuận An, Bình Dương', 425352434, 'Giao tại phòng 03 ,...', 'Khi nhận hàng', '1', '4', 57),
(18, 'DHSP1.09-12-22 13:08', 'Phuc Nguyen', 'Phuc Nguyen', 'Điện thoại OPPO Find X5 Pro 5G', 'https://cdn.tgdd.vn/Products/Images/42/250622/oppo-find-x5-pro-den-thumb-200x200.jpg', 'oop1.jpg', 1, '32990000', '2022-12-09 13:08:56', 'phucable@gmail.com', 'Ấp 4,Xã Minh Hưng,Chơn Thành,Bình Phước', 325927624, 'Giao trước 12 giờ ,...', 'Khi nhận hàng', '1', '4', 58),
(19, 'DHSP1.10-12-22 11:59', 'Phuc Nguyen', 'Phuc Nguyen', 'Samsung Galaxy Note 10 Plus (10+)', 'https://cdn.tgdd.vn/Products/Images/42/206176/samsung-galaxy-note-10-plus-silver-new-200x200.jpg', 'ssu.jpg', 3, '22668900', '2022-12-10 11:59:48', 'phucable@gmail.com', 'Ấp 4,Xã Minh Hưng,Chơn Thành,Bình Phước', 325927624, 'Giao trước cổng nha,...', 'Khi nhận hàng', '1', '4', 61),
(20, 'DHSP1.10-12-22 15:08', 'Phuc Nguyen', 'Phúc Nguyễn Văn', 'Điện thoại OPPO Reno8 Z 5G ', 'https://cdn.tgdd.vn/Products/Images/42/282901/oppo-reno8-z-5g-vang-thumb-2-200x200.jpg', 'oppo.jpg', 1, '10280200', '2022-12-10 15:09:20', 'phucable@gmail.com', 'Ấp 4,Xã Minh Hưng,Chơn Thành,Bình Phước', 325927624, 'Giao ở hẻm abc,...', 'Khi nhận hàng', '1', '4', 62),
(21, 'DHSP1.10-12-22 15:08', 'Phuc Nguyen', 'Phúc Nguyễn Văn', 'Điện thoại OPPO Reno7 Z 5G ', 'https://cdn.tgdd.vn/Products/Images/42/271717/oppo-reno7-z-5g-thumb-1-1-200x200.jpg', 'op1.jpg', 1, '8991000', '2022-12-10 15:09:20', 'phucable@gmail.com', 'Ấp 4,Xã Minh Hưng,Chơn Thành,Bình Phước', 325927624, 'Giao ở hẻm abc,...', 'Khi nhận hàng', '1', '4', 66),
(22, 'DHSP1.10-12-22 15:08', 'Phuc Nguyen', 'Phúc Nguyễn Văn', 'Điện thoại Samsung Galaxy A23 4GB ', 'https://cdn.tgdd.vn/Products/Images/42/272016/sam-sung-galaxy-a23-5g-xanh-thumb-200x200.jpg', 'sab.jpg', 1, '5690000', '2022-12-10 15:09:20', 'phucable@gmail.com', 'Ấp 4,Xã Minh Hưng,Chơn Thành,Bình Phước', 325927624, 'Giao ở hẻm abc,...', 'Khi nhận hàng', '1', '4', 67),
(23, 'DHSP1.10-12-22 17:08', 'Phuc Nguyen', 'Phuc Nguyen', 'Samsung Galaxy Note 10 Plus (10+)', 'https://cdn.tgdd.vn/Products/Images/42/206176/samsung-galaxy-note-10-plus-silver-new-200x200.jpg', 'ssu.jpg', 1, '7556300', '2022-12-10 17:08:42', 'phucable@gmail.com', 'Ấp 4,Xã Minh Hưng,Chơn Thành,Bình Phước', 325927624, 'Giao trước cổng nha,...', 'Khi nhận hàng', '0', '3', 68),
(24, 'DHSP1.10-12-22 17:08', 'Phuc Nguyen', 'Phuc Nguyen', 'Điện thoại Xiaomi Redmi Note 11', 'https://cdn.tgdd.vn/Products/Images/42/245261/xiaomi-redmi-note-11-xanh-nhat-thumb-200x200.jpg', 'xm.jpg', 2, '10980000', '2022-12-10 17:08:42', 'phucable@gmail.com', 'Ấp 4,Xã Minh Hưng,Chơn Thành,Bình Phước', 325927624, 'Giao trước cổng nha,...', 'Khi nhận hàng', '0', '3', 69);

-- --------------------------------------------------------

-- 
-- Structure de la table `giohang`
-- 

CREATE TABLE `giohang` (
  `id_giohang` int(10) NOT NULL auto_increment,
  `tendt` varchar(100) NOT NULL,
  `anhurl` varchar(500) NOT NULL,
  `anh` varchar(50) NOT NULL,
  `gia` int(11) NOT NULL,
  `giamgia` float NOT NULL,
  `soluong` int(10) NOT NULL default '1',
  `thanhtien` int(11) NOT NULL,
  `id_dt` int(10) NOT NULL,
  `id_taikhoan` varchar(50) NOT NULL default ' ',
  `NgayThemGioHang` datetime NOT NULL,
  PRIMARY KEY  (`id_giohang`),
  KEY `id_sach` (`id_dt`),
  KEY `id_sach_2` (`id_dt`),
  KEY `id_sach_3` (`id_dt`),
  KEY `id_taikhoan` (`id_taikhoan`),
  KEY `id_taikhoan_2` (`id_taikhoan`),
  KEY `id_taikhoan_3` (`id_taikhoan`),
  KEY `id_taikhoan_4` (`id_taikhoan`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=70 ;

-- 
-- Contenu de la table `giohang`
-- 

INSERT INTO `giohang` (`id_giohang`, `tendt`, `anhurl`, `anh`, `gia`, `giamgia`, `soluong`, `thanhtien`, `id_dt`, `id_taikhoan`, `NgayThemGioHang`) VALUES 
(60, 'Samsung Galaxy Note 10 Plus (10+)', 'https://cdn.tgdd.vn/Products/Images/42/206176/samsung-galaxy-note-10-plus-silver-new-200x200.jpg', 'ssu.jpg', 7790000, 3, 1, 7556300, 2, ' ', '2022-12-10 11:59:22');

-- --------------------------------------------------------

-- 
-- Structure de la table `hoadon`
-- 

CREATE TABLE `hoadon` (
  `id_hoadon` int(10) NOT NULL auto_increment,
  `tenhoadon` varchar(50) NOT NULL,
  `tendonhang` varchar(50) NOT NULL,
  `tenkhachhang` varchar(50) NOT NULL,
  `tongtienthu` varchar(50) NOT NULL,
  `sotienthu` varchar(50) NOT NULL,
  `congno` varchar(50) NOT NULL default '0',
  `ngaythu` datetime NOT NULL,
  PRIMARY KEY  (`id_hoadon`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- Contenu de la table `hoadon`
-- 

INSERT INTO `hoadon` (`id_hoadon`, `tenhoadon`, `tendonhang`, `tenkhachhang`, `tongtienthu`, `sotienthu`, `congno`, `ngaythu`) VALUES 
(2, 'DHSP1.10-12-22 15:08', 'DHSP1.10-12-22 15:08', 'Phúc Nguyễn Văn', '24961200', '24961200', '0', '2022-12-10 17:01:36'),
(3, 'DHSP1.10-12-22 11:59', 'DHSP1.10-12-22 11:59', 'Phuc Nguyen', '22668900', '22668900', '0', '2022-12-10 17:06:25'),
(4, 'DHSP1.09-12-22 13:08', 'DHSP1.09-12-22 13:08', 'Phuc Nguyen', '32990000', '32990000', '0', '2022-12-10 17:06:56'),
(5, 'DHSP3.09-12-22 11:56', 'DHSP3.09-12-22 11:56', 'Nguyễn Đức Tài', '86674500', '86674500', '0', '2022-12-10 17:08:03');

-- --------------------------------------------------------

-- 
-- Structure de la table `hotro`
-- 

CREATE TABLE `hotro` (
  `id_hotro` int(10) NOT NULL auto_increment,
  `cauhoi` varchar(10000) NOT NULL,
  `phanhoi` varchar(10000) NOT NULL,
  `ngayguicauhoi` datetime NOT NULL,
  `ngayphanhoi` datetime NOT NULL,
  `anhnv` varchar(50) NOT NULL,
  `tennv` varchar(100) NOT NULL,
  `id_nvphanhoi` int(10) NOT NULL,
  `id_TK` int(10) NOT NULL,
  PRIMARY KEY  (`id_hotro`),
  KEY `id_TK` (`id_TK`),
  KEY `id_nvphanhoi` (`id_nvphanhoi`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Contenu de la table `hotro`
-- 

INSERT INTO `hotro` (`id_hotro`, `cauhoi`, `phanhoi`, `ngayguicauhoi`, `ngayphanhoi`, `anhnv`, `tennv`, `id_nvphanhoi`, `id_TK`) VALUES 
(1, 'Samsung Galaxy Note 10 Plus (10+) bảo hành sao ạ !', 'Bảo hành 1 năm nha anh .Thân !', '2022-12-09 16:00:00', '2022-12-09 17:24:58', 'cun.jpg', 'An Phuc', 4, 1),
(2, 'Điện thoại OPPO Reno8 Z 5G có giảm giá không ?', 'Có nha a.', '2022-12-09 15:00:00', '2022-12-09 17:12:33', 'cun.jpg', 'An Phuc', 8, 3),
(3, 'Mình muốn mua con Reno8 Z 5G hiệu năng ổn không ạ !', 'Máy có cấu hình tốt , ram và rom đều ổn phù hợp cho công việc và học tập ạ .', '2022-12-09 17:10:51', '2022-12-09 17:12:33', 'cun.jpg', 'An Phuc', 8, 3),
(4, 'Có bán trả góp không a điện thoại Samsung\r\n', 'Có nha a , trả góp 6 tháng lãi suất 0%', '2022-12-09 17:24:47', '2022-12-09 17:24:58', 'cun.jpg', 'An Phuc', 8, 1),
(5, 'Điện thoại OPPO Reno7 Z 5G có tốt bằng với Reno8 Z 5G ko ạ ?', 'Có nha a , anh có thể liên hệ bên đội ngũ tư vấn sẽ giúp ích cho a ạ . Chào !', '2022-12-09 17:36:40', '2022-12-09 17:37:29', 'meo.jpg', 'Phuc Follo', 4, 3),
(6, 'Giá sản phẩm hiện tại là bao nhiêu , có được đổi hàng sau khi mua không ?', '', '2022-12-10 12:06:16', '0000-00-00 00:00:00', '', '', 0, 1);

-- --------------------------------------------------------

-- 
-- Structure de la table `loai`
-- 

CREATE TABLE `loai` (
  `id_loai` varchar(10) NOT NULL,
  `loaidt` varchar(15) NOT NULL,
  `id_dt` int(10) NOT NULL auto_increment,
  PRIMARY KEY  (`id_loai`),
  KEY `id_sach` (`id_dt`),
  KEY `id_sach_2` (`id_dt`),
  KEY `id_dt` (`id_dt`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- Contenu de la table `loai`
-- 

INSERT INTO `loai` (`id_loai`, `loaidt`, `id_dt`) VALUES 
('1', 'Android', 1),
('2', 'Iphone', 2);

-- --------------------------------------------------------

-- 
-- Structure de la table `nhacungcap`
-- 

CREATE TABLE `nhacungcap` (
  `id_nhacungcap` int(10) NOT NULL auto_increment,
  `tennhacungcap` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `sdt` int(15) NOT NULL,
  `anh` varchar(50) NOT NULL,
  `diachi` varchar(50) NOT NULL,
  `ngaythanhlap` varchar(100) NOT NULL,
  PRIMARY KEY  (`id_nhacungcap`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Contenu de la table `nhacungcap`
-- 

INSERT INTO `nhacungcap` (`id_nhacungcap`, `tennhacungcap`, `email`, `sdt`, `anh`, `diachi`, `ngaythanhlap`) VALUES 
(1, 'SamSung', 'samsung@ss.com', 5678432, 'samsung.png', 'Suwon, Hàn Quốc', '1 tháng 3, 1938, Daegu, Hàn Quốc'),
(2, 'Oppo', 'oppo@ss.com', 3452133, 'oppoo.png', 'Đông Hoản, Trung Quốc', '2004, Đông Hoản, Trung Quốc'),
(3, 'Xiaomi', 'xiaomi@ss.com', 8745699, 'xiaomi.png', 'Hải Điến, Bắc Kinh, Trung Quốc', '6 tháng 4, 2010, Yingu Building, Bắc Kinh, Trung Quốc'),
(4, 'Apple', 'apple@ss.com', 2435643, 'apple.png', 'Cupertino, California, Hoa Kỳ', '1 tháng 4, 1976, Los Altos, California, Hoa Kỳ'),
(5, 'Realme', 'realme@ss.com', 8976541, 'realme.png', 'Thâm Quyến, Trung Quốc', '4 tháng 5, 2018, Thâm Quyến , Trung Quốc'),
(6, 'Vivo', 'vivo@gmail.com', 2147483647, 'vivo.png', 'Đông Hoản, Trung Quốc', '2009, Đông Hoản, Trung Quốc');

-- --------------------------------------------------------

-- 
-- Structure de la table `taikhoan`
-- 

CREATE TABLE `taikhoan` (
  `id_TK` int(10) NOT NULL auto_increment,
  `Username` varchar(100) NOT NULL,
  `Password` varchar(200) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `SoDienThoai` varchar(15) NOT NULL,
  `DiaChi` varchar(100) NOT NULL,
  `Anh` varchar(50) NOT NULL,
  `NguoiDung` varchar(50) NOT NULL,
  `usr_an` varchar(100) NOT NULL,
  PRIMARY KEY  (`id_TK`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

-- 
-- Contenu de la table `taikhoan`
-- 

INSERT INTO `taikhoan` (`id_TK`, `Username`, `Password`, `Email`, `SoDienThoai`, `DiaChi`, `Anh`, `NguoiDung`, `usr_an`) VALUES 
(1, 'Phuc Nguyen', 'e10adc3949ba59abbe56e057f20f883e', 'phucable@gmail.com', '0325927624     ', 'Ấp 4,Xã Minh Hưng,Chơn Thành,Bình Phước', 'meo2.jpg', '1', ''),
(2, 'Lê Thành Vinh', '837ac0a6cda3716a9e785c05b17c8897', 'lethanhvinh201@gmail.com', '0425352434', 'Thanh Hóa', 'meo1.jpg', '1', ''),
(3, 'Nguyen Duc Tai', '5d146e9c6ed7f798b365f51e66dba8b7', 'ndt@gmail.com', '0425352434', 'Thuận Giao, Thuận An, Bình Dương', 'cun1.jpg', '1', 'user752344104'),
(4, 'Phuc Follo', '12345678', 'phuc123@gmail.com', '0393328400', 'Bình Phước', 'meo.jpg', '3', ''),
(5, 'Vinh Le', '4ad7fc92d4bf5a4c609756b30b79aaf0', 'anhvinhka@gmail.com', '0425352434  ', 'Cổng 2 , Trường Đại Học Công Nghiệp ,Nguyễn Văn Bảo, Phường 4 , Gò Vấp , TP,HCM', 'camap.jpg', '1', 'user530259381'),
(6, 'Minh Anh', '84b809b265e68832a26e43e0adaf6500', 'ma@gmail.com', '0393328400', 'Lạng Sơn', 'meo.jpg', '1', ''),
(7, 'Hoàng Ngân', 'e860048b3279c11c53ee684da5cbc4f3', 'hoangan@gmail.com', '0425352434', 'aa,bb,Tiền Giang', 'vit.jpg', '1', 'user123456'),
(8, 'An Phuc', '66f2018d1b4792e9812dcfff5e8e4f1e', 'anphuc@gmail.com', '0425352434', 'Bình Phước', 'cun.jpg', '2', ''),
(9, 'Lam Tuong', '1fd9427998f3af8e676d14b3e6e0cf97', 'ltuong@gmail.com', '0425352434', 'Bình Phước', 'camap.jpg', '4', '');
