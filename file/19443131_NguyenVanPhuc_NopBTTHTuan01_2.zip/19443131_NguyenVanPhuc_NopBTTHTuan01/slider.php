<!DOCTYPE html>
<html lang="en"><head>
    <meta charset="utf-8" />
    <title>Swiper demo</title>
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1"
    />
    <!-- Link Swiper's CSS -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css"
    />

    <!-- Demo styles -->
    <style>
      html,
      body {
		position:relative;
        height: 100%;
      }

      body {
        font-family: Helvetica Neue, Helvetica, Arial, sans-serif;
        font-size: 14px;
        color: #000;
        margin: 0;
        padding: 0;
      }

      .swiper {
        width: 100%;
        height: 300px;
      }

      .swiper-slide {
        font-size: 18px;
        background: #fff;

        /* Center slide text vertically */
        display: -webkit-box;
        display: -ms-flexbox;
        display: -webkit-flex;
        -webkit-box-pack: center;
        -ms-flex-pack: center;
        -webkit-justify-content: center;
        justify-content: center;
        -webkit-box-align: center;
        -ms-flex-align: center;
        -webkit-align-items: center;
        align-items: center;
      }

	  
	  .swiper-button-next{
		  right:-25px;
		  background-color:#F06;
		  height:30px;
	  }
	  .swiper-button-prev{
		  left:-25px;
		  background-color:#F06;
		  background-size:cover;
		  height:30px;
	  }
	  img {
  image-rendering: pixelated;
  position:relative;
}
@media(min-width: 1000px){
	.ra{
		display:none;
	}
}
@media(max-width: 1000px){
	.mySwiper{
		display:none;
	}
}
    </style>
  </head>

  <body>
    <!-- Swiper -->
    <div class="swiper mySwiper">
     
       <div class="swiper-wrapper">
       <?php include_once("Controller/cSP.php");
		$p=new cSP();
		$co=$p->LaySPKM();
		while($cot=mysql_fetch_assoc($co)){
		?>
        
        <div class="swiper-slide">
           <div style="position: relative;background: url(img/<?php echo $cot['anh']?>); width:420px; height:150px;background-repeat:round">
             <?php if($cot['giamgia']==0){
			 }
			 else{?>
            <p style="position: absolute;top:-1.2em; right: 0.2em; width: 50px; height:35px; padding: 4px;font-weight: bold; font-size: 18px;"
            class="rounded-circle btn btn-warning">
                   <r><?php
				   		echo "-".$cot['giamgia']."%";
						
                      ?>
                     </r>
                 </p>
                 <?php
			 }
				 ?>
 			
           </div>
           <tde><uk><a href="home.php?chitiet&&Ten=<?php echo $_GET['Ten']; ?>&&id=<?php echo $cot['id_mypham']?>"><te><?php echo $cot['tenmypham']; ?></te><br>
		   <p></p><m>Giá:&nbsp;<?php echo number_format($cot['gia'],0,",",".") ?>&nbsp;VNĐ</m></a></tde>
           <br><br><br><br><?php 
			  if($cot['tonkho']==0){
				  ?>
                  <img src="img/banhet.jpg" height="55px" width="55px"/>
                  <?php
			  }
			  else{?> <a href="home.php?Ten=<?php echo $_GET['Ten']?>&&id_KH=<?php 
				 if(preg_match("/^user[0-9]{1,15}/",$_GET['Ten'])){
					echo $_GET['Ten'];
				}
				else{
					
				    echo $u['id_TK']; 
				}?>&&themgiohang=<?php echo $cot['id_dt']?>"><img src='img/ac.png' height="55px" width="55px"/>
                </a><?php } ?></br>
           
         </div>
         
         
      <?php }?>
      <br>
     </div>
      	  <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
          <div class="swiper-pagination"></div>
       </div>
    </div>
    
    <div class="swiper ra">
     
       <div class="swiper-wrapper">
       <?php include_once("Controller/cSP.php");
		$p=new cSP();
		$co=$p->LaySPKM();
		while($cot=mysql_fetch_assoc($co)){
		?>
        
        <div class="swiper-slide">
           <div style="position: relative;background: url(img/<?php echo $cot['anh']?>); width:420px; height:150px;background-repeat:round">
             <?php if($cot['giamgia']==0){
			 }
			 else{?>
            <p style="position: absolute;top:-1.2em; right: 0.2em; width: 50px; height:35px; padding: 4px;font-weight: bold; font-size: 18px;"
            class="rounded-circle btn btn-warning">
                   <r><?php
				   		echo "-".$cot['giamgia']."%";
						
                      ?>
                     </r>
                 </p>
                 <?php
			 }
				 ?>
 			
           </div>
           <tde><uk><a href="home.php?chitiet&&Ten=<?php echo $_GET['Ten']; ?>&&id=<?php echo $cot['id_mypham']?>"><te><?php echo $cot['tenmypham']; ?></te><br>
		   <p></p><m>Giá:&nbsp;<?php echo number_format($cot['gia'],0,",",".") ?>&nbsp;VNĐ</m></a></tde>
           <br><br><br><br><?php 
			  if($cot['tonkho']==0){
				  ?>
                  <img src="img/banhet.jpg" height="55px" width="55px"/>
                  <?php
			  }
			  else{?> <a href="home.php?Ten=<?php echo $_GET['Ten']?>&&id_KH=<?php 
				 if(preg_match("/^user[0-9]{1,15}/",$_GET['Ten'])){
					echo $_GET['Ten'];
				}
				else{
					
				    echo $u['id_TK']; 
				}?>&&themgiohang=<?php echo $cot['id_dt']?>"><img src='img/ac.png' height="55px" width="55px"/>
                </a><?php } ?></br>
           
         </div>
         
         
      <?php }?>
      <br>
     </div>
      	  <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
          <div class="swiper-pagination"></div>
       </div>
    </div>

    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>

    <!-- Initialize Swiper -->
    <script>
      var swiper = new Swiper(".mySwiper", {
        slidesPerView: 3,
        spaceBetween: 30,
        slidesPerGroup: 3,
        loop: true,
        loopFillGroupWithBlank: true,
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
      });
    </script>
    <script>
      var swiper = new Swiper(".ra", {
        slidesPerView: 1,
        spaceBetween: 30,
        slidesPerGroup: 1,
        loop: true,
        loopFillGroupWithBlank: true,
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
      });
    </script>
  </body>
</html>