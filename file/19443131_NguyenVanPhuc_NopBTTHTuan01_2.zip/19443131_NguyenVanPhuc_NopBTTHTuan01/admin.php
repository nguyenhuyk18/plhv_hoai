<?php if(isset($_GET['xn'])){
	include_once("Controller/cPro.php");
	$p=new cSP();
	$p->xn();
	echo header('refresh:0,url="admin.php?lsdh&&Ten='.$_GET['Ten'].'&&page='.$_GET['page'].'"');
}
elseif(isset($_GET['xn1'])){
	include_once("Controller/cPro.php");
	$p=new cSP();
	$p->xn1();
	echo header('refresh:0,url="admin.php?lsdh&&Ten='.$_GET['Ten'].'&&page='.$_GET['page'].'"');
}
elseif(isset($_POST['guibl'])){
					include_once("Controller/cTK(BH).php");
								$p=new cTKBH();
								$p->phanhoibinhluan();
								echo header('refresh:0,url="admin.php?qlbl&&Ten='.$_GET['Ten'].'"');
}
elseif(isset($_POST['OK'])){
					include_once("Controller/cTK(BH).php");
								$p=new cTKBH();
								$p->suabl();
								echo header('refresh:0,url="admin.php?qlbl&&Ten='.$_GET['Ten'].'"');
}
elseif(isset($_POST['submit'])){
								include_once("Controller/cTK(BH).php");
								$p=new cTKBH();
								$p->tlht();
								echo header('refresh:0,url="admin.php?hotro&&Ten='.$_GET['Ten'].'"');
							}
							elseif(isset($_POST['sua'])){
								include_once("Controller/cTK(BH).php");
								$p=new cTKBH();
								$p->suatlht();
								echo header('refresh:0,url="admin.php?hotro&&Ten='.$_GET['Ten'].'"');
							}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
<title>Follo-Shop bán điện thoại chính hãng</title>
<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script src="js/snow-plugin.js"></script>
<style>
#cv{
	background-color:#9FF;
}
tkh{
	color:#F66;
	font-size:25px;
}
kj{
	color:#FFF;
}
kh{
	color:#C99;
}
img {
  image-rendering: pixelated;
  position:relative;
}
nm{
	color:#F00;
	font-size:20px;
}
ok{
	color:#FFF;
}
n{
	color:#9F0;
}
xcx{
	color:#FFF;
}

m{
	color:#9C0;
}

h3{
	color:#FC0;
	font-family:cursive;
}
h5{
	color:#FC6;
	font-family:"Comic Sans MS", cursive;
}
th{  
	color:#FF3;
	background-color:#9CC;
}
a:link{
	color:#000;
}
ir{
	color:#F60;
}
xn{
	color:#FF9;
}
xnl{
	color:#F30;
}
xxn{
	color:#FFF;
}
</style>
</head>

<body>
<?php
if(isset($_GET['home-qlbdthoai'])||isset($_GET['dxuat'])||isset($_GET['dssp'])||isset($_GET['up'])||isset($_GET['del'])
||isset($_GET['themdienthoai'])||isset($_GET['lsdh'])||isset($_GET['xn'])||isset($_GET['ttl'])||isset($_GET['Ten'])||isset($_GET['qlkh'])||
isset($_GET['qlncc'])||isset($_GET['xn'])||isset($_GET['ctdh'])||isset($_GET['qlbl'])||isset($_GET['guibl'])||isset($_GET['hotro'])){
	}
else{
   echo"<script>
	window.location.href='home.php';
    </script>";
}

?>

<div class="container h-600">
	<div class="row">
    	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 border">
           <div class="row">
           <div class="col-xs-12 col-sm-12 col-md-12 col-ld-12">
           		<div class="row">
                <script type="text/javascript" src="https://itexpress.vn/API/js/noel.js"></script>
                	<div class="col-xs-2 col-sm-2 col-md-2 col-ld-2">
                    	<center><h3><n><img src="img/lgo.png"
                         height="200px" width="200px"/></n></h3></center>
                    </div>
                    <div class="col-xs-10 col-sm-10 col-md-10 col-ld-10">
                    	<center><h3><n><img src="img/banner.jpg" height="265px" width="100%"/></n></h3></center>
                    </div>   
                </div>
            <p></p>
             
           <div class="row">
           		<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
                <table class="table table-bordered">
                <?php
					include_once("Controller/cTK(AD).php");
					$p=new cTKAD();
					$sa=mysql_fetch_assoc($p->quyenchucnang());
					if($sa['NguoiDung']==2){
						?>
                        <tr>
                    	 <td><a href="home.php?Ten=<?php echo $_GET['Ten'] ?>&&abc"><img src="img/nha.jpg" height="45px" width="40px"/>&nbsp;<m>Trang chủ</m></a></td>
                    </tr>
                        <tr>
                    	<td><a href="admin.php?lsdh&&Ten=<?php echo $_GET['Ten']?>"><img src="img/dh.png" height="35px" width="35px"/>&nbsp;<m>Quản lý đơn 
<center></center><center>hàng</center></m></a></td>
                    </tr>
                        <tr>
                    	<td><a href="admin.php?hotro&&Ten=<?php echo $_GET['Ten'] ?>"><img src="img/hotro.jfif" height="40px" width="40px"/>&nbsp;<m>Hỗ Trợ</m></a></td>
                        </tr>
                        <tr>
                        <td><a href="admin.php?qlbl&&Ten=<?php echo $_GET['Ten'] ?>"><img src="img/rely.jfif" height="40px" width="40px"/>&nbsp;<m>Phản Hồi</m></a></td>
                    </tr>
                    <tr>
                    	<td><a href="admin.php?home-qlbdthoai&&Ten=<?php echo $_GET['Ten'] ?>"><img src="img/back.jpg" height="40px" width="40px"/>&nbsp;<m>Trở về</m></a></td>
                    </tr>
                    
                        
                        <?php
					}
					elseif($sa['NguoiDung']==3){
					
				?>
                	<tr>
                    	 <td><a href="home.php?Ten=<?php echo $_GET['Ten'] ?>&&abc"><img src="img/nha.jpg" height="45px" width="40px"/>&nbsp;<m>Trang chủ</m></a></td>
                    </tr>
                    <tr>
                    	 <td><a href="admin.php?qlncc&&Ten=<?php echo $_GET['Ten']?>"><img src="img/ncc.png" height="35px" width="35px"/>&nbsp;<m>Quản lý nhà<center></center><center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;cung cấp</center></m></a></td>
                    </tr>
                    <tr>
                    	 <td><a href="admin.php?dssp&&Ten=<?php echo $_GET['Ten']?>"><img src="img/qlsp.jpg" height="35px" width="35px"/>&nbsp;<m>Quản lý sản<center></center><center>phẩm</center></m></a></td>
                    </tr>
                    <tr>
                    	<td><a href="admin.php?lsdh&&Ten=<?php echo $_GET['Ten']?>"><img src="img/dh.png" height="35px" width="35px"/>&nbsp;<m>Quản lý đơn 
<center></center><center>hàng</center></m></a></td>
                    </tr>
                    <tr>
                    	<td><a href="admin.php?qlkh&&Ten=<?php echo $_GET['Ten']?>"><img src="img/qlkh.png" height="35px" width="40px"/>&nbsp;<m>Quản lý &nbsp;&nbsp;<center></center><center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;khách hàng</center></m></a></td>
                    </tr>
                    <tr>
                    	<td><a href="admin.php?hotro&&Ten=<?php echo $_GET['Ten'] ?>"><img src="img/hotro.jfif" height="40px" width="40px"/>&nbsp;<m>Hỗ Trợ</m></a></td>
                    </tr>
                    
                    <tr>
                    	<td><a href="admin.php?home-qlbdthoai&&Ten=<?php echo $_GET['Ten'] ?>"><img src="img/back.jpg" height="40px" width="40px"/>&nbsp;<m>Trở về</m></a></td>
                    </tr>
         
                  <?php
					}
					?>
                    
               
                </table>
                </div>
                <div class="col-xs-10 col-sm-10 col-md-10 col-lg-10">
                <?php
				if(isset($_GET['themdienthoai'])){
					include_once("View/vThem.php");
				}
				elseif(isset($_GET['up'])){
					include_once("View/vSua.php");
				}
				elseif(isset($_GET['del'])){
					include_once("View/vPro.php");
				}
				elseif(isset($_GET['themnhacungcap'])){
					include_once("View/vThemInv.php");
				}
				elseif(isset($_GET['upncc'])){
					include_once("View/vSuaInv.php");
				}
				elseif(isset($_GET['delncc'])){
					include_once("View/vXoaInv.php");
				}
				elseif(isset($_GET['delkh'])){
					include_once("View/vXoaCus.php");
				}
				//Tải tài liệu
				elseif(isset($_GET['ttl'])){
					?>
                    <br />
                    <h5>Mời upload tài liệu tại đây:</h5>
                    <p></p>
                    	<form method="post" enctype="multipart/form-data">
                        	<input type="file" name="f"/>
                            <input type="submit" name="submit" value="Upload"/>
                        </form>
                    <?php
					include_once("View/vPro.php");
				}
				elseif(isset($_GET['qlbl'])||isset($_GET['guibl'])){
					?>
                    <div class="row col-xs-12 col-md-12 col-lg-12 col-md-12">
                    	<div col-xs-12 col-md-12 col-lg-12 col-md-12>
                        <table class="table table-bordered col-xs-12 col-md-12 col-lg-12 col-md-12">
                    	<thead>
                        <tr>
                        	<th><center>STT</center></th>
                            <th><center>Tên Khách Hàng</center></th>
                            <th><center>Sản Phẩm Mua</center></th>
                            <th><center>Ảnh Thực Tế</center></th>
                            <th><center>Nội Dung Bình Luận</center></th>
                            <th><center>Đánh Giá</center></th>
                             <th><center>Phản Hồi</center></th>
                             <th><center>Xác Nhận</center></th>
                        </tr>
                        <?php
						include("Controller/cTK(BH).php");
						$p=new cTKBH();
						if(isset($_GET['qlbl'])){
						$r=$p->xembinhluan();
						$a=1;
						while($s=mysql_fetch_assoc($r)){
						?>
                        <tr>
                        	<td><center><?php echo $a++;?></center></td>
                            <td><center><?php echo $s['tenkhachhang'];?></center></td>
                            <td><center><?php echo $s['tendt'];?></center></td>
                            <td><center><img src="img/<?php echo $s['anhthucte'];?>" height="50px" width="50px" /></center></td>
                            <td><center><?php echo $s['noidungbinhluan'];?></center></td>
                            <td><center><?php echo $s['sosao'];?>&nbsp;<img src="img/sao.jfif" height="20px" width="20px" /></center></td>
                            <form action="#" method="post">
                            <input type="hidden" name="idbl" value="<?php echo $s['id_binhluan']?>" />
                            <?php if($s['phanhoi']==null){?><td><center><textarea name="ph" placeholder="Nhập phản hồi ..."></textarea></center></td>
                             <td><br /><center><input type="submit" value="Gửi" name="guibl" /></center></td>
                              </form>
                             <?php
							}
							else{
								?><td><center><?php if(isset($_GET['suabl'])){
									?><br />
                                    <form action="#" method="post">
                                    <input type="text" name="phl" value="<?php echo $s['phanhoi']?>" ></textarea>
                                    <?php
								}
								else{
									echo $s['phanhoi'];
								}?></center></td>
                                <td><center><?php if(isset($_GET['suabl'])){
									
									?><br />
                                     <input type="hidden" name="idbl" value="<?php echo $s['id_binhluan']?>" />
                                     <input type="submit" value="OK" name="OK" class="btn-info" />
                                    </form>
                                    <?php
								}
								else{?><button class="btn-light" ><a href="admin.php?qlbl&&Ten=<?php echo $_GET['Ten']?>&&idbl=<?php echo $s['id_binhluan']?>&&suabl">Sửa</a></button><?php } ?></center></td>
                                <?php
							}
							?>
                            
                        </tr>
                        <?php
						}
						$a++;
						}
						?>
                        </thead>
                        </table>
                        </div>
                     </div>
                    <?php
				}
				elseif(isset($_GET['hotro'])){
					?>
                    <div class="row col-xs-12 col-md-12 col-lg-12 col-md-12">
                    	<div col-xs-12 col-md-12 col-lg-12 col-md-12>
                        <table class="table table-bordered col-xs-12 col-md-12 col-lg-12 col-md-12">
                    	<thead>
                        <tr>
                        	<th><center>STT</center></th>
                        	<th><center>Người Dùng</center></th>
                            <th><center>Câu Hỏi Hỗ Trợ</center></th>
                            <th><center>Phản Hồi</center></th>
                            <th><center>Xác Nhận</center></th>
                        </tr>
                        <?php 
						include_once("Controller/cTK(BH).php");
						$p=new cTKBH();
						$co=$p->xuatchht();
						$a=1;
						while($c=mysql_fetch_assoc($co)){
						?>
                        <tr>	
                        	<td><center><?php echo $a++; ?></center></td>
                        	<td><center><?php echo $c['Username']?></center></td>
                            <td><center><?php echo $c['cauhoi']?></center></td>
                            <?php
								if($c['phanhoi']==null){
								
							?>
                            <td><center>
                           
                            <form action="#" method="post">
                            	<textarea name="ph" placeholder="Nhập câu trả lời ..."></textarea>
                            </center></td>
                            <td><center><input type="submit" value="Gửi"  name="submit"/>
                            <?php
							$as=$p->id();
							$u=mysql_fetch_assoc($as);
							?>
                            <input type="hidden" name="idht" value="<?php echo $c['id_hotro'];?>" />
                             <input type="hidden" name="anh" value="<?php echo $u['Anh'];?>" />
                            <input type="hidden" name="ten" value="<?php echo $_GET['Ten'];?>" /></center>
                            <input type="hidden" name="id" value="<?php echo $u['id_TK'];?>" />
                            <input type="hidden" name="idkh" value="<?php echo $c['id_TK'];?>" /></center></form></td>
                            <?php
							
								}
								elseif(isset($_GET['sua'])){
									?>
                                    <td><center>
                           <?php
							$as=$p->id();
							$u=mysql_fetch_assoc($as);
							?>
                            <form action="#" method="post">
                            	<input type="text" name="phi" value="<?php echo $c['phanhoi']?>" >
                            </center></td>
                            <input type="hidden" name="idht" value="<?php echo $c['id_hotro'];?>" />
                             <input type="hidden" name="id" value="<?php echo $u['id_TK'];?>" />
                            <input type="hidden" name="idkh" value="<?php echo $c['id_TK'];?>" />
                            <td><center><input type="submit" value="OK"  name="sua"/></td>
                            </form>
                            
                           
                                    <?php
									
								}
								else{
									?>
                                    <td><center><?php echo $c['phanhoi']?></center></td>
                                    <td><center><button class="btn-info"><a href="admin.php?hotro&&Ten=<?php echo $_GET['Ten']?>&&sua"><kj>Sửa</kj></a></button></center></td>
                                    
                                    <?php
								}
							?>
                        </tr>
                        <?php
						}
						$a++;
						
						?>
                        <tr>
                        </tr>
                        </thead>
                    </table>
                        </div>
                    </div>
                    <?php
				}
				elseif(isset($_GET['ctdh'])){
					?>
                    <div class="row col-xs-12 col-md-12 col-lg-12 col-md-12">
                    	<div class=" col-xs-1 col-md-1 col-lg-1 col-md-1">
                    	
                    </div>
                    
                    <div class=" col-xs-10 col-md-10 col-lg-10 col-md-10 border">
                    <br />
                        <center><tkh>Chi Tiết Đơn Hàng</tkh></center>
                        <br />
                        <?php
						   include("Controller/cPro.php");
						   $p=new cSP();
						    $hi=$p->ctdh();
							$ca=mysql_fetch_assoc($hi);
						   ?>
                        <kh>&nbsp;Tên Khách Hàng:</kh> <?php echo $ca['tenkhac'];?>
                        <br />
                        <kh>&nbsp;Địa Chỉ:</kh> <?php echo $ca['diachi'];?>
                        <br />
                        <kh>&nbsp;Số Điện Thoại:</kh> +84 <?php echo $ca['sdt'];?>
                        <br />
                        <kh>&nbsp;Ghi Chú:</kh> <?php echo $ca['ghichu'];?>
                        <br />
                        <kh>&nbsp;Phương Thức Thanh Toán:</kh> <?php echo $ca['phuongthucthanhtoan'];?>
                        <br />
                        <br />
                    <table class="table table-bordered col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    	<thead>
                          <tr>
                        	<th><center>STT</center></th>
                            <th><center>Tên Sản Phẩm</center></th>
                            <th><center>Ảnh</center></th>
                            <th><center>Số Lượng</center></th>
                            <th><center>Thành Tiền (VNĐ)</center></th>
                            <th><center>Ngày Đặt</center></th>
                           </tr>
                           <?php
						   $hie=$p->ctdh();
						   $a=1;
						   while($c=mysql_fetch_assoc($hie)){
						   ?>
                           <tr>
                           
                           	<td><p></p><center><?php echo $a++;?></center></td>
                            <td><?php echo $c['tendt']?></td>
                            <td><center><img src="img/<?php echo $c['anh']?>" height="75px" width="75px"/></center></td>
                            <td><p></p><center>x &nbsp;<?php echo $c['soluong']?></center></td>
                            <td><p></p><center><?php echo number_format($c['thanhtien'],0)?>&nbsp;đ</center></td>
                            <td><center><?php echo $c['ngaydat']?></center></td>
                           
                           </tr>
                            <?php
						   }
						   $a++;
						   ?>
                           
                        </thead>
                    </table>
                    <br />
                    <center>
                    <?php 
					if(isset($_GET['homnay'])){
						?>
						<a href="admin.php?lsdh&&Ten=<?php echo $_GET['Ten'] ?>&&homnay"><img src="img/back.jpg" height="50px" width="50px"/></a>
                        <?php
					}
					elseif(isset($_GET['homqua'])){
		?>
						<a href="admin.php?lsdh&&Ten=<?php echo $_GET['Ten'] ?>&&homqua"><img src="img/back.jpg" height="50px" width="50px"/></a>
                        <?php
		
	}				elseif(isset($_GET['trongtuan'])){
		?>
						<a href="admin.php?lsdh&&Ten=<?php echo $_GET['Ten'] ?>&&trongtuan"><img src="img/back.jpg" height="50px" width="50px"/></a>
                        <?php
		
	}
					else{
		
					?>
				
                    	<a href="admin.php?lsdh&&Ten=<?php echo $_GET['Ten'] ?>"><img src="img/back.jpg" height="50px" width="50px"/></a>
                        <?php
					}
					?>
                    </center>
                    <br />
                    	
                    </div>
                    <div class=" col-xs-1 col-md-1 col-lg-1 col-md-1">
                    	
                    </div>
                    
                    </div>
                    <?php
				}
				//Xem lịch sử đơn hàng
				elseif(isset($_GET['lsdh'])||isset($_GET['xn'])){?>
                	<?php /*
						include_once("Controller/cPro.php");
						$p=new cSP();
						$hien=$p->soluongdat();
						   if(mysql_num_rows($hien)>0){
							while($cot=mysql_fetch_assoc($hien)){?>
                            <strong>Có <?php echo $cot['sl']?> lượt khách hàng đặt mua chờ xác nhận đơn hàng!!!</strong>
                            <?php
							}
						  }
						
					*/?>
                   
                    Lọc Đơn: &nbsp;<select onchange="window.location.href=this.value;">
                     <option value="#">
                     <?php
					 	if(isset($_GET["homnay"])){
							echo "Hôm nay";
						}
						elseif(isset($_GET["homqua"])){
							echo "1 ngày trước";
						}
						elseif(isset($_GET["trongtuan"])){
							echo "Tuần qua";
						}
						else{
							echo "Chọn";
						}
                     ?></option>
                    	<option value="admin.php?lsdh&&Ten=<?php echo $_GET['Ten']; ?>&&homnay">Hôm nay</option>
                        <option value="admin.php?lsdh&&Ten=<?php echo $_GET['Ten']; ?>&&homqua">1 ngày trước</option>
                        <option value="admin.php?lsdh&&Ten=<?php echo $_GET['Ten']; ?>&&trongtuan">Tuần qua</option>
                    </select>
            	<br />
                <br />
				<table class="table table-bordered">
        		<thead>
            	<tr id="cv">
                	<th><center>STT</center></th>
                    <th><center>Mã DH</center></th>
                    <th><center>Tên KH</center></th>
                    <th><center>Tổng Tiền</center></th>
                    <th><center>Tình Trạng</center></th>
                    <th><center>Chi Tiết</center></th>
                    <th><center>Trạng Thái</center></th>
                    <th><center>Hủy</center></th>
                    
               </tr>
               <?php
					include_once("View/vPro.php");
				?>
                </thead>
                </table>
                <center>
                <?php
				if(isset($_GET['homnay'])){
		
		
				}
				elseif(isset($_GET['homqua'])){
		
		
				}
				elseif(isset($_GET['trongtuan'])){
		
		
				}
				else{
                	$p=new xuatphantrang();
					$p->page();
				}
				?>
                </center>
                <?php
				}
				else{
				
				?>
               <?php
				if(isset($_GET['dssp'])){
				?>
    <p align="right"><a href="admin.php?themdienthoai&&Ten=<?php echo $_GET['Ten'];?>"><img src="img/them.jpg" height="60px" width="60px"/></a></p>
                <table class="table table-bordered">
        		<thead>
            	<tr>
                    <th><center>Mã SP</center></th>
                    <th><center>Tên sản phẩm</center></th>
                    <th><center>Giá</center></th>
                    <th><center>Khuyến mãi</center></th>
                    <th><center>Ảnh</center></th>
                    <th><center>Loại</center></th>
                    <th><center>Mã cửa hàng</center></th>
                    <th><center>Sửa</center></th>
                    <th><center>Xóa</center></th>
                    
               </tr>
                <?php
				 include_once("View/vPro.php");
				
				?>
                </thead>
               </table>
               <center>
               <?php
			   
				$p=new xuatphantrang();
				$p->page();
				
				}
				elseif(isset($_GET['qlncc'])){
					?>
					<p align="right"><a href="admin.php?themnhacungcap&&Ten=<?php echo $_GET['Ten'];?>"><img src="img/them.jpg" height="60px" width="60px"/></a></p>
                <table class="table table-bordered">
        		<thead>
            	<tr>
                    <th><center>Mã NCC</center></th>
                    <th><center>Tên NCC</center></th>
                    <th><center>Email</center></th>
                    <th><center>Phone</center></th>
                    <th><center>Địa Chỉ</center></th>
                    <th><center>Logo</center></th>
                    <th><center>Ngày Thành Lập</center></th>
                    <th><center>Sửa</center></th>
                    <th><center>Xóa</center></th>
                    
                    
               </tr>
                <?php
				 include_once("Controller/cInv.php");
				 $p=new cNCC();
				 $cot=$p->NCC();
				 while($ncc=mysql_fetch_assoc($cot)){
				 
				 ?>
                 	<tr>
                    
                    	<td><center><ir><?php echo $ncc['id_nhacungcap'];?></ir></center></td>
                        <td><center><?php echo $ncc['tennhacungcap'];?></center></td>
                        <td><center><?php echo $ncc['email'];?></center></td>
                        <td><center><?php echo $ncc['sdt'];?></center></td>
                        <td><center><?php echo $ncc['diachi'];?></center></td>
                        <td><center><img src="img/<?php echo $ncc['anh'];?>" height="50px" width="50px" /></center></td>
                        <td><center><?php echo $ncc['ngaythanhlap'];?></center></td>
                        <td><center><a href="admin.php?upncc=<?php echo $ncc['id_nhacungcap'] ?>&&Ten=<?php echo $_GET['Ten'];?>"><img src="img/edit.png" height="30px" width="30px"/></a></center></td>
            <td><center><a href="admin.php?delncc=<?php echo $ncc['id_nhacungcap'] ?>&&Ten=<?php echo $_GET['Ten'];?>"><img src="img/del.png" height="30px" width="30px"/></a></center></td>
                    </tr>
                 <?php
				 }
				?>
                </thead>
               </table>
               <center>
               <?php
			   
				
					
				}
				elseif(isset($_GET['qlkh'])){
					?>
					
                    <p></p>
                <table class="table table-bordered">
        		<thead>
            	<tr>
                    <th><center>Mã KH</center></th>
                    <th><center>Họ tên KH</center></th>
                    <th><center>Email</center></th>
                    <th><center>Số điện thoại</center></th>
                    <th><center>Địa chỉ</center></th>
                    <th><center>Ảnh</center></th>
                    <th><center>Xóa</center></th>
                    
                    
               </tr>
               
                <?php
				 include_once("Controller/cCus.php");
				 $p=new cKH();
				 $cot=$p->KH();
				 while($kh=mysql_fetch_assoc($cot)){
				 
				 ?>
                 	<tr>
                    
                    	<td><center><ir><?php echo $kh['id_TK'];?></ir></center></td>
                        <td><center><?php echo $kh['Username'];?></center></td>
                        <td><center><?php echo $kh['Email'];?></center></td>
                        <td><center><?php echo $kh['SoDienThoai'];?></center></td>
                        <td><center><?php echo $kh['DiaChi'];?></center></td>
                        <td><center><img src="img/<?php echo $kh['Anh'];?>" height="50px" width="50px" /></center></td>
            <td><center><a href="admin.php?delkh=<?php echo $kh['id_TK'] ?>&&Ten=<?php echo $_GET['Ten'];?>"><img src="img/del.png" height="30px" width="30px"/></a></center></td>
                    </tr>
                 <?php
				 }
				?>
                </thead>
               </table>
               <center>
               <?php
			   $p=new cKH();
			   $p->PhantrangKH();
					
				}
				
				
				else{
					echo "<img src='img/ma.jpg' height='100%' width='100%'/>";
				}
				}
				?>
                
               </center>
              <br/>
                </div>
           </div>
        </div>
        <br />
        <br />
        <div class="col-xs-12 col-sm-12 col-md-12 col-ld-12 border">
            <marquee><k>Trang Admin-Nơi quản trị mọi cơ sở dữ liệu tuyệt vời với các công cụ siêu vạn năng hỗ trợ đắc lực cho bạn!!!</k></marquee>
        </div>
    </div>
    
        
</div>
</body>
</html>