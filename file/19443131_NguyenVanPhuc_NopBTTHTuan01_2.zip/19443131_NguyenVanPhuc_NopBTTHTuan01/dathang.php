<?php
if(preg_match("/^user[0-9]{1,15}/",$_GET['Ten'])){
	$a=$_GET['Ten'];
	echo"<script>
	window.location.href='SignIn.php?Ten=$a';
    </script>";
}
else{
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script type="text/javascript" src="js/jquery.zoom.min.js"></script>

<script src="https://unpkg.com/js-image-zoom@0.4.1/js-image-zoom.js" type="application/javascript"></script>
<title>Trang chủ</title>
<style>
img {
  image-rendering: pixelated;
  position:relative;
}
.footer{
	background-color:#CCF;
	border-width:1px !important;
	border-color: #000 !important;
}
tt{
	color:#F36;
	font-size:24px;
}
tg{
	color:#F90;
	font-size:16px;
}
gc{
	color:#99F;
	font-size:16px;
	font-weight:200;
}
pt{
	color:#960;
	font-size:16px;
	font-weight:200;
}
tti{
	color:#99C;
	font-size:17px;
	font-weight:200;
}
r{
	color:#F66;
	font-size:16px;
	font-weight:200;
}
sp{
	color:#99C;
	font-size:18px;
	font-weight:200;
}
ho{
	color:#000;
}
#slideshow {
   overflow: hidden;
   height: 400px;
   width: 1120px;
   margin: 0 auto;
 }
.slide-wrapper {
   width: 5000px;
   -webkit-animation: slide 8s ease infinite;
 }
.slide {
   float: left;
   height: 400px;
   width: 1120px;
 }
 a{
	 color:#FC3;
 }
 
@-webkit-keyframes slide {
   20% {margin-left: 0px;}
   30% {margin-left: -1120px;}
   50% {margin-left: -1120px;}
   60% {margin-left: -2290px;}
   80% {margin-left: -2290px;}
 }
</style>
</head>

<body>

<div class="container h-600">
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 border">
    <div class="row">
   					<div class="col-xs-2 col-sm-2 col-md-2 col-ld-2">
                    	<center><h3><n><img src="img/logo.png"
                         height="200px" width="200px"/></n></h3></center>
                    </div>
                    <div class="col-xs-10 col-sm-10 col-md-10 col-ld-10">
                    	<center><h3><n><img src="img/bne.jpg" height="265px" width="100%"/></n></h3></center>
                    </div> 
    </div>
      <div class="row p-2">
           <div class="row "><?php /* header" id="Follo" */?>
           	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="home.php?Ten=<?php echo $_GET['Ten']; ?>&&id_KH=<?php echo $_GET['id_KH'];?>&&abc"><center><img src="img/nha.jpg" height="40px" width="40px"/></center> 
            <center><ho>Home</ho></center></a> 
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             <?php /*?>
            <a href="dnhap.php"><center><img src="img/ad.png" height="40px" width="40px"/></center>
             <center>Admin</center></a>
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
       		 <a href="home.php?vitri"><center><img src="img/map1.jpg" height="40px" width="40px"/></center>
             <center>Vị trí</center></a>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <?php */?>
         </div>

        </div>
        <br />
        <div class="row">
         <?php 
			if(isset($_POST['dh'])){
				if($_POST['f']==null){
					echo "<script>alert('Vui lòng chọn phương thức thanh toán')</script>";
					$a=$_GET['Ten'];
					$b=$_GET['id_KH'];
					echo header("refresh:0,url='dathang.php?Ten=$a&&id_KH=$b'");
				}
				elseif(isset($_POST['tdh'])){
					$ten=$_POST['a'];
					$email=$_POST['c'];
					$e1="phucable@gmail.com";
					$diachi=$_POST['b'];
					$sdt=$_POST['d'];
					$gc=$_POST['e'];
					$pt=$_POST['f'];
	include_once("Controller/cSP.php");
	$p=new cSP();
	$cot=$p->themdonhang();
	$cot=$p->capnhatDonHang();
	$cot=$p->cntkho();
	include_once('Controller/cSP.php');
    $p=new cSP();
	$co=$p->xdh1();
	$cot=$p->xoagh();
include_once("Controller/cTK(KH).php");
$p=new cTK();
$tk=mysql_fetch_assoc($p->xuat());	
$pe=$tk['Email'];

$strBody.="<p style='color:#03F;'>Cảm ơn bạn đã đặt hàng từ Shop Mỹ Phẩm ViPu !</p>
<p></p>
<p style='color:orange;'>Đây là thông tin đặt hàng của bạn :</p>
<p></p>
<p style='color:brown'>-Tên khách hàng:&nbsp;".$ten."</p>
<p style='color:brown'>-Email:&nbsp;".$email."</p>
<p style='color:brown'>-Địa chỉ:&nbsp;".$diachi."</p>
<p style='color:brown'>-Số điện thoại:&nbsp;".$sdt."</p>
<p style='color:brown'>-Ghi chú:&nbsp;".$gc."</p>
<p style='color:blue'>*Lưu ý : Nếu nhận hàng trực tiếp, quý khách được phép xem sản phẩm giao đến và vui lòng chuẩn bị đủ tiền trước khi thanh toán !  </p><br/>

";


$strBody.="<center><table border='0.5px' width='100%'>

<tr style='background-color:#CFF;'>
<th>Số Thứ Tự</th>
<th>Tên Mỹ Phẩm</th>
<th>Ảnh</th>
<th>Số lượng</th>
<th>Thành Tiền</th>
<th>Ngày Đặt</th>";


$a=1;
while($tt=mysql_fetch_assoc($co)){	
$strBody.="<tr style='background-color:#FFFFCC'>
<td><center>".$a++."</center></td>
<td><center>".$tt['tenmypham']."</center></td>
<td><center><img src='".$tt['anhurl']."' height='40px' width='40px'/></center></td>
<td><center>".$tt['soluong']."</center></td>
<td><center>".number_format($tt['thanhtien'],0,',','.')."&nbsp; VNĐ</center></td>
<td><center>".$tt['ngaydat']."</center></td>
</tr>";
}
$a++;
include_once("Controller/cSP.php");
$p=new cSP();
$c=$p->tongtiendh();
$tt1=mysql_fetch_assoc($c);
$strBody.="
</table></center><br/>
<p align='right'><b style='color:brown'>Tổng tiền:&nbsp;&nbsp;".number_format($tt1['tongtien'],0,',','.')."&nbsp; VNĐ</b></p>
<p style='color:green'>Phương thức thanh toán:&nbsp;".$pt."</p>
<p style='color:orange'>Quý khách có thể xem đơn hàng trực tiếp trên website: <a href='http://localhost/MyPham/home.php?Ten=".$_GET['Ten']."&&xemdh'>http://localhost/MyPham/home.php?Ten=".$_GET['Ten']."&&xemdh</a></p>

<p style='color:blue'>Mọi chi tiết xin phản hồi lại về địa chỉ : ".$e1."</p>";





include "class.phpmailer.php"; // include the class name
$mail = new PHPMailer(); // create a new object
$mail->IsSMTP(); // enable SMTP
$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
$mail->SMTPAuth = true; // authentication enabled
$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for GMail
$mail->Host = "smtp.gmail.com";
$mail->Port = 465; // or 587
$mail->IsHTML(true);
$mail->Username = "phucable@gmail.com";
$mail->Password = "afbv blky ofzi vzsy";
$mail->SetFrom("shop@gmail.com");
$mail->AddAddress($pe);
$mail->Subject = "Website Shop ViPu!";
$mail->Body =  $strBody;
 if(!$mail->Send()){
   
}
else{
}
	?>
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
    
    	<center><img src="img/tichxanh.png" height="75px" width="75px"  /></center>
        <br />
        <center><tg>Cảm ơn quý khách đã mua hàng !</tg></center>
        <br />
        <center><button class="btn btn-light"><a href="home.php?Ten=<?php echo $_GET['Ten'] ?>&&id_KH=<?php echo $_GET['id_KH']; ?>&&abc">Tiếp tục mua hàng</a></button></center>
        <br />
        <br />
        <br />
        <br />
        <br />
        
    </div>
    	
  <?php
}
			}
			else{
		?>
        <div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">
        </div>
       
        <div class="col-xs-10 col-sm-10 col-md-10 col-lg-10 border">
        <p></p>
       	
        <center><tt>Thông Tin Mua Hàng</tt></center>
        <br/>
        <br />
                                         	
        <?php
		include_once("Controller/cTK(KH).php");
		$p=new cTK();
		$tk=mysql_fetch_assoc($p->xuat());
		?>
        <form action="#" method="post">
        	<div class="form-group row col-sm-12">
                                        	<label class="col-sm-7">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<gc>Tên người nhận:</gc></label>
                                            <div class="col-sm-5">
                                            	<input type="hidden" name="tdh" value="<?php echo "DHSP".$_GET['id_KH'].".".date("d-m-y H:i");?>" class="btn-outline-success"/>
                                            	<input type="text" name="a" value="<?php echo $_GET['Ten'];?>" class="btn-outline-success"/>
                                            </div>
                                            
                                        </div>
                                  
                                        <div class="form-group row col-sm-12">
                                        	<label class="col-sm-7">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<gc>Email:</gc></label>
                                            <div class="col-sm-5">
                                            	<input type="text" name="c" value="<?php echo $tk['Email'];?>"  class="btn-outline-success"/>
                                            </div>
                                            
                                        </div>
                                         <br />
                                        <br />
                                        <div class="form-group row col-sm-12">
                                        	<label class="col-sm-7">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<gc>SĐT liên hệ:</gc></label>
                                            <div class="col-sm-5">
                                            	<input type="text" name="d" value="<?php echo $tk['SoDienThoai'];?>"  class="btn-outline-success"/>
                                            </div>
                                            
                                        </div>
                                              <div class="form-group row col-sm-12">
                                        	<label class="col-sm-7">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<gc>Địa chỉ nhận hàng:</gc></label>
                                            <div class="col-sm-5">
                                            	<input type="text" name="b" value="<?php echo $tk['DiaChi'];?>" class="btn-outline-success" size="36"/>
                                            </div>
                                            
                                        </div>
                                       
                                       
                                        <div class="form-group row col-sm-12">
                                        <label class="col-sm-7">	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<gc>Ghi chú:</gc></label>
                                            <div class="col-sm-5">
                                            	<input type="text" name="e" size="36" placeholder="Lưu ý cho người bán ..." />
                                            </div>
                                            
                                        </div>
                                       
                                        <div class="col-xs-12 col-md-12 col-lg-12 col-lg-12">
                                            		<div class="col-xs-1 col-md-1 col-lg-1 col-lg-1">
                                                    </div>
                                                    <div class="col-xs-10 col-md-10 col-lg-10 col-lg-10 border">
                                                    <br />
                                                   <center>
                                                    <table class="table-bordered">
                                                    	<thead>	
                                                       
                                                        	<tr>
                                                            	<th colspan="12"><p></p><center><sp>Sản phẩm mua của bạn</sp></center><p></p></th>
                                                            </tr>
                                                          
                                                            <tr>
                                                            	<td><p></p><center><r>Tên Mỹ Phẩm</r></center><p></p></td>
                                                                <td><p></p><center><r>&nbsp;Ảnh&nbsp;</r></center><p></p></td>
                                                                <td><p></p><center><r>&nbsp;Giá Bán&nbsp;</r></center><p></p></td>
                                                                <td><p></p><center><r>&nbsp;Số Lượng&nbsp;</r></center><p></p></td>
                                                                <td><p></p><center><r>Thành Tiền</r></center><p></p></td>
                                                            </tr>
                                                            <?php 
															include_once("Controller/cSP.php");
															$p=new cSP();
															$hien=$p->xdh();
															while($tri=mysql_fetch_assoc($hien)){
															?>
                                                            <tr>
                                                            	<td><?php echo $tri['tenmypham'];?></td>
                                                                <td><p></p><center><img src="img/<?php echo $tri['anh'];?>" height="25px" width="25px;" /></center><p></p></td>
                                                                <td><center><?php
																
												$a=$tri['gia'];
												$b=$tri['giamgia'];
												$c=($a*$b)/100; 
												$d=$a-$c;
							
												 echo number_format($d,0,",",".")?> VNĐ</center></td>
                                                                 <td><center><?php echo $tri['soluong'];?></center></td>
                                                                  <td><center><?php echo number_format($tri['thanhtien'],0,",",".")?> VNĐ</center></td>
                                                            </tr>
                                                            
                                                           <?php
															}
														   ?>
                                                        </thead>
                                                    </table>
                                                    </center>
                                                   
                                                    <br />
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    
                                                    <tti>&nbsp;Tổng Tiền:</tti>&nbsp;&nbsp;<?php
													$tt=mysql_fetch_assoc($p->ttdh());
													echo "<tg>".number_format($tt['tongtien'],0,",",".")."&nbsp;VNĐ</tg>";
                                                 
													?>
                                                    <br />
                                                    <p></p>
                                                    <pt>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    Phương Thức Thanh Toán:&nbsp;&nbsp;&nbsp;
                       
                       
                       <input type="radio" name="f" value="Khi nhận hàng" />&nbsp;&nbsp;
                      
                       <img src="img/truct.png" height="40px" width="40px"/><br /></br></pt><br /></br></pt>
                       
                       
                                                    
                                                    </div>
                                                    <br />
                                                    <div class="col-xs-1 col-md-1 col-lg-1 col-lg-1">
                                                    </div>
                                                    <br />
                        
                                            </div>
                                       
                                        
                                        
                                         
                                         
                                        <div class="form-group row col-sm-12">
                                        	<label class="col-sm-10"></label>
                                            <div class="col-sm-2">
                                            <br />
                                            	<input type="submit" name="dh" value="Đặt Hàng" class="btn btn-warning"/>
                                            </div>
                                            
                                        </div>
        </form>
       
        </div>
        <div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">
        </div>
        </div>
        <br />
        <div class="footer col-xs-12 col-sm-12 col-md-12 col-ld-12 border">
	<div class="row">
    	<div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        	<center><img src="img/logo.png" height="100px" width="100px" /></center>
            <p> <nx>Về Chúng Tôi</nx> </p>
            <p> <nx>Giới thiệu:</nx><a href="#"> Nhà bán lẻ Mỹ Phẩm VIPU</a></p>
            <p> <nx>Số điện thoại:</nx> <a href="tel:0325927624">0325927624</a></p>
            <p> <nx>Email:</nx> <a href="mailto:phucable@gmail.com">phucable@gmail.com</a></p>
            <p> <nx>Địa chỉ: </nx><rf> ..., Phường xxx, Quận xxx, TP.HCM </rf> </p>
        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        ... ( Nội dung )
        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        ... ( Nội dung )
        </div>
    </div>
    
</div>
    
</div>
</div>
               
    </div>
    <br />
     <?php } ?> 
</div>

</body>
</html>
<?php
}
?>