<?php
if(isset($_GET['Ten'])&&isset($_GET['idTKNew'])){
	include_once("Controller/cTK(KH).php");
	$p=new cTK();
	$p->cnid();
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" href="css/bootstrap.css" />
<script type="text/javascript" src="js/jquery-3.6.0.min.js"></script>
<br />



<style>
 a:link{
	 color: #F60;
 }
 a: hover{
	 color: #F36;
 }
 .footer{
	background-color:#CCF;
	border-width:1px !important;
	border-color: #000 !important;
}
 
	#dn{
		background-color: #FFC;
	}
	dn{
		color:#966;
		font-size:28px;
		font-weight:300;
		font-family:"Comic Sans MS", cursive;
	}
	tb{
		font-size:22px;
		font-family:"Comic Sans MS", cursive;
		color:#F30;
	}
	pi{
		color:#F60;
		font-family:"Comic Sans MS", cursive;
		font-size:23px;
		font-weight:100;
	}
	a:hover{
		color:#F30;
	}
	
	
	n{
		color:#9F0;
	}
	
	th{
		background-color:#FCC;
	}
	
	nh{
		color:#F30;
	}
	#preview{
   width:600;
   height: 300px;
}
</style>
</head>

<body>
<div class="container h-600">
	<div class="row">
     <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 border">
           <div class="row">
           <div class="col-sm-12">
           		<div class="row">
                	<div class="col-xs-3 col-sm-3 col-md-3 col-ld-3">
                    	<center><h3><n><img src="img/logo.png"
                         height="300px" width="300px"/></n></h3></center>
                    </div>
                    <div class="col-xs-9 col-sm-9 col-md-9 col-ld-9">
                    	<center><h3><n><img src="img/bne.jpg" height="300px" width="100%"/></n></h3></center>
                    </div>   
                </div>
              </div>
         <p></p>
         
    	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        <center>
        <?php
		ob_start();
function ChuyenSangTiengVietKhongDau($str)
{
$str = preg_replace("/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|� �|ặ|ẳ|ẵ)/", 'a', $str);
$str = preg_replace("/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/", 'e', $str);
$str = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $str);
$str = preg_replace("/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|� �|ợ|ở|ỡ)/", 'o', $str);
$str = preg_replace("/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/", 'u', $str);
$str = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $str);
$str = preg_replace("/(đ)/", 'd', $str);
$str = preg_replace("/(À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|� �|Ặ|Ẳ|Ẵ)/", 'A', $str);
$str = preg_replace("/(È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ)/", 'E', $str);
$str = preg_replace("/(Ì|Í|Ị|Ỉ|Ĩ)/", 'I', $str);
$str = preg_replace("/(Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|� �|Ợ|Ở|Ỡ)/", 'O', $str);
$str = preg_replace("/(Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ)/", 'U', $str);
$str = preg_replace("/(Ỳ|Ý|Ỵ|Ỷ|Ỹ)/", 'Y', $str);
$str = preg_replace("/(Đ)/", 'Đ', $str);
$str = preg_replace("/( )/", '%20', $str);
return $str;
}
		if(isset($_POST['submit']))
		{
			$se=$_POST['se'];
			$mk=md5($_POST['pass']);
			    include_once("Controller/cTK(KH).php");
				$p=new cTK();
				$ktra=$p->KiemTraTKPass();
				$col=mysql_fetch_assoc($ktra);
				$ten=$col['Username'];
				$t=$ten;
				$b=utf8_decode($t);
				include_once("Controller/cTK(BH).php");
				$p=new cTKBH();
				$ktra1=$p->KiemTraTKPassBH();
				$col1=mysql_fetch_assoc($ktra1);
				$ten1=$col1['Username'];
				$t1=$ten1;
				$b1=utf8_decode($t1);
				$user=$col['User'];
				
				//Ship
				$ktra3=$p->KiemTraTKPassShip();
				$col3=mysql_fetch_assoc($ktra3);
				$ten3=$col3['Username'];
				$t3=$ten3;
				$b3=utf8_decode($t3);
				
				
				include_once("Controller/cTK(AD).php");
				$p=new cTKAD();
				$ktra2=$p->KiemTraTKPassAD();
				$col2=mysql_fetch_assoc($ktra2);
				$ten2=$col2['Username'];
				$t2=$ten2;
				$b2=utf8_decode($t2);
				$user=$col['User'];
				if(mysql_num_rows($ktra)==1){
					echo header("refresh:0,url='home.php?Ten=$b");
				}
				elseif(mysql_num_rows($ktra1)==1){
					echo header("refresh:0,url='admin.php?qlbdthoai&&Ten=$b1");
				}
				elseif(mysql_num_rows($ktra2)==1){
					echo header("refresh:0,url='admin.php?qlbdthoai&&Ten=$b2");
				}
				elseif(mysql_num_rows($ktra3)==1){
					echo header("refresh:0,url='ship.php?qlvc&&Ten=$b3");
				}
				elseif((!preg_match("/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})/",$se))&&(!preg_match("/[0-9]{10}/",$se))){
						echo "<script>alert('Email không đúng định dạng hoặc Số Điện Thoại là 10 số')</script>";
				}
				else{
					echo "<script>alert('Đăng nhập thất bại!')</script>";
				}
	
		}
		if(isset($_POST['dn'])){
				include_once("Controller/cTK(KH).php");
				$p=new cTK();
			    $kt=$p->KiemTraTKQR();
				$co=mysql_fetch_assoc($kt);
				$ten=$co['Username'];
				$tn=$ten;
				$b=utf8_decode($tn);
				include_once("Controller/cTK(BH).php");
				$p=new cTKBH();
				$kt1=$p->KiemTraTKQRBH();
				$r1=mysql_fetch_assoc($kt1);
				$ten1=$r1['Username'];
				$tn1=$ten1;
				$b1=utf8_decode($tn1);
				
				//Ship 
				$kt3=$p->KiemTraTKQRShip();
				$r3=mysql_fetch_assoc($kt3);
				$ten3=$r3['Username'];
				$tn3=$ten3;
				$b3=utf8_decode($tn3);
				
				include_once("Controller/cTK(AD).php");
				$p=new cTKAD();
				$kt2=$p->KiemTraTKQRAD();
				$r2=mysql_fetch_assoc($kt2);
				$ten2=$r2['Username'];
				$tn2=$ten2;
				$b2=utf8_decode($tn2);
				$user=$co['User'];
				if(mysql_num_rows($kt)==1){
					echo header("refresh:0,url='home.php?Ten=$b");
				}
				elseif(mysql_num_rows($kt1)==1){
					echo header("refresh:0,url='admin.php?qlbdthoai&&Ten=$b1");
				}
				elseif(mysql_num_rows($kt2)==1){
					echo header("refresh:0,url='admin.php?qlbdthoai&&Ten=$b2");
				}
				elseif(mysql_num_rows($kt3)==1){
					echo header("refresh:0,url='ship.php?qlvc&&Ten=$b3");
				}
				else{
					echo "<script>alert('Đăng nhập thất bại!')</script>";
				}
		}
		ob_end_flush();
		?>
        <br />
         <br />
        	<table class="table-bordered col-xs-8 col-sm-8 col-md-8 col-lg-8" >
            	<thead>
                <tr>
                <th colspan="8" id="dn"><p></p><center><dn>Đăng Nhập Tài Khoản</dn></center><p></p></th>
                </tr>
                 <tr>
                	<th colspan="4"><center><a href="SignIn.php?mk"><pi>Mật Khẩu</a>&nbsp;&nbsp;<img src="img/pass.jpg" height="50" width="50"/></pi></center></th>
                    <th colspan="4"><center><a href="SignIn.php?qr"><pi>Qrcode</a>&nbsp;&nbsp;<img src="img/qrc.png" height="50" width="50"/></pi></center></th>
                 </tr>
                 <tr>
                 <center>
                    <?php
						if(isset($_GET['mk'])){
							?>
                            <form action="#" method="post">
                            <td colspan="6"><br /><center>Email/Số Điện Thoại :  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text"  required="required" placeholder="abc@gmail.com|03xxxxxxxx"  name="se" class="b1"/><br /></center><br />
                           <center>Mật Khẩu :  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password"  required="required" placeholder="*********" name="pass" class="b1" /></center><br />
                             <br />
                             <center><input type="submit" name="submit" value="Đăng Nhập" class="btn-success" /></center>
                            <br /><br /></td>
                            
                          </form>
                           
                            <?php
						}
						elseif(isset($_GET['qr'])){
							?>
                            <td colspan="6">
                            <br />
                           <center><tb>Mở Ảnh QRCode Trên Điện Thoại Của Bạn Lên Để Quét</tb></center>
                           <br />
                          
                            	<video id="preview" width="100%"></video>
                                <form action="home.php" method="post">
                                <br />
                                <br />
                                <center><input type="hidden" name="a" id="text" size="35"  />
                               
                               
                               
                                <?php /* <input type="hidden" name="qr" size="35"  />
                                <input type="submit" name="su" value="OK" class="btn-info"  /></center>
                                </form>
                                 <br />
                                <?php 
								$b=$_GET['a'];
								$b1=strpos($b,";P:");
								$c=substr($b,2,$b1-2);
								$b2=strpos($b,";E:");
								$b3=strpos($b,";P:");
								$d=$b2-($b3+3);
								$d1=substr($b,$b3+3,$d);
								$d2=strpos($b,";SDT:");
								$e=$d2-($b2+3);
								$e1=substr($b,$b2+3,$e);
								$f1=substr($b,$d2+5,1000);
								?>
                              
                              <center>
                              <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">
                              <table class="table table-bordered">
                              	<thead>
                                <tr>
                                    	<td colspan="2"><center><tb>Thông Tin Của Bạn</tb></center></td>
                                        
                                    </tr>
                                	<tr>
                                    <form action="SignIn.php" method="post">
                                    	<td>&nbsp;&nbsp;Tên:</td>
                                        <td><center><input type="Name" name="Name" value="<?php echo utf8_decode($c); ?>"  /></center></td>
                                    </tr>
                                    <tr>
                                    	<td>&nbsp;&nbsp;Mật Khẩu:</td>
                                        <td><center><input type="text" name="Pass" value="<?php echo $d1; ?>"  /></center></td>
                                    </tr>
                                    <tr>
                                    	<td>&nbsp;&nbsp;Email:</td>
                                        <td><center><input type="text" name="Email" value="<?php echo $e1; ?>"/></center></td>
                                    </tr>
                                    <tr>
                                    	<td>&nbsp;&nbsp;Số Điện Thoại:</td>
                                        <td><center><input type="text" name="Phone" value="<?php echo $f1; ?>"  /></center></td>
                                    </tr>
                                     <tr>
                                    	<td colspan="2"><center><input type="submit" name="dn" value="Đăng Nhập" class="btn-success" /></center></td>*/ ?>
                                       </form> 
                                       </td>
                                    </tr>
                               
                              </center>
							  
                             
                              
                               
                                <br />
                                <br />
                            
                            <script type="text/javascript" src="instascan.min.js"></script>
                            <script src="https://rawgit.com/schmich/instascan-builds/master/instascan.min.js"></script>
<script type="text/javascript">
    var scanner = new Instascan.Scanner({ video: document.getElementById('preview'), scanPeriod: 5, mirror: false });
    scanner.addListener('scan',function(content){
        document.getElementById("text").value=content;
        window.location.href=content;
    });
    Instascan.Camera.getCameras().then(function (cameras){
        if(cameras.length>0){
            scanner.start(cameras[0]);
            $('[name="options"]').on('change',function(){
                if($(this).val()==1){
                    if(cameras[0]!=""){
                        scanner.start(cameras[0]);
                    }else{
                        alert('No Front camera found!');
                    }
                }else if($(this).val()==2){
                    if(cameras[1]!=""){
                        scanner.start(cameras[1]);
                    }else{
                        alert('No Back camera found!');
                    }
                }
            });
        }else{
            console.error('No cameras found.');
            alert('No cameras found.');
        }
    }).catch(function(e){
        console.error(e);
        alert(e);
    });
	</script>
                            
                            </td>
                            
                            <?php
							
						}
						else{
							?>
                            </form>
                             <form action="#" method="post">
                             <td colspan="6"><br /><center>Email/Số Điện Thoại :  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text"  required="required" placeholder="abc@gmail.com|03xxxxxxxx"  name="se"/></center><br />
                            <center>Mật Khẩu :  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password"  required="required" placeholder="*********" name="pass" /></center><br />
                             <br />
                             <center><input type="submit" name="submit" value="Đăng Nhập" class="btn-success" /></center>
                             
                            <br /><br /></td>
                            </form>
                            
                            <?php
						}
					?>
                  </center>
                  
                 </tr>
                 <tr>
                 	<td colspan="3">
                  		 <?php
						 	if(isset($_GET['Ten'])){
								?>
								<center><a href="SignUp.php?Ten=<?php echo $_GET['Ten']?>">Bạn chưa có tài khoản ?</a></center>
                                <?php
							}
							else{
						 ?>
                            	<center><a href="SignUp.php">Bạn chưa có tài khoản ?</a></center>
                         <?php
							}
						 ?>
                                
                            </td>
                            <td colspan="3">
                  
                            	<center><a href="Resetpass.php">Quên mật khẩu ?</a></center>
                                
                            </td>
                 </tr>
                </thead>
            </table>
       
        </center>
        <br />
        	
        </div>
    </div>
</div>
          <div class="footer col-xs-12 col-sm-12 col-md-12 col-ld-12 border">
	<div class="row">
    	<div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        	<center><img src="img/logo.png" height="100px" width="100px" /></center>
            <p> Về Chúng Tôi </p>
            <p> Giới thiệu:<a href="#"> Nhà bán lẻ Mỹ Phẩm VIPU</a></p>
            <p> Số điện thoại: <a href="tel:0325927624">0325927624</a></p>
            <p> Email: <a href="mailto:phucable@gmail.com">phucable@gmail.com</a></p>
            <p>Địa chỉ: Số nhà xxx, Đường xxx, Phường xxx, Quận xxx, TP.HCM </p>
        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        ... ( Nội dung )
        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        ... ( Nội dung )
        </div>
    </div>
</div>
</body>
</html>