<?php
session_start();
$_SESSION['re']=$_POST['re'];
$se=$_SESSION['re'];
$_SESSION['re']=time();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script type="text/javascript" src="js/jquery.zoom.min.js"></script>

<script src="https://unpkg.com/js-image-zoom@0.4.1/js-image-zoom.js" type="application/javascript"></script>
<title>Untitled Document</title>
<style>
tk{
	color:#C99;
	font-family:"Comic Sans MS", cursive;
	font-size:25px;
	
}
ps{
	color:#F33;
	font-size:18px;
}
table, th, td {
  border: 1px solid black;
}
</style>
</head>
<body>
<center>
<div class="container h-600">
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 border">
    <div class="row">
                	<div class="col-xs-2 col-sm-2 col-md-2 col-ld-2">
                    	<center><h3><n><img src="img/logo.png"
                         height="200px" width="200px"/></n></h3></center>
                    </div>
                    <div class="col-xs-10 col-sm-10 col-md-10 col-ld-10">
                    	<center><h3><n><img src="img/bne.jpg" height="265px" width="100%"/></n></h3></center>
                    </div>           
                 </div>
    	<div class="row">
                 	<div class="col-xs-3 col-sm-3 col-md-3 col-ld-3">
                    	
                    </div>  
                    <div class="col-xs-6 col-sm-6 col-md-6 col-ld-6 border">
                    <br />
                <?php    
                    if(isset($_POST['td'])){
								$re=$_POST['pe'];
								include_once("Controller/cTK(KH).php");
								$p=new cTK();
								$p->ResetP();
								echo "<script>alert('Thay đổi mật khẩu hoàn tất!')</script>";
								echo header("refresh:0,url='SignIn.php'");
							
							
								
								
							
                              

include "class.phpmailer.php"; // include the class name
$mail = new PHPMailer(); // create a new object
$mail->IsSMTP(); // enable SMTP
$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
$mail->SMTPAuth = true; // authentication enabled
$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for GMail
$mail->Host = "smtp.gmail.com";
$mail->Port = 465; // or 587
$mail->IsHTML(true);
$mail->Username = "phucable@gmail.com";
$mail->Password = "lvovhiwexdkmvkwb";
$mail->SetFrom("shop@gmail.com");
$mail->AddAddress($re);
$mail->Subject = "Website Shop Follo!";
$mail->Body = "<p style='color:#0CF;'>-Mật khẩu của bạn đã được Reset,bạn không tiết lộ ra bên ngoài !</p>
<p style='color:orange'>-Bạn vui lòng nhấn vào đây đăng nhập Website lại mật khẩu vừa thay đổi: <a href='http://localhost/PhoneX/SignIn.php'>http://localhost/PhoneX/SignIn.php</a></p>";
 if(!$mail->Send()){
    echo "Mailer Error: " . $mail->ErrorInfo;
}
else{
}
  
					}

						
						?>
                    	
                        <?php
						if(isset($_POST['su'])){
							$OTP=$_POST['OTP'];
							$numOTP=$_POST['numOTP'];
							$tgn=$_POST['tgn'];
							if($numOTP==$OTP){
								?>
                               <center><tk>Đổi lại mật khẩu ? <img src="img/cp.png" height="35px" width="35px" /></tk></center>
                               <br />
                       <form action="#" method="post">
                    	<center><ps>New Pass:&nbsp;&nbsp;<input type="password" name="p" required="required" /></ps></center>
                        <br />
                        <center><ps>Re-Pass:&nbsp;&nbsp;&nbsp;&nbsp;<input type="password" name="rp" required="required" /></ps></center>
                        <center><ps><input type="hidden" name="pe" value="<?php echo $se; ?>" required="required" /></ps></center>
                        <br />
                        
                        <center><input type="submit" name="td" value="OK" required="required"/></center>
                        <br />
                        <center><a href="SignIn.php">Tiếp tục đăng nhập &nbsp;<img src="img/bl.png" width="30" height="30"/></a></center></td>
                    </form>

                                <?php
							}
							elseif(($_SESSION['re']-$tgn)>60){
								echo "<script>alert('Mã OTP hết hiệu lực!')</script>";
								echo header("refresh:0,url='ReSetPass.php'");
							}
						else{
								echo "<script>alert('Mã OTP xác nhận không đúng!')</script>";
								echo header("refresh:0,url='ReSetPass.php'");
							}
							
						}
							
?>
                    </div>  
                    
                    <div class="col-xs-3 col-sm-3 col-md-3 col-ld-3">
                    	
                    </div>  
</div>
<br />
   <div class="footer col-xs-12 col-sm-12 col-md-12 col-ld-12 border">
	<div class="row">
    	<div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        <p></p>
        	<center><img src="img/logo.png" height="100px" width="100px" /></center>
            <p> <nx>Về Chúng Tôi</nx> </p>
            <p> <nx>Giới thiệu:</nx><a href="#"> Nhà bán lẻ Mỹ Phẩm VIPU</a></p>
            <p> <nx>Số điện thoại:</nx> <a href="tel:0325927624">0325927624</a></p>
            <p> <nx>Email:</nx> <a href="mailto:phucable@gmail.com">phucable@gmail.com</a></p>
            <p> <nx>Địa chỉ: </nx><rf> ..., Phường xxx, Quận xxx, TP.HCM </rf> </p>
        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        ... ( Nội dung )
        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        ... ( Nội dung )
        </div>
    </div>
    
</div>
                 
    </div>
</div>
</center>
</body>
</html>

<?php
/*
<center><table border='0.5px' width='100%'>

<tr style='background-color:#CFF;'>
<th>123</th>
<th>345</th>
</tr>
<td><center>123</center></td>
<td><center>345</center></td>
</tr>
</table></center>
*/
?>