<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
 /*
session_start();
include_once("Controller/cTK(KH).php");
$p=new cTK();
$qr=$p->KTTK();
if(mysql_num_rows($qr)==1){
	echo "<script>alert('Đăng nhập thành công')</script>";
	echo header("refresh:0,url='admin.php?home-qlbsach'");
}
else{
	echo "<script>alert('Đăng nhập thất bại!!!')</script>";
	echo header("refresh:0,url='dnhap.php'");
}
$qr=$p-> KTTK();
$cot=mysql_fetch_assoc($qr);
session_start();
if(isset($_REQUEST['submit'])){
$ma=$_POST['ma'];
$ten=$_REQUEST['name'];
$mk=$_REQUEST['pass'];
$mk1=md5($_REQUEST['pass']);
 	mk1=adminflowerAbc/	
if(($_SESSION["ten"]==$ten&&$_SESSION["pas"]==$mk&&$ma==$cot['idAdmin'])||($ten==$cot['UserName']&&$mk1==$cot['Password']&&$ma==$cot['idAdmin'])){
	echo "<script>alert('Đăng nhập thành công')</script>";
	echo header("refresh:0,url='admin.php?home'");
}
else{
	echo "<script>alert('Đăng nhập thất bại!!!')</script>";
	echo header("refresh:0,url='dnhap.php'");
}
}
else{
	echo "<script>alert('Sai url!!!')</script>";
	echo header("refresh:0,url='dnhap.php'");
}
*/
?>
</body>
</html>