<?php
session_start();
$_SESSION['pe']=$_POST['pe'];
$pe=$_SESSION['pe'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script type="text/javascript" src="js/jquery.zoom.min.js"></script>

<script src="https://unpkg.com/js-image-zoom@0.4.1/js-image-zoom.js" type="application/javascript"></script>
<title>Untitled Document</title>
<style>
tk{
	color:#C99;
	font-family:"Comic Sans MS", cursive;
	font-size:25px;
	
}
ps{
	color:#F33;
	font-size:18px;
}
gc{
	color:#36F;
}
</style>
</head>
<body>
<center>
<div class="container h-600">
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 border">
    <div class="row">
                	<div class="col-xs-2 col-sm-2 col-md-2 col-ld-2">
                    	<center><h3><n><img src="img/logo.png"
                         height="200px" width="200px"/></n></h3></center>
                    </div>
                    <div class="col-xs-10 col-sm-10 col-md-10 col-ld-10">
                    	<center><h3><n><img src="img/bne.jpg" height="265px" width="100%"/></n></h3></center>
                    </div>           
                 </div>
    	<div class="row">
                 	<div class="col-xs-3 col-sm-3 col-md-3 col-ld-3">
                    	
                    </div>  
                    <div class="col-xs-6 col-sm-6 col-md-6 col-ld-6 border">
                    <br />
                    	<center><tk>Nhập mã xác nhận OTP ? <img src="img/sic.png" height="35px" width="35px" /></tk></center>
                        <br />
                       
                        
                         <?php 
							if(isset($_POST['tim'])){
								include_once("Controller/cTK(KH).php");
								$p=new cTK();
								$cot=$p->TimTK();
								if(mysql_num_rows($cot)!=1){
									echo "<script>alert('SĐT/Email không thuộc tài khoản nào !!!')</script>";
									echo header("refresh:0,url='Resetpass.php'");
								}
								else{
// Function to generate OTP
function generateNumericOTP($n) {
      
    // Take a generator string which consist of
    // all numeric digits
    $generator = "1357902468";
  
    // Iterate for n-times and pick a single character
    // from generator and append it to $result
      
    // Login for generating a random character from generator
    //     ---generate a random number
    //     ---take modulus of same with length of generator (say i)
    //     ---append the character at place (i) from generator to result
  
    $result = "";
  
    for ($i = 1; $i <= $n; $i++) {
        $result .= substr($generator, (rand()%(strlen($generator))), 1);
    }
  
    // Return result
    return $result;
}
  
// Main program
$n = 6;
session_start();
$_SESSION['OTP']=generateNumericOTP($n);
$OTP=$_SESSION['OTP'];
$_SESSION['OTP']=time();
							
include "class.phpmailer.php"; // include the class name
$mail = new PHPMailer(); // create a new object
$mail->IsSMTP(); // enable SMTP
$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
$mail->SMTPAuth = true; // authentication enabled
$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for GMail
$mail->Host = "smtp.gmail.com";
$mail->Port = 465; // or 587
$mail->IsHTML(true);
$mail->Username = "phucable@gmail.com";
$mail->Password = "afbv blky ofzi vzsy";
$mail->SetFrom("shop@gmail.com");
$mail->AddAddress($pe);
$mail->Subject = "Website Shop VIPU!";
$mail->Body = "<p style='color:#03F;'>Mã OTP xác nhận của bạn là:&nbsp;<tb style='color:orange'>".$OTP."</tb> </p>";
 if(!$mail->Send()){
   
}
else{
}

// Authentication key
$authKey = "YOUR_AUTH_KEY";

// Also add muliple mobile numbers, separated by comma
$phoneNumber = $_POST['phoneno'];

// route4 sender id should be 6 characters long.
$senderId = "YOUR_SENDER_ID";

// Your message to send
$message = "Mã OTP của bạn là :".$OTP."";


									?>
                        
                        <p></p>
                        
                        <form action="RePass.php" method="post">
                    	<center><ps>Nhập Mã OTP:&nbsp;&nbsp;</ps><input type="text" name="OTP" /></ps>&nbsp; <br /></center>
                        
                        <center><ps></ps><input type="hidden" name="numOTP" value="<?php echo $OTP; ?>" /></ps>&nbsp; <br /></center>
                        <center><ps></ps><input type="hidden" name="tgn" value="<?php echo $_SESSION['OTP']; ?>" /></ps>&nbsp; <br /></center>
                       <?php 
					   ?>
                      
                       <center><ps></ps><input type="hidden" name="re" value="<?php echo $pe; ?>" /></ps>&nbsp; <br /></center>
                      
                        <gc>-Tài khoản của bạn được tìm thấy !<br/></gc>
                        <gc>-Mã OTP xác nhận vừa gửi đến Email/SĐT : <?php echo $pe;?> !</gc>
                        <br />
                        <br />
                        <p></p>
                       
                        <center><input type="submit" name="su" value="Xác nhận" required="required"/></center>
                        <br />
                    </form>
                    <?php
								}
								
							}
							
								?>
                    </div>  
                    
                    <div class="col-xs-3 col-sm-3 col-md-3 col-ld-3">
                    	
                    </div>  
</div>
<br />
                        <center><a href="Resetpass.php"><img src="img/back.jpg" height="35px" width="35px" /></a></center>
                        <br />
<br />
   <div class="footer col-xs-12 col-sm-12 col-md-12 col-ld-12 border">
	<div class="row">
    	<div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        <p></p>
        	<center><img src="img/logo.png" height="100px" width="100px" /></center>
            <p> <nx>Về Chúng Tôi</nx> </p>
            <p> <nx>Giới thiệu:</nx><a href="#"> Nhà bán lẻ Mỹ Phẩm VIPU</a></p>
            <p> <nx>Số điện thoại:</nx> <a href="tel:0325927624">0325927624</a></p>
            <p> <nx>Email:</nx> <a href="mailto:phucable@gmail.com">phucable@gmail.com</a></p>
            <p> <nx>Địa chỉ: </nx><rf> ..., Phường xxx, Quận xxx, TP.HCM </rf> </p>
        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        ... ( Nội dung )
        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        ... ( Nội dung )
        </div>
    </div>
    
</div>
                 
    </div>
</div>
</center>
</body>
</html>