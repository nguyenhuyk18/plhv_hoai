<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" href="css/bootstrap.css" />
<br />

<style>
	#dk{
		background-color:#CFF;
	}
	h3{
		color:#696;
		font-weight:400;
		font-family:"Comic Sans MS", cursive;
	}
	
	n{
		color:#9F0;
	}
	
	th{
		background-color: #FCC !important;
	}
	
	nh{
		color:#F30;
	}
	.footer{
	background-color:#CCF;
	border-width:1px !important;
	border-color: #000 !important;
}
</style>
</head>

<body
</div class="container h-600">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
         <div class="row">
         <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 border">
           <div class="row">
           <div class="col-sm-12">
           		<div class="row">
                	<div class="col-xs-2 col-sm-2 col-md-2 col-ld-2">
                    	<center><h3><n><a href="http://localhost/MyPham/home.php"><img src="img/logo.png"
                         height="200px" width="200px"/></a></n></h3></center>
                    </div>
                    <div class="col-xs-10 col-sm-10 col-md-10 col-ld-10">
                    	<center><h3><n><img src="img/bne.jpg" height="265px" width="100%"/></n></h3></center>
                    </div>     
                </div>
              </div>
         <p></p>
         </div>
         <div class="row">
         <div class="col-sm-3">
         </div>
         <div class="col-sm-6">
         <?php 
		 include_once("Controller/cTK(KH).php");
		 if(isset($_POST['su'])){
			 $a=$_POST['name'];
			 $b=$_POST['pass'];
			 $c=$_POST['email'];
			 $d=$_POST['pic'];
			 $e=$_POST['repass'];
			 $f=$_POST['phone'];
			 $dc=$_POST['dc'];
			 $p=new cTK();
			 $ttt=$p->KTTKTT();
			 if($b!=$e){
				 echo "<script>alert('Mật khẩu nhập lại không khớp!')</script>";
			 }
			 elseif(mysql_num_rows($ttt)>0){
				echo "<script>alert('Tên tài khoản đã tồn tại!')</script>";
			
			 }
			 elseif(!preg_match("/^[A-Za-z{\\sÁàáạã_-]{2,25}/",$a)){
					echo "<script>alert('Họ và tên chưa đúng')</script>";
				}
			 elseif(!preg_match("/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})/",$c)){
					echo "<script>alert('Email không đúng định dạng')</script>";
				}
			 elseif(!preg_match("/[0-9]{10}/",$f)){
				 echo "<script>alert('Số Điện Thoại là 10 số')</script>";
			 }
			 elseif(!preg_match("/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/"
			 ,$b)){
				echo "<script>alert('Mật khẩu có 8 ký tự gồm chữ cái in hoa và in thường')</script>";
			 }
			 elseif($a == $b){
				echo "<script>alert('Tên đăng nhập và mật khẩu không được trùng nhau')</script>";
			 }
			 else{
			 $p=new cTK();
			 $kq=$p->themtk();

			 if($kq==1){
				
				 echo "<script>alert('Đăng ký thành công!')</script>";
			 }
			 }
			
			/* 
			echo "<pre>" ;
			var_dump($_POST);
			echo "</pre>";
			*/
			 
		 }
		 elseif(isset($_POST['Ten'])){
		 include_once("Controller/cSP.php");
		  $a=$_POST['name'];
			 $b=$_POST['pass'];
			 $c=$_POST['email'];
			 $d=$_POST['pic'];
			 $e=$_POST['repass'];
			 $f=$_POST['phone'];
			 $dc=$_POST['dc'];
			 $p=new cTK();
			 $ttt=$p->KTTKTT();
			 if($b!=$e){
				 echo "<script>alert('Mật khẩu nhập lại không khớp!')</script>";
			 }
			 elseif(mysql_num_rows($ttt)>0){
				echo "<script>alert('Tên tài khoản đã tồn tại!')</script>";
			
			 }
			 elseif(!preg_match("/^[A-Za-z{\\sÁàáạã_-]{2,25}/",$a)){
					echo "<script>alert('Họ và tên chưa đúng')</script>";
				}
			 elseif(!preg_match("/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})/",$c)){
					echo "<script>alert('Email không đúng định dạng')</script>";
				}
			 elseif(!preg_match("/[0-9]{10}/",$f)){
				 echo "<script>alert('Số Điện Thoại là 10 số')</script>";
			 }
			 elseif(!preg_match("/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/"
			 ,$b)){
				echo "<script>alert('Mật khẩu có 8 ký tự gồm chữ cái in hoa và in thường')</script>";
			 }
			 elseif($a == $b){
				echo "<script>alert('Tên đăng nhập và mật khẩu không được trùng nhau')</script>";
			 }
			 else{
			 $p=new cTK();
			 $kq=$p->themtk();

			 if($kq==1){
				
				 echo "<script>alert('Đăng ký thành công!')</script>";
			 }
			 }
		 }
		 
		 
		
		 ?>
         <?php 
		 include_once("phpqrcode/qrlib.php");
		 $PNG_TEMP_DIR='qrcodepic/';
		 if(!file_exists($PNG_TEMP_DIR))
		 	mkdir($PNG_TEMP_DIR);
			
			$filename=$PNG_TEMP_DIR.date('d-m-y').'-png';
			if(isset($_POST['su'])){
				$codeString="home.php?Ten=".utf8_decode($_POST['name']);
				
				$filename=$PNG_TEMP_DIR.date('d-m-y').'-'.md5($codeString).'.png';
				
				QRCODE::png($codeString,$filename);
				
				
			}
			
		 	
		 ?>
         <form action="#" method="POST" enctype="multipart/form-data">
         <br />
         <table class="table table-bordered">
         	<thead>
            	<tr>
       <th colspan="2" id="dk"><center><h3><nh>Đăng Ký&nbsp;&nbsp;<img src="img/pass.jpg" height="50" width="50" /></nh></h3></center></th>
          		<tr>
                <tr>
                	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Họ Tên:</td>
                    <td><center><input class="form-control" type="text" name="name" value="<?php echo $a ?>" required="required"/></center></td>
                </tr>
                <tr>
                	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mật Khẩu:</td>
                    <td><center><input class="form-control" type="password" name="pass"  value="<?php echo $b ?>" required="required"/></center></td>
                </tr>
                <tr>
                	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nhập Lại Pass:</td>
                    <td><center><input class="form-control" type="password" name="repass"  value="<?php echo $e ?>" required="required"/></center></td>
                </tr>
                <tr>
                	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email:</td>
                    <td><center><input class="form-control" type="text" name="email"  value="<?php echo $c ?>" required="required"/></center></td>
                </tr>
                <tr>
                	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phone:</td>
                    <td><center><input class="form-control" type="text" name="phone"  value="<?php echo $f ?>" required="required"/></center></td>
                </tr>
                <tr>
                	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Địa Chỉ:</td>
                    <td><center><input class="form-control" type="text" name="dc"  value="<?php echo $dc ?>" required="required"/></center></td>
                </tr>
                <tr>
                	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ảnh Đại Diện:</td>
                    <td><center><input type="file" name="pic"  value="<?php echo $d ?>" required="required"/></center></td>
                </tr>
                   <tr>
                   <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;QRCode:</td>
                   <td><center>
                   		<?php 
						$a=$filename;
						$b=substr($a,5);
						?>
                    	<?php /* <input type="hidden" name="qrcode" value="<?php echo $b  ?>"/> */ ?>
                        
                        <input type="hidden" name="user" value="1" />
				   <?php 
				  if($kq!=1){
					  echo 'Chưa có thông tin tạo mã QRCode';
					 
					  
				  }
				  else{
				   if($codeString!=null)
				   {
					   
					   echo '<a href="taixuong.php?fu='.$filename . '"><img src="'.$PNG_TEMP_DIR.basename($filename).'"/></a>&nbsp;&nbsp;';
				   }
				   else{
					   echo 'Chưa có thông tin tạo mã QRCode';
				   }
				  }
				   ?>
                  </center></td>
                  </tr>
                   <tr>
                <td colspan="2"><center>
              
                                
				<input type="hidden" name="Ten" value="<?php echo $_GET['Ten']?>" />
                <input type="submit" name="su" value="Đăng Ký" class="btn-info"/></center>
                </form>
                </tr>
                <tr>
                <td colspan="6">
                <?php
						 	if(isset($_GET['Ten'])){
								$p=new cTK();
								$cot23=mysql_fetch_assoc($p->xuatid());
							
								?>
								<center><a href="SignIn.php?Ten=<?php echo $_GET['Ten'];?>&&idTKNew=<?php echo $cot23['id_TK']; ?>">Tiếp tục đăng nhập &nbsp;<img src="img/bl.png" width="30" height="30"/></a></center>
                                <?php
							}
							else{
						 ?>
                <center><a href="SignIn.php">Tiếp tục đăng nhập &nbsp;<img src="img/bl.png" width="30" height="30"/></a></center></td>
                <?php
							}
				?>
                </tr>
               </thead>
           </table>
        </div>
        <div class="col-sm-3">
        </div>
        </div>
        </div>
        <div class="footer col-xs-12 col-sm-12 col-md-12 col-ld-12 border">
	<div class="row">
    	<div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        	<center><img src="img/logo.png" height="100px" width="100px" /></center>
            <p> Về Chúng Tôi </p>
            <p> Giới thiệu:<a href="#"> Nhà bán lẻ Mỹ Phẩm VIPU</a></p>
            <p> Số điện thoại: <a href="tel:0325927624">0325927624</a></p>
            <p> Email: <a href="mailto:phucable@gmail.com">phucable@gmail.com</a></p>
            <p>Địa chỉ: Số nhà xxx, Đường xxx, Phường xxx, Quận xxx, TP.HCM </p>
        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        ... ( Nội dung )
        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        ... ( Nội dung )
        </div>
    </div>
</div>
        
        
    </div>

</body>
</html>