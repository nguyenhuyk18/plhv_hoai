<?php
if(isset($_GET['tiepnhan'])){
	include("Controller/cTK(BH).php");
	$p=new cTKBH();
	$p->tiepnhangh();
	echo header("refresh:0,url='ship.php?dhang&&Ten=".$_GET['Ten']."'");
}
elseif(isset($_GET['giaohang'])){
	include("Controller/cTK(BH).php");
	$p=new cTKBH();
	$p->hoantatgiaohang();
	echo header("refresh:0,url='ship.php?dhang&&Ten=".$_GET['Ten']."'");
}
elseif(isset($_GET['xnthu'])){
	include("Controller/cTK(BH).php");
	$p=new cTKBH();
	$p->them();
	$p->sua();
	$p->sua1();
	echo header("refresh:0,url='ship.php?tti&&Ten=".$_GET['Ten']."'");
	
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script type="text/javascript" src="js/jquery.zoom.min.js"></script>

<script src="https://unpkg.com/js-image-zoom@0.4.1/js-image-zoom.js" type="application/javascript"></script>
<title>Trang Giao Vận</title>
<style>
th{
	color:#939;
}
hts{
	color:#060;
}
xci{
	color:#F63;
}
ay{
	color:#FF9;
}
ht{
	color:#C66;
	font-size:16px;
}
tt{
	color:#C9F;
	font-size:19px;
	font-weight:200;
}
rr{
	color:#C99;
	font-size:18px;
	font-weight:200;
}
tn{
	color:#FFC;
}
xe{
	color:#FF0;
}
tti{
	color:#99C;
	font-size:25px;
}
#slideshow {
   overflow: hidden;
   height: 400px;
   width: 1120px;
   margin: 0 auto;
 }
.slide-wrapper {
   width: 5000px;
   -webkit-animation: slide 8s ease infinite;
 }
.slide {
   float: left;
   height: 400px;
   width: 1120px;
 }
 
@-webkit-keyframes slide {
   20% {margin-left: 0px;}
   30% {margin-left: -1120px;}
   50% {margin-left: -1120px;}
   60% {margin-left: -2290px;}
   80% {margin-left: -2290px;}
 }
</style>
</head>

<body>
<div class="container h-600">
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 border">
    <div class="row">
                	<div class="col-xs-2 col-sm-2 col-md-2 col-ld-2">
                    	<center><h3><n><img src="img/lgo.png"
                         height="200px" width="200px"/></n></h3></center>
                    </div>
                    <div class="col-xs-10 col-sm-10 col-md-10 col-ld-10">
                    	<center><h3><n><img src="img/banner.jpg" height="265px" width="100%"/></n></h3></center>
                    </div>           
                 </div>
    	<div class="row">
                 	&nbsp;&nbsp;<a href="ship.php?qlvc&&Ten=<?php echo $_GET['Ten'] ?>"><img src="img/nha.jpg" height="45px" width="40px"/>&nbsp;<center><m>Trang chủ</m></center></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="ship.php?dhang&&Ten=<?php echo $_GET['Ten'] ?>"><img src="img/dhang.jfif" height="45px" width="40px"/>&nbsp;<center><m>Đơn Hàng</m></center></a>&nbsp;&nbsp;&nbsp;<?php
					include_once("Controller/cTK(BH).php");
					$p=new cTKBH();
					$sd=$p->ttShip();
					$t=mysql_fetch_assoc($sd);
					
					
					?>
                    &nbsp;&nbsp;
                    <a href="ship.php?Ten=<?php echo $_GET['Ten']; ?>&&tti"><img src="img/thutien.jfif " height="45px" width="45px" class="rounded-circle" /><center><m>Thu Tiền</m></center></a>&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="ship.php?qlvc&&Ten=<?php echo $_GET['Ten'] ?>&&tt"><img src="img/<?php echo $t['Anh'] ?> " height="45px" width="45px" class="rounded-circle" /><center><m><?php echo $_GET['Ten']; ?></m></center></a>
           
                 
    </div>
    <br />
            
           
           <div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ">
    <div class="row">
                	<div class="col-xs-2 col-sm-2 col-md-2 col-ld-2 ">
                    </div>
                    <br />
                    <?php
					if(isset($_GET['tt'])){
					?>
                    <div class="col-xs-8 col-sm-8 col-md-8 col-ld-8 border">
                    <p></p>
                    
                    <center><tti>Thông Tin Cá Nhân</tti></center>
                    <p></p>
                    <?php
					$t=mysql_fetch_assoc($p->ttShip());
					?>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<ht>Họ Tên :</ht>  <?php echo $t['Username']?>
                    <p></p>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<ht>Địa Chỉ :</ht>  <?php echo $t['DiaChi']?>
                    <p></p>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<ht>Số Điện Thoại :</ht>  <?php echo $t['SoDienThoai']?>
                    <p></p>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<ht>Email :</ht>  <?php echo $t['Email']?>
                    <p></p>
                    <center><img src="img/<?php echo $t['Anh'] ?>" height="40px" width="40px" class="rounded-circle" /></center>
                    <p></p>
                    
                    </div>
                    <?php
					}
					elseif(isset($_GET['tti'])||isset($_GET['xnthu'])){
						?>
                        <div class="col-xs-8 col-sm-8 col-md-8 col-ld-8 border">
                    <p></p>
                    
                    <center><tti>Bảng Thu Tiền</tti></center>
                    <p></p>
                    <table class="table table-bordered col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    	<thead>
                        
                        <tr>
                        	<th><center>STT</center></th>
                            <th><center>Tên Khách Hàng</center></th>
                            <th><center>Tên Đơn Hàng</center></th>
                            <th><center>Tổng Tiền</center></th>
                            <th><center>Số Tiền Phải Thu </center></th>
                            <th><center>Xác Nhận</center></th>
                        </tr>
                        <?php 
						$de=$p->xuatdonhangthutien();
						$a=1;
						while($d=mysql_fetch_assoc($de)){
						?>
                        <tr>
                        	<td><center><?php echo $a++;?></center></td>
                            <td><center><?php echo $d['tenkhac']?></center></td>
                            <td><center><?php echo $d['tendonhang']?></center></td>
                            <td><center><?php echo number_format($d['tongtien'],0)?> VNĐ</center></td>
                           	<form>
                            <input type="hidden" name="Ten" value="<?php echo $_GET['Ten']?>" />
                            <input type="hidden" name="tenkhac" value="<?php echo $d['tenkhac']?>" />
                            <input type="hidden" name="tendonhang" value="<?php echo $d['tendonhang']?>" />
                            <input type="hidden" name="tongtienthu" value="<?php echo $d['tongtien']?>" />
                            <input type="hidden" name="sotientra" value="<?php echo $d['tongtien']; ?>" />
                            	<td><center><?php echo number_format($d['tongtien'])?>&nbsp;VNĐ</center></td>
                            	<td><center><input type="submit" value="OK" name="xnthu" class="btn-success" /></center></td>
                            </form>
                        </tr>
                        <?php
						}
						$a++;
						?>
                        </thead>
                    </table>
                    
                    <p></p>
                    
                    </div>
                        <?php
					}
					elseif(isset($_GET['xemct'])){
						?>
                        <div class="col-xs-8 col-sm-8 col-md-8 col-ld-8 border">
                    <p></p>
                    
                    <center><tti>Chi Tiết Đơn Hàng</tti></center>
                    <p></p>
                    <?php
					$cot=$p->xemdhangct();
					$x=mysql_fetch_assoc($cot);
					?>
                    &nbsp;<hts>Họ Tên Người Nhận :</hts> <xci><?php 
					echo $x['tenkhac']?></xci><p></p>
                    &nbsp;<hts>Số Điện Thoại :</hts> <xci><?php 
					echo $x['tenkhac']?></xci><p></p>
                    &nbsp;<hts>Địa Chỉ Nhận Hàng:</hts> <xci><?php 
					echo $x['diachi']?></xci><p></p>
                    &nbsp;<hts>Lời Nhắn:</hts> <xci><?php 
					echo $x['ghichu']?></xci>
                    <p></p>
                    <table class="table table-bordered col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    	<thead>
                        	<tr>
                            	<th><center>STT</center></th>
                                <th><center>Tên Sản Phẩm</center></th>
                                <th><center>Ảnh</center></th>
                                <th><center>Số Lượng</center></th>
                                <th><center>Thành Tiền</center></th>
                            	
                            </tr>
                            <?php
							$sd=$p->xemdhangct();
							$tt=mysql_fetch_assoc($p->tongtien());
							$a=1;
							while($cr=mysql_fetch_assoc($sd)){
							
							?>
                            <tr>
                            	<td><center><?php echo $a++;?></center></td>
                                <td><center><?php echo $cr['tendt']?></center></td>
                                <td><center><img src="img/<?php echo $cr['anh']?>" height="50px" width="50px" /></center></td>
                                <td><center>x <?php echo $cr['soluong']?></center></td>
                                <td><center><?php echo number_format($cr['thanhtien'],0)?>&nbsp;VNĐ</center></td>
                            </tr>
                            
                            <?php
							}
							$a++;
							?>
                            <tr>
                            	<th colspan="3" class="btn-light"></th>
                                <th colspan="2"><center><tt>Tổng Tiền:</tt> <rr><?php echo number_format($tt['tongtien'],0)?> VNĐ</rr></center></th>
                            </tr>
                        </thead>
                    </table>
                    <p></p>
                    <center><a href="ship.php?Ten=<?php echo $_GET['Ten'];?>&&dhang"><img src="img/back.jpg" height="40px" width="40px" /></a></center>
                    <p></p>
                    </div>
                        <?php
					}
					
					elseif(isset($_GET['dhang'])||isset($_GET['tiepnhan'])||isset($_GET['giaohang'])){
						?>
                        <div class="col-xs-8 col-sm-8 col-md-8 col-ld-8 border">
                    
                    <p></p>
                    <center><tti>Thông Tin Đơn Hàng</tti></center>
                    <p></p>
                    
                   
                    <table class="table table-bordered  col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    	<thead>
                        	<tr>
                            	<th><center>STT</center></th>
                                <th><center>Tên Đơn Hàng</center></th>
                                <th><center>Tên Khách Hàng</center></th>
                                <th><center>Tình Trạng</center></th>
                                <th><center>Chi Tiết</center></th>
                                <th><center>Trạng Thái</center></th>
                           	</tr>
                            <?php
							$a=1;
							$cot=$p->xemdhang();
							while($c=mysql_fetch_assoc($cot)){
							?>
                            <tr>
                            	<td><center><?php echo $a++; ?></center></td>
                                <td><center><?php echo $c['tendonhang'] ?></center></td>
                                <td><center><?php echo $c['tenkhac'] ?></center></td>
                                
                                <td><center><?php if($c['tinhtrang']==0){
									echo "Chưa Thanh Toán";
								}
								else{
									echo "Đã Thu Tiền";
								}?></center></td>
                                <td><center><button class="btn-info"><a href="ship.php?Ten=<?php echo $_GET['Ten']?>&&tendonhang=<?php echo $c['tendonhang']?>&&xemct"><xe>Xem</xe></a></button></center></td>
                                <td><center><?php if($c['trangthai']==2){
									?>
                                    <button class="btn-warning"><a href="ship.php?Ten=<?php echo $_GET['Ten']?>&&tendonhang=<?php echo $c['tendonhang'];?>&&tiepnhan"><tn>Tiếp Nhận</tn></a></button>
                                    <?php
								}
								elseif($c['trangthai']==3){
									?>
									<button class="btn-secondary"><a href="ship.php?Ten=<?php echo $_GET['Ten']?>&&tendonhang=<?php echo $c['tendonhang'];?>&&giaohang"><tn>Đang Giao</tn></a></button>
                                    <?php
									
								}
								elseif($c['trangthai']==4){
									?>
                                    <button class="btn-success">Đã Giao</button>
                                    <?php
								}?></center></td>
                            </tr>
                            <?php
							}
							$a++;
							?>
                        </thead>
                    </table>
                    <p></p>
                    
                    </div>
                        <?php
					}
					?>
                    
                    <div class="col-xs-2 col-sm-2 col-md-2 col-ld-2 ">
                    </div>
                  </div>
                  </div>
                  </div>
                  <br />
           
          
</div>
<br />
<br />
</body>
<script type="text/javascript" src="https://itexpress.vn/API/js/noel.js"></script>
</html>