<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Follo-Shop bán điện thoại chính hãng</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<title>Untitled Document</title>
<style>
h3{
	color:#F03;
	font-family:cursive;
}
sl{
	color:#F66;
}
tm{
	color:#09C;
}
h4{
	font-family:"Comic Sans MS", cursive;
	color:#FC0;
}
.rounded-circle{
	background-color:#9C0;
}
th{
	background-color:#FF9;
}

x{
	color:green;
}

s{
	color:#F00;
}
r{
	color:#FFF;
}

l{
	color:#F03;
}

m{
	color:#3CF;
}

n{
	color:#9F0;
}

p{
	color:#F30;
}

v{
	color:#C90;
}
.footer{
	background-color:#CCF;
	border-width:1px !important;
	border-color: #000 !important;
}

t{
	color:#CC0;
}
z{
	color:#9CC;
}
kh{
	color:#CF3;
}
a:link{
	color:#000;
}
li{
	list-style-type:none;
	text-decoration:none;
}
.header{
	  padding: 10px 16px;
}
.content {
  padding: 16px;
}
.sticky {
  position:fixed;
  top: 0px;
  padding-top:15px;
  left:152px;
  width:79.73%;
  height:100px;
  z-index:1;
  background-color:rgba(255,255,255,0.92);
  box-shadow:0.1px 0.1px 0.1px yellow;
}
 img {
  image-rendering: pixelated;
  position:relative;
}
<script>
window.onscroll = function() 
{myFunction()};

var header = document.getElementById("myHeader");

var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset < sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
</script>
</style>
</head>

<body>
<div class="container h-600">
	<div class="row">
    	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        	<div class="row">
                	<div class="col-xs-2 col-sm-2 col-md-2 col-ld-2">
                    	<center><h3><n><img src="img/logo.png"
                         height="200px" width="200px"/></n></h3></center>
                    </div>
                    <div class="col-xs-10 col-sm-10 col-md-10 col-ld-10">
                    	<center><h3><n><img src="img/bne.jpg" height="265px" width="100%"/></n></h3></center>
                    </div>       
             </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        <div class="row p-2">
           <div class="row "><?php /* header" id="Follo" */?>
           	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="home.php?Ten=<?php echo $_GET['Ten']; ?>&&hm"><center><img src="img/nha.jpg" height="40px" width="40px"/></center>
            <center>Home</center></a>
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             <?php /*?>
            <a href="dnhap.php"><center><img src="img/ad.png" height="40px" width="40px"/></center>
             <center>Admin</center></a>
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
       		 <a href="home.php?vitri"><center><img src="img/map1.jpg" height="40px" width="40px"/></center>
             <center>Vị trí</center></a>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <?php */?>
         </div>

        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<?php
					
                        include_once("View/vCart.php");
						
                    ?>
                 <form>
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-ld-12">
                                    	<div class="table">
                                        <center>
                                        <table class="col-xs-12 col-sm-12 col-md-12 col-ld-12">
                                        	<thead>
                                            <tr>
                                            	<th><center><p>STT</p></center></th>
                                            	<th><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tên Mỹ Phẩm</p></th>
                                                <th><center><p>Ảnh</p></center></th>
                                                <th><center><p>Giá Bán</p></center></th>
                                                <th><center><p>Số lượng</p></center></th>
                                                <th><center><p>Thành tiền</p></center></th>
                                                <th><center><p>Chi tiết</p></center></th>
                                                <th><center><p>Xóa</p></center></th>

                                             </tr>
                                             <tr>
                                             	<?php
												 include_once("Controller/cSP.php");
												 $p=new cSP();
												 if(preg_match("/^user[0-9]{1,15}/",$_GET['Ten'])){
													 $hien1=$p->Xemghvd();
													 $hien1=$p->tkvd();
												 }
												 else{
											     $hien1=$p->Xemgh();
												 $hien1=$p->tk();
												 }
												 
												 if($hien1){
													 $i=1;
													 while($cot=mysql_fetch_assoc($hien1)){
												     if($tinh==0){
													 echo "<tr>";}
												?>
                                                <td><center><br /><?php echo $i++; ?></center></td>
                                                <td><br />
                                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                
												<?php echo $cot['tenmypham']?></td>
                                                <td><center><?php echo '<img src="img/'.$cot['anh'].'"height="75px"; width="85px";'?></center></td>
                                                 <?php
												$a=$cot['gia'];
												$b=$cot['giamgia'];
												$c=($a*$b)/100; 
												$d=$a-$c;
							
												?>
                                                <td><center><br /><?php echo number_format($d,0)?></center></td>
                                                <td><center><br />
                                                <form action="#" method="get">
                                                
   												  <sl><select name="sl"  onchange="window.location.href=this.value;">
                                               
                                                		<option><?php echo $e=$cot['soluong']?></option> 
                                                        <?php echo $tk=$cot['tonkho'];?>
                                                    <?php for($a=1;$a<=$tk;$a++){?>          
                                                        <option value="giohang.php?Ten=<?php echo $_GET['Ten'];?>&&id_KH=<?php echo $_GET['id_KH']?>&&id=<?php echo $cot['id_giohang']?>&&sl=<?php echo $a; ?>" ><?php echo  $a; ?></option>;
      												<?php } ?>
                                                        
                                                   </select></sl>
                                                  
                                                   
                               <input type="hidden" name="Ten" value="<?php echo $_GET['Ten'];?>" size="1"/>
                               
							   <input type="hidden" name="id_KH" value="<?php echo $_GET['id_KH'];?>" size="1"/>	
                               
                               <input type="hidden" name="id" value="<?php echo $cot['id_giohang']?>" size="1"/>	
                               
                                                &nbsp;&nbsp;
                                                </center>
                                                
                                              
                                                </form>	
                                                
                                                </td>
                                               										
                                                <?php $f=$d*$e; ?>
                                                <td><center><br /><?php echo number_format($f,0) ?>đ
                                               <form action="#" method="GET">
                                             <input type="hidden" name="ma" value="<?php echo $cot['id_giohang']?>" size="1"/>
                                                
                                                <br />
                                                </center>
                                                </td>
                                                <td><p></p><center>
                                                <a href="home.php?chitiet&&Ten=<?php echo $_GET['Ten']; ?>&&id=<?php echo $cot['id_mypham']?>"><img src="img/cm.png" height="30px" width="40px" /></a></center>
                                                </td>
                                                <td><center><p></p>
                                          <input type="hidden" name="Ten" value="<?php echo $_GET['Ten'] ?>"/>
                                          <input type="hidden" name="id_KH" value="<?php echo $_GET['id_KH'] ?>"/>
                                          <input type="image" src="img/del.png" height="25px" width="25px" name="submit"/></p>
                                               </form></center></td>
                                                <?php
												$tinh++;
												if($tinh=1){
													echo "</tr>";
												}
												   
											 		 }
													 $i++;
												 }
											 ?>
											
                                             </tr>
                                             <tr colspan="9">
                                             	<td colspan="2">
                                                 	<form action="#" method="get">
                                           <input type="hidden" name="Ten" value="<?php echo $_GET['Ten'] ?>"/>
                                           <input type="hidden" name="id_KH" value="<?php 
										   if(preg_match("/^user[0-9]{1,15}/",$_GET['Ten'])){
											   echo $_GET['Ten'];
										   }
										   else{
											   echo $_GET['id_KH'];
										   }?>"/>
                                           <input type="submit" name="submit" value="Xóa Tất Cả" class="btn-danger"/>
                                           
                                           			</form>
                                                 </td>
                                                 <td colspan="10">
                                                    
                                             <?php
											 include_once("Controller/cSP.php");
											 $p=new cSP();
											 if(preg_match("/^user[0-9]{1,15}/",$_GET['Ten'])){
												 $hien=$p->ttienvd();	
											 }
											 else{
												 $hien=$p->ttien();	
											 }
											 while($cot=mysql_fetch_assoc($hien)){										 
											 ?>
<p align="right"><strong><z>Tổng tiền:</z></strong>&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" value="<?php echo number_format($cot['tongtien'],0)."&nbsp;VNĐ" ?>" disabled="disabled" size="13" class="btn btn-info"/></p>
												</td>
                                
                              				<?php
											 }
											?>
                                             </tr>
                                            </thead>
                                        </table>
                                        </center>
                                        </div>
                                        <br />
                                        <p></p>
                                        
                                       
                                        <br />
                                        <br />
                                        <?php 
										$p=new cSP();
										$dem=mysql_fetch_assoc($p->knut());
										$dem1=mysql_fetch_assoc($p->knutvl());
									
										if(preg_match("/^user[0-9]{1,15}/",$_GET['Ten'])){
											if($dem1['slhang']==0){
												?>
												<p align="right"><a href="dathang.php?Ten=<?php echo $_GET['Ten'] ?>&&id_KH=<?php echo $_GET['id_KH']; ?>"><button type="button" class="btn btn-light" disabled="disabled">Mua Hàng</button></a>&nbsp;&nbsp;</p>
                                                <?php
											}
											else{
											?>
                                            <p align="right"><a href="dathang.php?Ten=<?php echo $_GET['Ten'] ?>&&id_KH=<?php echo $_GET['id_KH']; ?>"><button type="button" class="btn btn-warning">Mua Hàng</button></a>&nbsp;&nbsp;</p>
                                            <?php
											}
										}
										elseif($dem['slhang']==0){
											?>
                                            <p align="right"><a href="dathang.php?Ten=<?php echo $_GET['Ten'] ?>&&id_KH=<?php echo $_GET['id_KH']; ?>"><button type="button" class="btn btn-light" disabled="disabled">Mua Hàng</button></a>&nbsp;&nbsp;</p>
                                            <?php
										}
										else{
										?>
                                        <p align="right"><a href="dathang.php?Ten=<?php echo $_GET['Ten'] ?>&&id_KH=<?php echo $_GET['id_KH']; ?>"><button type="button" class="btn btn-warning">Mua Hàng</button></a>&nbsp;&nbsp;</p>
                                        <?php
										}
										?>
                                        </form>
                                      
                                        
                                        
                                        <hr />
                                        <?php /* <form action="#" method="GET">
                                        <div class="form-group row col-sm-12">
                                        	<label class="col-sm-5">Tên người nhận:</label>
                                            <div class="col-sm-7">
                                            	<input type="text" name="a" value="<?php echo $_GET['Ten'];?>" class="btn-outline-success"/>
                                            </div>
                                            
                                        </div>
                                        <div class="form-group row col-sm-12">
                                        	<label class="col-sm-5">Địa chỉ nhận hàng:</label>
                                            <div class="col-sm-7">
                                            	<input type="text" name="b" class="btn-outline-success"/>
                                            </div>
                                            
                                        </div>
                                        <div class="form-group row col-sm-12">
                                        	<label class="col-sm-5">Email:</label>
                                            <div class="col-sm-7">
                                            	<input type="text" name="c" class="btn-outline-success"/>
                                            </div>
                                            
                                        </div>
                                        <div class="form-group row col-sm-12">
                                        	<label class="col-sm-5">SĐT liên hệ:</label>
                                            <div class="col-sm-7">
                                            	<input type="text" name="d" class="btn-outline-success"/>
                                            </div>
                                            
                                        </div>
                                        <div class="form-group row col-sm-12">
                                        	<label class="col-sm-5">Ghi chú:</label>
                                            <div class="col-sm-7">
                                            	<input type="text" name="e"/>
                                            </div>
                                            
                                        </div>
                                    </div>
                                   	<div class="modal-footer">
                                        <input type="submit" name="submit" value="Đặt hàng" class="btn btn-warning"/>
                                    	</form>
										*/ ?>
                                    </div>
                                   </div>
                                 </div>
                            </div>
                            <div class="footer col-xs-12 col-sm-12 col-md-12 col-ld-12 border">
	<div class="row">
    	<div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        	<center><img src="img/logo.png" height="100px" width="100px" /></center>
            <p> <nx>Về Chúng Tôi</nx> </p>
            <p> <nx>Giới thiệu:</nx><a href="#"> Nhà bán lẻ Mỹ Phẩm VIPU</a></p>
            <p> <nx>Số điện thoại:</nx> <a href="tel:0325927624">0325927624</a></p>
            <p> <nx>Email:</nx> <a href="mailto:phucable@gmail.com">phucable@gmail.com</a></p>
            <p> <nx>Địa chỉ: </nx><rf> ..., Phường xxx, Quận xxx, TP.HCM </rf> </p>
        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        ... ( Nội dung )
        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        ... ( Nội dung )
        </div>
    </div>
    
</div>
                        </div>
                        
        </div>
    </div>
</div>
<script>
window.onscroll = function() {myFunction()};

var header = document.getElementById("Follo");

var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
$(document).ready(function(){
	$(window).scroll(function(){
		if($(this).scrollTop()){
			$('#lendau').fadeIn();
		}
		else{
			$('#lendau').fadeOut();
		}
	})
	$('#lendau').click(function(){
		$('html,body').animate({
			scrollTop:0
		},10);
	})
	
})
</script>
</body>
</html>

