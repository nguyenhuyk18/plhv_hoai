<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script type="text/javascript" src="js/jquery.zoom.min.js"></script>

<script src="https://unpkg.com/js-image-zoom@0.4.1/js-image-zoom.js" type="application/javascript"></script>
<title>Trang chủ</title>
<style>
.footer{
	background-color:#CCF;
	border-width:1px !important;
	border-color: #000 !important;
}
#slideshow {
   overflow: hidden;
   height: 600px;
   width: 1120px;
   margin: 0 auto;
 }
.slide-wrapper {
   width: 5000px;
   -webkit-animation: slide 8s ease infinite;
 }
.slide {
   float: left;
   height: 800px;
   width: 1120px;
 }
 
@-webkit-keyframes slide {
   20% {margin-left: 0px;}
   30% {margin-left: -1120px;}
   50% {margin-left: -1120px;}
   60% {margin-left: -2290px;}
   80% {margin-left: -2290px;}
 }
 a:link{
	 color: #F60;
 }
 a: hover{
	 color: #F36;
 }
</style>
</head>

<body>
<center>
<div class="container h-600">
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 border">
    <div class="row">
                	<div class="col-xs-3 col-sm-3 col-md-3 col-ld-3">
                    	<center><h3><n><img src="img/logo.png"
                         height="300px" width="300px"/></n></h3></center>
                    </div>
                    <div class="col-xs-9 col-sm-9 col-md-9 col-ld-9">
                    	<center><h3><n><img src="img/bne.jpg" height="300px" width="100%"/></n></h3></center>
                    </div>           
                 </div>
                 
                <center><p align="right"><?php /* <a href="home.php?Ten=<?php echo "user".rand(100000,1000000000); ?>"><img src="img/xs.jpg" height="50px" width="50px" />Xem Shop</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; */?><a href="SignIn.php"><img src="img/loi.png" height="50px" width="50px" />Đăng Nhập</a></p></center> 
    	<div class="row">
                 	<div id="slideshow">
  <div class="slide-wrapper">
    <div class="slide"><img src="img/h1.jpg" height="800px" width="100%"></div>
    <div class="slide"><img src="https://thegioidohoacom.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2019/01/10045250/my-pham-lasalsa-luon-la-lua-chon-yeu-thich-cua-phai-dep-1.jpg" height="800px" width="100%"></div>
       <div class="slide"><img src="img/h3.jpg" height="800px" width="100%"></div>
  </div>
</div>
</div>
                 
    </div>
    </div>
<br/>
<br/>
</center>
<div class="footer col-xs-12 col-sm-12 col-md-12 col-ld-12 border">
	<div class="row">
    	<div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        	<center><img src="img/logo.png" height="100px" width="100px" /></center>
            <p> Về Chúng Tôi </p>
            <p> Giới thiệu:<a href="#"> Nhà bán lẻ Mỹ Phẩm VIPU</a></p>
            <p> Số điện thoại: <a href="tel:0325927624">0325927624</a></p>
            <p> Email: <a href="mailto:phucable@gmail.com">phucable@gmail.com</a></p>
            <p>Địa chỉ: Số nhà xxx, Đường xxx, Phường xxx, Quận xxx, TP.HCM </p>
        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        ... ( Nội dung )
        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        ... ( Nội dung )
        </div>
    </div>
</div>
</div>
</div>

</body>
</html>