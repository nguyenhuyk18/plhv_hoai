<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Follo-Shop bán điện thoại chính hãng</title>
    <style>
	button{
	background-color:#FFF;
	border-bottom:0;
	border-top:0;
	border-left:0;
	border-right:0;
}
	</style>
</head>
<body>
<br />
<br />
<?php //Nhận dạng giọng nói,chuyễn từ giọng nói sang text ?>
    <center><button type="button" id='btnTalk'><img src="img/mc.png" width="100%" height="60" onclick = "imagefun ()" id = "getImage"></button></center>
    <br>
    <center><nvm>Nhấn Vào Micro Để Nói !</nvm></center>
    <span id='message'></span>
    <br>
    <center>
    <tv>Text Voice :</tv>  <input type="text" name="&nbsp;val" id="val" disabled="True"  size='15' />
</center>
    <br>
    <script>
        var message = document.querySelector('#message');

        var SpeechRecognition = SpeechRecognition || webkitSpeechRecognition;
        var SpeechGrammarList = SpeechGrammarList || webkitSpeechGrammarList;

        var grammar = '#JSGF V1.0;'

        var recognition = new SpeechRecognition();
        var speechRecognitionList = new SpeechGrammarList();
        speechRecognitionList.addFromString(grammar, 1);
        recognition.grammars = speechRecognitionList;
        recognition.lang = 'vi-VN';
        recognition.interimResults = false;

        recognition.onresult = function(event) {
			var oForm = document.forms["fr"];
            var lastResult = event.results.length - 1;
            var content = event.results[lastResult][0].transcript;
            <?php // message.textContent ='Voice Input: ' + content;?>
			document.getElementById("gt").value = content;
			document.getElementById("val").value = content;
			window.location.href='home.php?Ten=<?php echo $_GET['Ten']; ?>&&gt='+content;
			

        };
        recognition.onspeechend = function() {
            recognition.stop();
        };

        recognition.onerror = function(event) {
           <?php // message.textContent = 'Error occurred in recognition: ' + event.error; ?>
		   alert('No Speech !');
        }

        document.querySelector('#btnTalk').addEventListener('click', function(){
            recognition.start();
        });
		function imagefun () {
            var Image_Id = document.getElementById ('getImage');
            if (Image_Id.src.match ("img/mc.png")) {
                Image_Id.src = "img/vgi.gif";
            }
            else {
                Image_Id.src = "img/mc.png";
				recognition.stop();
            }
        } ;
		
    </script>
    <?php /* <center> <form name="fr" action="home.php" method="GET" id="submit">
        <input type="hidden" name="gt" id="gt" />
        <input type="hidden" name="Ten" value="<?php echo $_GET['Ten']; ?>" />
        <input type="submit" value="OK" name="abc" class="btn-success"/>
    </form><center>
	*/ ?>
    <form  name="fr" action="home.php" method="get">
    							<center><input type="hidden" name="Ten" value=<?php echo $_GET['Ten']; ?> size="35"  />
                                <center><input type="hidden" name="gt" id="gt" size="35"  />
                                </center>
    </form>
</script>
</body>
</html>