<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
include_once("Controller/cSP.php");
$p=new cSP();
//Xem sản phẩm,xem sp theo tên,tìm kiếm,lọc
if(isset($_GET['mingia'])&&isset($_GET['maxgia'])){
	$hien=$p->LocGia();
}
elseif(isset($_GET['loc'])){
	$hien=$p->Loc();
}
elseif(isset($_GET['s'])){
	$hien=$p->Timkiem();
}
elseif(isset($_GET['gt'])){
	$hien=$p->TimkiemGN();
	}
elseif(isset($_GET['id_nhacungcap'])){
	$hien=$p->LaySPTheoTen();
}
else{
$hien=$p->LaySP();
}
?>

   <?php /*?><tr><th colspan="6"> */ ?><center><h3>Sản Phẩm</h3></center><?php /*?></th></tr> */ ?>
<?php
if($hien){
	if(mysql_num_rows($hien)>0){
		while($cot=mysql_fetch_assoc($hien)){
			if($dem==0){
			 echo "<tr  colspan='6'>";}?>
             <td><?php /* <center>
             <br />
             <a href="home.php?chitiet&&Ten=<?php echo $_GET['Ten']; ?>&&id=<?php echo $cot['id_mypham']?>"><div style="position: relative;background: url(img/<?php echo $cot['anh']?>); width:150px; height:150px;background-repeat:round">
             <?php if($cot['giamgia']==0){
			 }
			 else{?>
            <p style="position: absolute;top:-1.2em; right: 0.2em; width: 50px; height:35px; padding: 4px;font-weight: bold; font-size: 18px;"
            class="rounded-circle btn btn-warning">
                   <r><?php
				   		echo "-".$cot['giamgia']."%";
						
                      ?>
                     </r>
                 </p>
                 <?php
			 }
				 ?>
 
           </div></a> 
           </td>
			<?php /* echo '<img src="img/'.$cot['anh'].'"height="200px"; width="200px";' </center></td></td>
             <td> */?>
             <center>
             <br />
             <a href="home.php?chitiet&&Ten=<?php echo $_GET['Ten']; ?>&&id=<?php echo $cot['id_mypham']?>"><div style="position: relative;background: url(img/<?php echo $cot['anh']?>); width:250px; height:250px;background-repeat:round">
             <?php if($cot['giamgia']==0){
			 }
			 else{?>
            <p style="position: absolute;top:-1.2em; right: 0.2em; width: 50px; height:35px; padding: 4px;font-weight: bold; font-size: 18px;"
            class="rounded-circle btn btn-warning">
                   <r><?php
				   		echo "-".$cot['giamgia']."%";
						
                      ?>
                     </r>
                 </p>
                 <?php
			 }
				 ?>
 
           </div></a>
           </center>
           <br/>
             	<ta><strong></strong><?php echo $cot['tenmypham']?></ta>
				<?php /* <br/>
                <va><strong>Mô tả:</strong><?php echo $cot['mota'] ?></va>
				*/ ?>
                <br/>
                <?php
				$a=$cot['gia'];
				$b=$cot['giamgia'];
				$c=($a*$b)/100; 
				if($cot['giamgia']==0){
					?>
					<ma><strong>Giá:</strong><?php echo number_format($cot['gia'],0,",",".") ?>VNĐ</ma>
                    <?php
				}
				else{
				?>
                <sa><strong>Giá Cũ:</strong><?php echo number_format($cot['gia'],0,",",".") ?>VNĐ</sa>
                <br/>
                <xa><strong>Giảm:</strong><?php echo number_format($c,0,",",".")?>VNĐ</xa>
                <br/>
                <?php $d=$a-$c;?>
                <ma><strong>Giá Mới:</strong><?php echo number_format($d,0,",",".") ?>VNĐ</ma>
                <?php }?>
                <form action="#" method="get">
                <p align="right">
                <?php
				include_once("Controller/cTK(KH).php");
				$p=new cTK();
				$u=mysql_fetch_assoc($p->InfoKhachHang());
				?>
              <?php 
			  if($cot['tonkho']==0){
				  ?>
                  <img src="img/banhet.jpg" height="75px" width="75px"/>
                  <?php
			  }
			  else{?> 
            	<a href="home.php?Ten=<?php echo $_GET['Ten']?>&&id_KH=<?php 
				 if(preg_match("/^user[0-9]{1,15}/",$_GET['Ten'])){
					echo $_GET['Ten'];
				}
				else{ echo $u['id_TK']; 
				}?>&&themgiohang=<?php echo $cot['id_mypham']?>"><img src='img/ac.png' height="55px" width="55px"/>
                </a></p>
                <?php }?>
           		</form>
             </td>
        	
		
        <?php
		$dem++;
		if($dem==4){
			echo "</tr>";
		}
        }
	}
	else{
		echo "<script>alert('Không có sản phẩm !')</script>";
	}
}
else{
	echo "<script>alert('Không lấy được dữ liệu !')</script>";
}


?>
<?php
class Xuatphantrang{
	function page(){
		if(isset($_GET['id_nhacungcap'])){
			$p=new cSP();
			$p->Phantrangten();
		}
		elseif(isset($_GET['s'])){
			$p=new cSP();
			$p->Phantrangtimkiem();
		}
		elseif(isset($_GET['gt'])){
			$p=new cSP();
			$p->PhantrangtimkiemVoice();
		}
		elseif(isset($_GET['mingia'])&&isset($_GET['maxgia'])){
			$p=new cSP();
			$p->PhantranglocGia();
		}
		elseif(isset($_GET['loc'])){
			$p=new cSP();
			$p->Phantrangloc();
		}
		else{
			$p=new cSP();
			$p->Phantrang();
		}
	}
	}



?>
</body>
</html>