<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../css/bootstrap.css"/>
<title>Untitled Document</title>

</head>

<body>
<?php
ob_start();
include_once("Controller/cPro.php");
$p=new cSP();
$qr=$p->laydulieucosan();
$cot=mysql_fetch_assoc($qr);
if(isset($_POST['submit'])){
$a=$_POST['a'];
$b=$_POST['b'];
$c=$_POST['c'];
$g=$_POST['g'];
if($a==Null||$b==Null||$c==Null||$g==Null){
	echo "<script>alert('Thiếu thông tin!!!')</script>";
}
elseif($a!=Null||$b!=Null||$c!=Null||$e!=Null||$f!=Null){
	$p=new cSP();
    $p->suaSP();
	$ten=$_GET['Ten'];
	echo header("refresh:0,url='admin.php?dssp&&Ten=$ten'");
				}
			}
ob_end_flush();
?>
<div class="container h-600">
	<div class="row">
    	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 h-150">
            <center>
            	<h3>Sửa Sản Phẩm</h3><br />
                <p></p>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          		<form action="#" method="post" enctype="multipart/form-data">
                	<div class="form-group row">
                    	<label class="col-sm-3"></label>
                        <label class="col-sm-2">Tên điện thoại:</label>
                        <input type="text" name="a" value="<?php  echo $cot['tendt']?>"/>
                    </div>
                    <div class="form-group row">
                    	<label class="col-sm-3"></label>
                        <label class="col-sm-2">Giá:</label>
                        <input type="text" name="b" value="<?php  echo $cot['gia']?>"/>
                    </div>
                    <div class="form-group row">
                    	<label class="col-sm-3"></label>
                        <label class="col-sm-2">Khuyến mãi:</label>
                        <input type="text" name="c" value="<?php  echo $cot['giamgia']?>"/>(%)
                    </div>
                    <div class="form-group row">
                    	<label class="col-sm-3"></label>
                        <label class="col-sm-2">Ảnh:</label>
                        <img src='img/<?php echo $cot['anh']?>' height="150px" width="150px"/>
                        <input type="hidden" name="e" value="<?php echo $cot['anh']?>"/>
                    </div>
                     <div class="form-group row">
                    	<label class="col-sm-3"></label>
                        <label class="col-sm-2">File:</label>
                        <input type="file" name="d" />
                    </div>
                   <div class="form-group row">
                    	<label class="col-sm-3"></label>
                        <label class="col-sm-2">Loại:</label>
                        <input type="text" value="<?php if($cot['id_loai'] ==1){
							echo "Android";
						}
						elseif($cot['id_loai'] ==2){
							echo "Iphone";
						}?>" disabled="True"/>
                    </div>
                    <div class="form-group row">
                    	<label class="col-sm-3"></label>
                        <label class="col-sm-2"></label>
                       <?php
					   if($cot['id_loai']==1){
						   $android="checked";
					   }
					   elseif($cot['id_loai']==2){
						   $iphone="checked";
					   }
					   ?>
                       <input type="radio" name="f" value="1" <?php echo $android?>/>&nbsp;&nbsp;
                       <img src="img/andro.png" height="50px" width="50px"/>&nbsp;&nbsp&nbsp;&nbsp
                       <input type="radio" name="f" value="2" <?php echo $iphone?>/>&nbsp;&nbsp;
                       <img src="img/iphon.png" height="50px" width="50px"/>
                       
                        
                    </div>
                    <div class="form-group row">
                    	<label class="col-sm-3"></label>
                        <label class="col-sm-2">Mô tả:</label>
                        <input type="text" name="g" value="<?php  echo $cot['mota']?>"/>
                    </div>
                    <div class="form-group row">
                    	<label class="col-sm-3"></label>
                        <label class="col-sm-2">Nhà cung cấp:</label>
                        <input type="text" value="<?php 
						echo $cot['tennhacungcap'];
							?>" disabled="disabled"/>
                    </div>
                    <div class="form-group row">
                    	<label class="col-sm-3"></label>
                        <label class="col-sm-2"></label>
                        <select name="h">
                        	<?php
							include_once("Controller/cCH.php");
							$p=new cCH();
							$data=$p->laydulieu();
							while($cot=mysql_fetch_assoc($data)){
								echo "<option value='".$cot['id_nhacungcap']."'>".$cot['tennhacungcap']."</option>";
							}
							
							?>
                        </select>
                    </div>
                    <div class="form-group row">
                    	<label class="col-sm-3"></label>
                        <label class="col-sm-2"></label>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;<input type="submit" name="submit" value="Sửa"/>
                    </div>
                </form>
                </div>
            </center>
        </div>
    </div>
</div>
</body>
</html>