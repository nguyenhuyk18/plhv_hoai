<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
ob_start();
include_once("Controller/cInv.php");
$p=new cNCC();
if(isset($_GET['delncc'])){
	$p->xoa();
	echo header("refresh:0,url='admin.php?Ten=".$_GET['Ten']."&&qlncc'");
}
ob_end_flush();
?>
</body>
</html>