<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
ob_start();
include_once("Controller/cSP.php");
$p=new cSP();
//Đơn hàng
if(isset($_GET['a'])&&isset($_GET['b'])&&isset($_GET['c'])&&isset($_GET['d'])&&isset($_GET['e'])){
	$cot=$p->themdonhang();
	$cot=$p->capnhatDonHang();
	$cot=$p->xoagh();
	?>
    	Quý khách đặt hàng thành công.<a href="home.php">Tiếp tục mua hàng</a>
    <?php
}
//Giỏ hàng
elseif(isset($_GET['themgiohang'])){
	$cot=$p->ThemSPvaogiohang();
	$cot=$p->cntkgiohang();
	$cot=$p->uptt();
	
	}

elseif((isset($_GET['sl'])&&isset($_GET['id']))){
	$cot=$p->capnhatsl();
	$cot=$p->capnhattt();
}
elseif(isset($_GET['ma'])){
	$cot=$p->xoa();
	$ten=$_GET['Ten'];
	$id_KH=$_GET['id_KH'];
	echo header("refresh:0,url='giohang.php?Ten=$ten&&id_KH=$id_KH'");
}
elseif(isset($_GET['submit'])){
	if(preg_match("/^user[0-9]{1,15}/",$_GET['Ten'])){
	$cot=$p->xoatatcavd();
	}
	else{
	$cot=$p->xoatatca();
	$ten=$_GET['Ten'];
	$id_KH=$_GET['id_KH'];
	echo header("refresh:0,url='giohang.php?Ten=$ten&&id_KH=$id_KH'");
	}
}
ob_end_flush();
?>
</body>
</html>