<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
include_once("Controller/cPro.php");
$p=new cSP();
//Xóa
if(isset($_GET['del'])){
	$p-> delSP();

}
elseif(isset($_GET['huydh'])){
	$p->huydonyeucau();
}
//Tải tệp
elseif(isset($_POST['submit'])){
	$tai=$p->taitep();
	$ten=$_FILES['f']['name'];
	$tam=$_FILES['f']['tmp_name'];
	$path="tep/".$ten;
	if($tai){
		move_uploaded_file($tam,$path);
		echo "Tải lên thành công";
	}
	else{
		echo "Tải lên thất bại";
	}
}

//Đơn hàng(xem lsdh,sl khách hàng)
elseif(isset($_GET['lsdh'])){
	if(isset($_GET['homnay'])){
		$hien=$p->dhhn();
		
	}
	elseif(isset($_GET['homqua'])){
		$hien=$p->dhhq();
		
	}
	elseif(isset($_GET['trongtuan'])){
		$hien=$p->dhtq();
		
	}
	else{
	$hien=$p->xemdh();
	}
	if($hien){
		if(mysql_num_rows($hien)>0){
			$a=1;
		while($cot=mysql_fetch_assoc($hien)){?>
        <tr>
        	<td><center><?php echo $a++; ?></td>
        	<td><center><?php echo $cot['tendonhang'] ?></td>
            <td><center><?php echo $cot['tenkhac'] ?></td>
            <td><center><?php echo number_format($cot['tongtien'],0) ?>&nbsp; VNĐ</td>
            <td><center><?php if($cot['tinhtrang']==0){
				echo "Chưa Thanh Toán";
			}
			else{
				echo "Đã Thanh Toán";
			}?></td>
            <td><center>
             <?php
            if(isset($_GET['homnay'])){
				?>
				<button class="btn-success"><a href="admin.php?Ten=<?php echo $_GET['Ten'] ?>&&ctdh=<?php echo $cot['tendonhang'];?>&&homnay"><xn>Xem</xn></a></button>
                <?php
			}
			elseif(isset($_GET['homqua'])){
				?>
				<button class="btn-success"><a href="admin.php?Ten=<?php echo $_GET['Ten'] ?>&&ctdh=<?php echo $cot['tendonhang'];?>&&homqua"><xn>Xem</xn></a></button>
                <?php
			}
			elseif(isset($_GET['trongtuan'])){
				?>
				<button class="btn-success"><a href="admin.php?Ten=<?php echo $_GET['Ten'] ?>&&ctdh=<?php echo $cot['tendonhang'];?>&&trongtuan"><xn>Xem</xn></a></button>
                <?php
			}
			else{
						?><button class="btn-success"><a href="admin.php?Ten=<?php echo $_GET['Ten'] ?>&&ctdh=<?php echo $cot['tendonhang'];?>"><xn>Xem</xn></a></button><?php
		}
                        ?></td>
            <td><center>
            <?php
			if($cot['trangthai']==0){
			?>
            <button class="btn-info"><a href="admin.php?Ten=<?php echo $_GET['Ten']?>&&xn=<?php echo $cot['tendonhang']?>"><xn>Xác Nhận</xn></a></button>
            <?php
			}
			elseif($cot['trangthai']==1){
				?>
				<button class="btn-warning"><a href="admin.php?Ten=<?php echo $_GET['Ten']?>&&xn1=<?php echo $cot['tendonhang']?>"><xn1>Soạn Hàng</xnl></a></button>
                <?php
				
			}
			elseif($cot['trangthai']==2){
				?>
                <button class="btn-damage"><xnn>Đang Xử Lý </xnn></button>
                <?php
			}
			elseif($cot['trangthai']==3){
				?>
                <button class="btn-damage"><xnn>Đang V/C </xnn></button>
                <?php
			}
			elseif($cot['trangthai']==4){
				?>
                <button class="btn-damage"><xnn>Đã Giao</xnn></button>
                <?php
			}
			elseif($cot['trangthai']==5){
				?>
                <button class="btn-success"><xn>Hoàn Tất</xn></button>
                <?php
			}
			?></center></td>
            <td><?php if($cot['trangthai']==1){
				?>
                <center><button class="btn-danger"><a href="admin.php?lsdh&&Ten=<?php echo $_GET['Ten']; ?>&&iddh=<?php echo $cot['id_donhang'] ?>&&huydh"><xcx>X</xcx></a></button></center>
                <?php
			}
			else{
				?>
                <center><button class="btn-light">Hủy</button></center>
                
                <?php
			}?></td>
        </tr>
        <?php
		}
		$a++;
		}
		/* else{
			echo "Không có lượt đặt hàng nào gần đây!!!";
		}
		*/
	}
}
else{
//Hiện sp theo lưới
if(isset($_GET['dssp'])){
$hien=$p->SP();
if($hien){
	if(mysql_num_rows($hien)>0){
		$i=1;
		while($cot=mysql_fetch_assoc($hien)){?>
        <tr>
        	<td><center><ir><?php echo $cot['id_dt']; ?></ir></center></td>
            <td><center><?php echo $cot['tendt'] ?></center></td>
            <td><center><?php echo number_format($cot['gia'],0,",",".") ?>&nbsp;&nbsp;VNĐ</center></td>
            <td><center><?php echo $cot['giamgia'] ?>%</center></td>
            <td> <center><?php echo '<img src="img/'.$cot['anh'].'"height="100px"; width="100px";'?></center></td>
            <td><center><?php 
			if($cot['id_loai']==1){
				echo "Android";
			}
			else{
				echo "Iphone";
			}?></center></td>
            <td><center><?php echo $cot['id_nhacungcap'];
			?></center></td>
            <td><center><a href="admin.php?up=<?php echo $cot['id_dt'] ?>&&Ten=<?php echo $_GET['Ten'];?>"><img src="img/edit.png" height="30px" width="30px"/></a></center></td>
            <td><center><a href="admin.php?del=<?php echo $cot['id_dt'] ?>&&Ten=<?php echo $_GET['Ten'];?>"><img src="img/del.png" height="30px" width="30px"/></a></center></td>
        </tr>
        
     <?php
		}
		$i++;
	}
	else{
		echo "<script>alert('Không có dữ liệu')</script>";
	}
}
else{
	echo "<script>alert('Không lấy được dữ liệu')</script>";
}
}
}
?>
<?php
class xuatphantrang{
	function page(){
		$p=new cSP();
		if(isset($_GET['lsdh'])){
			$p->sotrangcanthietls();
		}
		else{
			$p->Phantrang();
		}
	}
	
}


?>
</body>
</html>