<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../css/bootstrap.css"/>
<title>Untitled Document</title>

</head>

<body>
<?php
ob_start();
if(isset($_POST['submit'])){
	include_once("Controller/cPro.php");
	if(isset($_POST['submit'])){
		$ten=$_GET['Ten'];
	$p=new cSP();
	$kq=$p->themSP();
	if($kq==1){
				echo "<script>alert('Thêm sản phẩm thành công')</script>";
				echo header("refresh:0,url='admin.php?dssp&&Ten=$ten'");
			}
	else{
			return false;
	
}
	}
}



ob_end_flush();
?>


<div class="container h-600">
	<div class="row">
    	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 h-150">
            <center>
            	<h3>Thêm Sản Phẩm Mới</h3><br />
                <p></p>
                <form action="#" method="post">
                    
                 	<div class="row col-xs-12 col-sm-12 col-md-12 col-lg-12 border">
                    
                    	<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        <br />
                          
                    	<strong>Thông Tin Chung</strong>&nbsp;&nbsp;<nm>(*)</nm>
                        <br />
                        <br />
                       Tên sản phẩm:                        
                       <input type="text" name="tsp" required="required"/>
                       <br />
                       <br />
                   			    
                    	
                        Giá:
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="gia" required="required"/>
                   		<br />
                        <br />	
                         
                        Khuyến mãi:&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" name="km" required="required"/>
                        <br />
                        <br />
                   			   
                        Loại:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                               <select name="loai">
                               		<option value="1">Android</option>
                                    <option value="2">Iphone</option>
                               </select>
                   			  
                               <br />
                               <br />
                               Nhà cung cấp:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                               <select name="ncc">
                               		<?php
							include_once("Controller/cCH.php");
							$p=new cCH();
							$data=$p->laydulieu();
							while($cot=mysql_fetch_assoc($data)){
								echo "<option value='".$cot['id_nhacungcap']."'>".$cot['tennhacungcap']."</option>";
							}
							
							?>
                               </select>
                            
                		<br />
                        <br />
                        Mô tả:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" name="mota" />
                        <br />
                        <br />
                         &nbsp;&nbsp;Ảnh:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="file" name="anh" required="required"/>
                        <br />
                        <br />
                        &nbsp;Ảnh 1:&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="file" name="anh1" required="required"/>
                        <br />
                        <br />
                        &nbsp;Ảnh 2:&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="file" name="anh2" required="required"/>
                        <br />
                        <br />
                        &nbsp;Ảnh 3:&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="file" name="anh3" required="required"/>
                        <br />
                        <br />
                        &nbsp;Ảnh 4:
                        &nbsp;&nbsp;&nbsp;&nbsp;<input type="file" name="anh4" required="required"/>
                        <br />
                        <br />
                        Ảnh URL:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" name="url" required="required" placeholder="https://cdn.tgdd.vn/Products/Images/42/245261/xiao"/>
                        <br />
                        <br />
                   			   
                        </div>
                    	
                    	<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        
                       
                           <br />
                          
                    	<strong>Màn Hình</strong>
                        <br />
                        <br />
                       Công nghệ màn hình:                        
                       <input type="text" name="A" />
                       <br />
                       <br />
                   			    
                    	
                        Độ phân giải:
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="B"/>
                   		<br />
                        <br />	   
                       Kích thước màn hình:
                        <input type="text" name="C" />
                        <br />
                        <br />
                   			    Độ sáng tối đa:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" name="D" />
                        <br />
                        <br />
                   			   Chất liệu kính:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                               <input type="text" name="E" />
                   			  
                               <br />
                               <br />
                            
                		
                        </div>
                		<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        
                        	
                		</div>
                     
                    </div>
                    
                    <div class="row clacol-xs-12 col-sm-12 col-md-12 col-lg-12 border">
                    	<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        <br />
                        	<strong>Camera Sau</strong>
                        <br />
                        <br />
                       Độ phân giải:                        
                       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                       <input type="text" name="F" />
                       <br />
                       <br />
                   			    
                    	
                        Quay phim:
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" name="G" />
                   		<br />
                        <br />	   
                       Đèn Flash:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" name="H" />
                        <br />
                        <br />
                   			    Tính năng:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" name="I" />
                        <br />
                        <br />
                        </div>
                		<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        <br />
                        	<strong>Camera Trước</strong>
                        <br />
                        <br />
                       Độ phân giải:                        
                      
                       <input type="text" name="K" />
                       <br />
                       <br />
                   			    
                    	
                        
                   			    Tính năng:&nbsp;&nbsp;
                                &nbsp;
                        <input type="text" name="L"/>
                        <br />
                        <br />
                		</div>
                    </div>
                    
                    <div class="row col-xs-12 col-sm-12 col-md-12 col-lg-12 border ">
                    	<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        <br />
                        	<strong>Hệ điều hành và CPU</strong>
                        <br />
                        <br />
                       Hệ điều hành:                        
                       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                       <input type="text" name="M" />
                       <br />
                       <br />
                   			    
                    	
                        Chip xử lý (CPU):
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" name="N" />
                   		<br />
                        <br />	   
                       Tốc độ (CPU):&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" name="O" />
                        <br />
                        <br />
                   			    Chip đồ họa:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" name="P" />
                        <br />
                        <br />
                		</div>
                		<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        <br />
                        	<strong>Bộ nhớ và lưu trữ</strong>
                        <br />
                        <br />
                       Ram:                        
                       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                       <input type="text" name="Q" />
                       <br />
                       <br />
                   			    
                    	
                        Bộ nhớ trong:&nbsp;&nbsp;
                        
                        <input type="text" name="R" />
                   		<br />
                        <br />	   
                       Thẻ nhớ:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" name="S" />
                        <br />
                        <br />
                   			    Danh bạ:&nbsp;&nbsp;
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" name="T" />
                        <br />
                        <br />	
                		</div>
               			
                    </div>
                    <div class="row col-xs-12 col-sm-12 col-md-12 col-md-12 border">
                    	<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        	<br />
                        	<strong>Kết nối</strong>
                        <br />
                        <br />
                       Mạng di động: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;                     
                       
                       <input type="text" name="U" />
                       <br />
                       <br />
                   			    
                    	
                        Sim:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        
                        <input type="text" name="V" />
                   		<br />
                        <br />	   
                       Wifi:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" name="X" />
                        <br />
                        <br />
                   			    Danh bạ:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" name="Y" />
                         <br />
                       <br />
                   			    
                    	
                        GPS:&nbsp;&nbsp;
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        
                        <input type="text" name="a" />
                   		<br />
                        <br />	   
                       Bluetooth:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" name="b" />
                        <br />
                        <br />
                   			    Cổng kết nối:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" name="c" />
                        <br />
                        <br />
                   			    Jack tai nghe:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text" name="d" />
                        <br />
                        <br />	
                		</div>
                		<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        <br />
                        	<strong>Pin & Sạc</strong>
                        <br />
                        <br />
                        	  Dung lượng pin:&nbsp;
                               
                                
                        <input type="text" name="e"/>
                         <br />
                       <br />
                   			    
                    	
                        Loại pin:&nbsp;&nbsp;
                                &nbsp;&nbsp;&nbsp;&nbsp;
                                &nbsp;&nbsp;&nbsp;&nbsp;
                                &nbsp;&nbsp;
                        
                        <input type="text" name="f" />
                   		<br />
                        <br />	   
                       Công nghệ pin:&nbsp;
                       &nbsp;&nbsp;
                        <input type="text" name="g" />
                        <br />
                        <br />
                   			    Hỗ trợ sạc tối đa:&nbsp;
                        <input type="text" name="h" />
                        <br />
                        <br />
                   			  
                		</div>
               			
                    </div>
                    <div class="row">
                    	<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        	
                		</div>
                		<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        	
                		</div>
               		
                    </div>
                    <div class="row col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="submit" name="submit" value="Thêm"/>
                    </div>
                    </thead>
                </table>
                </form>
                
             
        </div>
        </div>
        </div>
</body>
</html>