<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
$t=$_GET['Ten'];
include_once("Controller/cCH.php");
$p=new cCH();
?>
<?php
/*
if($hien){
	if(mysql_num_rows($hien)>0){
		while($cot=mysql_fetch_assoc($hien)){?>
        
        <tr>
        	<td> <a href="home.php?Ten=<?php echo $_GET['Ten']; ?>&&id_loai=<?php echo $cot['id_loai']; ?>"><tt><?php echo $cot['loaimypham'];?></tt></a><center></center><p></p></td></td>
        </tr>
        
     <?php  
		}
	}
	else{
		echo "<script>alert('Không có dữ liệu')</script>";
	}
	
}
else{
	echo "<script>alert('Không lấy được dữ liệu')</script>";
}

*/

?>
</body>
</html>