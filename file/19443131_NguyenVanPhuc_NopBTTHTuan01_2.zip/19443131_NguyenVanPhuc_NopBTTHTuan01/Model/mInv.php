<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
include_once("ketnoiAD.php");
class mNCC{
	//Xem nhà cung cấp theo lưới
	function xemNCC(){
			$p=new ketnoiAD($ketnoi);
			if($p->ketnoi($ketnoi)){
				if(isset($_GET['qlncc'])){
					$sql="select *from nhacungcap";
					$qr=mysql_query($sql);
					return $qr;
					$p->dongketnoi($ketnoi);
					
				}
				else{
					echo "<script>alert('Không có')</script>";
				}
			}
			else{
				return false;
}
}
//Thêm nhà cung cấp
	function themNCC(){
		$p=new ketnoiAD($ketnoi);
			if($p->ketnoi($ketnoi)){
				if(isset($_POST['submit'])){
					$a=$_POST['a'];
					$b=$_POST['b'];
					$c=$_POST['c'];
					$d=$_POST['d'];
					$f=$_POST['f'];
					$g=$_POST['g'];
					$sql="insert into nhacungcap(tennhacungcap,email,sdt,diachi,anh,ngaythanhlap)
					values('$a','$b','$c','$d','$f','$g')";
					$qr=mysql_query($sql);
					return $qr;
				}
			}
		
	}
//Lấy dữ liệu theo id để sửa
function layNCC(){
			$p=new ketnoiAD($ketnoi);
			if($p->ketnoi($ketnoi)){
					$id=$_GET['upncc'];
					$sql="select * from nhacungcap where id_nhacungcap=$id";
					$qr=mysql_query($sql);
					return $qr;
					$p->dongketnoi($ketnoi);
					
			}
			else{
				return false;
}
}
//Sửa nhà cung cấp
function suaNCC(){
			$p=new ketnoiAD($ketnoi);
			if($p->ketnoi($ketnoi)){
				if(isset($_POST['submit'])){
					$id=$_GET['upncc'];
					$a=$_POST['a'];
					$b=$_POST['b'];
					$c=$_POST['c'];
					$d=$_POST['d'];
					$f=$_POST['f'];
					$sql="update nhacungcap set tennhacungcap='$a',email='$b',sdt='$c',diachi='$d',ngaythanhlap='$f'
					where id_nhacungcap='$id' ";
					$qr=mysql_query($sql);
					return $qr;
					$p->dongketnoi($ketnoi);
					
			}
			}
			else{
				return false;
}
}
//Xóa nhà cung cấp
function xoa(){
	$p=new ketnoiAD($ketnoi);
			if($p->ketnoi($ketnoi)){
				if(isset($_GET['delncc'])){
					$id=$_GET['delncc'];
					$sql="delete from nhacungcap where id_nhacungcap=$id";
					$qr=mysql_query($sql);
					return $qr;
				}
			}
}
}
?>
</body>
</html>