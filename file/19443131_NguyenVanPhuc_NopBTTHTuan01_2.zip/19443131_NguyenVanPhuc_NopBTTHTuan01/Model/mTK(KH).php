<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
include_once("ketnoiKH.php");
class mTK{
	


/*
C1:
function laytaikhoan(){
$p=new ketnoi($ketnoi);
if($p->ketnoi($ketnoi)){
	$sql="select *from taikhoan";
	$qr=mysql_query($sql);
	return $qr;
	$p->dongketnoi($ketnoi);
}
else{
	return false;
}
	}

function tntaikhoan(){
	$p=new ketnoi($ketnoi);
	if($p->ketnoi($ketnoi)){
		if(isset($_POST['submit'])){
			$ten=$_REQUEST['name'];
			$mk=md5($_REQUEST['pass']);
			$sql="select *from taikhoan where Username='$ten' && Password='$mk'";
			$qr=mysql_query($sql);
			return $qr;
		}
		else{
			echo "<script>alert('Không có submit')</script>";
		}
	}
	else{
		return false;
	}
}
*/

//Đăng ký tài khoản khách hàng,thêm tài khoản khách hàng vào CSDL tài khoản
function dk(){
	$p=new ketnoi($ketnoi);
	if($p->ketnoi($ketnoi)){
		if(isset($_POST['su'])){
			$a=$_POST['name'];
			$b=md5($_POST['pass']);
			$c=$_POST['email'];
			$d=$_POST['qrcode'];
			$f=$_FILES['pic']['name'];
			$u=$_POST['user'];
			$p=$_POST['phone'];
			$dc=$_POST['dc'];
			$ten=$_POST['Ten'];
			$sql="insert into taikhoan(Username,Password,Email,Anh,NguoiDung,SoDienThoai,DiaChi,usr_an) values('$a','$b','$c'
			,'$f','$u','$p','$dc','$ten') ";
			$qr=mysql_query($sql);
			return $qr;
		}
		else{
			echo "<script>alert('Không có submit')</script>";
		}
	}
	else{
		return false;
	}
	
}
//Kiem tra tai khoan ton tai
function  tktt(){
	$p=new ketnoi($ketnoi);
	if($p->ketnoi($ketnoi)){
		if(isset($_POST['su'])){
			$a=$_POST['name'];
		$sql="select *from taikhoan where Username='$a'";
		$qr=mysql_query($sql);
		return $qr;
		}
	}


}
//Kiểm tra thông tin đăng nhập Khách Hàng

//Password Khach Hang(user 1),Nguoi Ban Hang (user 2),Admin (user 3),Shipper(user 4)
function taikhoan(){
	$p=new ketnoi($ketnoi);
	if($p->ketnoi($ketnoi)){
		if(isset($_POST['submit'])){
			$se=$_POST['se'];
			$mk=md5($_POST['pass']);
			$sql="select * from taikhoan where (SoDienThoai='$se' or Email='$se') && Password='$mk' && NguoiDung='1'";
			$qr=mysql_query($sql);
			return $qr;
		}
		else{
			echo "<script>alert('Không có submit')</script>";
		}
	}
	else{
		return false;
	}
}
function taikhoanQR(){
	$p=new ketnoi($ketnoi);
	if($p->ketnoi($ketnoi)){
		if(isset($_POST['dn'])){
			$ph=$_POST['Phone'];
			$e=$_POST['Email'];
			$p=$_POST['Pass'];
			$sql="select * from taikhoan where SoDienThoai='$ph' and Email='$e' and Password='$p' and NguoiDung='1'";
			$qr=mysql_query($sql);
			return $qr;
		}
		else{
			echo "<script>alert('Không có submit')</script>";
		}
	}
	else{
		return false;
	}
}
//Sự tồn tại tên trong tài khoản
function TenTonTai(){
		$tv=$_GET['Ten'];
		$sql="select * from taikhoan where Username in (select Username from taikhoan where Username='$tv' and NguoiDung='1')"; //and NguoiDung='1'
		$qr=mysql_query($sql);
		return $qr;
}
//Xuất info cá nhân
function XuatThongTin(){
		$tv=$_GET['Ten'];
		$sql="select * from taikhoan where Username='$tv'";
		$qr=mysql_query($sql);
		return $qr;
}
//Chỉnh sửa thông tin cá nhân
function SuaInfo(){
	$p=new ketnoi($ketnoi);
	if($p->ketnoi($ketnoi)){
		if(isset($_POST['cntt'])){
		$a=$_POST['a'];
		/*$b=$_POST['b']; Email ko sửa*/
		$c=$_POST['c'];
		$d=$_POST['d'];
		$f=$_POST['f'];
		if(isset($_POST['id'])){
		$id=$_POST['id'];
		$sql="update taikhoan set Username='$a',SoDienThoai='$c',DiaChi='$d',Anh='$f' where id_TK='$id'";
		$qr=mysql_query($sql);
		return $qr;
		}
		}
	}
	
}
//Tìm tài khoàn
function Tim(){
	$p=new ketnoi($ketnoi);
	if($p->ketnoi($ketnoi)){
		if(isset($_POST['tim'])){
			$pe=$_POST['pe'];
			$sql="select *from taikhoan where SoDienThoai='$pe' or Email='$pe'";
			$qr=mysql_query($sql);
			return $qr;
		}
	}
}
function cnmk(){
	$p=new ketnoi($ketnoi);
	if($p->ketnoi($ketnoi)){
		if(isset($_POST['td'])){
			$p=md5($_POST['p']);
			$pe=$_POST['pe'];
			$sql="update taikhoan set Password='$p' where SoDienThoai='$pe' or Email='$pe'";
			$qr=mysql_query($sql);
			return $qr;
		}
	}
	
}
//Chỉnh sửa mã tài khoản khi khách vô danh đăng ký và đăng nhập vào hệ thống
	function xemid(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			if(isset($_GET['Ten'])){
				$na=$_GET['Ten'];
				$sql="select *from taikhoan where usr_an='$na' ";
				$qr=mysql_query($sql);
				return $qr;
				$p->dongketnoi($ketnoi);
				
				
			}
		}
	}
	function cnid(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			if(isset($_GET['Ten'])&&isset($_GET['idTKNew'])){
				$id=$_GET['idTKNew'];
				$ten=$_GET['Ten'];
				$sql="update giohang set id_taikhoan='$id' where id_taikhoan='$ten' ";
				$qr=mysql_query($sql);
				return $qr;
				$p->dongketnoi($ketnoi);
				
				
			}
		}
	}
	
	//Xuất thông tin đơn hàng
	function xuatinfo(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
				$ten=$_GET['Ten'];
				$sql="select *from taikhoan where Username='$ten' ";
				$qr=mysql_query($sql);
				return $qr;
				$p->dongketnoi($ketnoi);
		}
	}
}
?>
</body>
</html>