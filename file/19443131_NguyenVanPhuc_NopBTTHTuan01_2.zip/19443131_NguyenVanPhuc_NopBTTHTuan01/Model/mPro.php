<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
include_once("ketnoiAD.php");
class mSP{
	
  
	//Xem sản phẩm lưới
	function xemSP(){
			$p=new ketnoiAD($ketnoi);
			if($p->ketnoi($ketnoi)){
				if(isset($_GET['dssp'])){
					$bangghimoitrang=!empty($_GET['per_page'])?$_GET['per_page']:4;
					$tranghientai=!empty($_GET['page'])?$_GET['page']:1;
					$start_from = ($tranghientai-1) * $bangghimoitrang;
					$sql="select *from dienthoai limit $start_from,$bangghimoitrang";
					$qr=mysql_query($sql);
					return $qr;
					$p->dongketnoi($ketnoi);
					
				}
				else{
					echo "<script>alert('Không có')</script>";
				}
			}
			else{
				return false;
}
}
	function sotrangcanthiet(){
			$bangghimoitrang=!empty($_GET['per_page'])?$_GET['per_page']:4;
			$tranghientai=!empty($_GET['page'])?$_GET['page']:1;
			$sql ="SELECT COUNT(id_dt) FROM dienthoai";
			$qr=mysql_query($sql); 
    		$cot = mysql_fetch_row($qr);  
    		$tongbangghi = $cot[0];  
   		    $tongsotrang = ceil($tongbangghi / $bangghimoitrang); 
			include_once("Controller/cPagePro.php");
			return $tongsotrang;
	}
	//Thêm sản phẩm
	function chenSP(){
		$p=new ketnoiAD($ketnoi);
		if($p->ketnoi($ketnoi)){
			if(isset($_POST['submit'])){
				$ncc=$_POST['ncc'];
				$mota=$_POST['mota'];
				$loai=$_POST['loai'];
				$km=$_POST['km'];
				$tsp=$_POST['tsp'];
				$gia=$_POST['gia'];
				$anh=$_POST['anh'];
				$url=$_POST['url'];
				$anh1=$_POST['anh1'];
				$anh2=$_POST['anh2'];
				$anh3=$_POST['anh3'];
				$anh4=$_POST['anh4'];
				$A=$_POST['A'];
				$B=$_POST['B'];
				$C=$_POST['C'];
				$D=$_POST['D'];
				$E=$_POST['E'];
				$F=$_POST['F'];
				$G=$_POST['G'];
				$H=$_POST['H'];
				$I=$_POST['I'];
				$K=$_POST['K'];
				$L=$_POST['L'];
				$M=$_POST['M'];
				$N=$_POST['N'];
				$O=$_POST['O'];
				$P=$_POST['P'];
				$Q=$_POST['Q'];
				$R=$_POST['R'];
				$S=$_POST['S'];
				$T=$_POST['T'];
				$U=$_POST['U'];
				$V=$_POST['V'];
				$X=$_POST['X'];
				$Y=$_POST['Y'];
				$a=$_POST['a'];
				$b=$_POST['b'];
				$c=$_POST['c'];
				$d=$_POST['d'];
				$e=$_POST['e'];
				$f=$_POST['f'];
				$g=$_POST['g'];
				$h=$_POST['h'];
				$i=$_POST['i'];
				
		}
		$sql="insert into dienthoai(tendt,anhurl,gia,giamgia,anh,anh1,anh2,anh3,anh4,mota,congnghemanhinh,dophangiai,kichthuocmanhinh,dosangtoida,
		chatlieukinh,dophangiaicamsau,quayphimcamsau,denflash,tinhnangcamsau,dophangiaicamtruoc,tinhnangcamtruoc,hedieuhanh,
		chipxulyCPU,tocdoCPU,chipdohoaGPU,ram,bonhotrong,thenho,danhba,mangdidong,sim,wifi,gps,bluetooth,congketnoi,tainghe,dungluongpin,
		loaipin,congnghepin,hotrosactoida,thoidiemramat,id_loai,id_nhacungcap) 
		values('$tsp','$url','$gia','$km','$anh','$anh1','$anh2','$anh3','$anh4','$mota','$A','$B','$C','$D','$E','$F','$G','$H','$I',
		'$K','$L','$M','$N','$O','$P','$Q','$R','$S','$T','$U','$V','$X','$Y','$a','$b','$d',
		'$e','$f','$g','$h',now(),'$loai','$ncc')";
		$qr=mysql_query($sql);
		return $qr;
		$p->dongketnoi($ketnoi);
		}
	}
	//Cập nhật sản phẩm
	function updateSP(){
		$p=new ketnoiAD($ketnoi);
		$p->ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			if(isset($_POST['submit'])){
				$a=$_POST['a'];
				$b=$_POST['b'];
				$c=$_POST['c'];
				$anh=$_FILES['d']['name'];
				if($anh==Null){
					$anh=$_POST['e'];
				}
				$f=$_POST['f'];
				$g=$_POST['g'];
				$h=$_POST['h'];
				if(isset($_GET['up'])){
					$id=$_GET['up'];
	$sql="update dienthoai set tendt='$a',gia='$b',giamgia='$c',anh='$anh',id_loai='$f',mota='$g',id_nhacungcap='$h'
	where id_dt='$id'";
	$qr =mysql_query($sql);
	return $qr;
	$p->dongketnoi(($ketnoi));
			}
			else{
				return false;
			}
		}
}
 }
 //Lấy dữ liệu đổ vào form khi cập nhật
 function dodulieu(){
	 $p=new ketnoiAD($ketnoi);
	 if($p->ketnoi($ketnoi)){
		 if(isset($_GET['up'])){
			 $id=$_GET['up'];
			 $sql="select dt.tendt as tendt,dt.gia as gia ,dt.giamgia as giamgia,dt.anh as anh,
			 dt.id_loai as id_loai,dt.mota as mota,ncc.tennhacungcap as tennhacungcap
			 from dienthoai dt join nhacungcap ncc on dt.id_nhacungcap=ncc.id_nhacungcap where id_dt='$id'";
			 $qr=mysql_query($sql);
			 return $qr;
			 $p->dongketnoi($ketnoi);
		 }
	 }
	 else{
		 return false;
	 }
 }
 //Xóa sản phẩm
 function xoaSP(){
	$p=new ketnoiAD($ketnoi);
	if($p->ketnoi($ketnoi)){
		if(isset($_GET['del'])){
			$id=$_GET['del'];
			$sql="delete from dienthoai where id_dt='$id'";
			$qr=mysql_query($sql);
			return $qr;
			
			$p->dongketnoi($ketnoi);
		}
	}
	else{
		echo "<script>alert('Không có')</script>";
	}
}
 
  //Đơn hàng(xem lsdh,sl khách hàng đặt mua)
  function lsdh(){
	  	$p=new ketnoiAD($ketnoi);
		if($p->ketnoi($ketnoi)){
		if(isset($_GET['lsdh'])){
			$bangghimoitrang=!empty($_GET['per_page'])?$_GET['per_page']:4;
			$tranghientai=!empty($_GET['page'])?$_GET['page']:1;
			$start_from = ($tranghientai-1) * $bangghimoitrang;
			$sql="select distinct(tendonhang),tenkhac,ngaydat,tinhtrang,trangthai,sum(thanhtien) as tongtien, id_donhang from donhang 
			group by tendonhang,tenkhac,ngaydat,tinhtrang,trangthai, id_donhang
			limit $start_from,$bangghimoitrang";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
		}
	}
	else{
		echo "<script>alert('Không có')</script>";
	}
  }
  function sotrangcanthietls(){
			$bangghimoitrang=!empty($_GET['per_page'])?$_GET['per_page']:4;
			$tranghientai=!empty($_GET['page'])?$_GET['page']:1;
			$sql ="SELECT COUNT(distinct(tendonhang)) FROM donhang";
			$qr=mysql_query($sql); 
    		$cot = mysql_fetch_row($qr);  
    		$tongbangghi = $cot[0];  
   		    $tongsotrang = ceil($tongbangghi / $bangghimoitrang); 
			include_once("Controller/cPagels.php");
			return $tongsotrang;
	}
	function soluongkhachdatmua(){
		$p=new ketnoiAD($ketnoi);
		if($p->ketnoi($ketnoi)){
		if(isset($_GET['lsdh'])){
			$sql="select count(distinct tenkhachhang) as sl from donhang";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
		}
	}
	else{
		echo "<script>alert('Không có')</script>";
	    }
	}
	
	//Hủy đơn hàng theo yêu cầu khách hàng
	function huydonyeucau(){
		$p=new ketnoiAD($ketnoi);
		if($p->ketnoi($ketnoi)){
			if(isset($_GET['huydh'])){
				$iddh=$_GET['iddh'];
				$sql="delete from donhang where id_donhang='$iddh'";
				$qr=mysql_query($sql);
				return $qr;
			}
		}
	}
	
	//Chi tiết đơn hàng
	function ctdhang(){
		$p=new ketnoiAD($ketnoi);
		if($p->ketnoi($ketnoi)){
		if(isset($_GET['ctdh'])){
			$tdh=$_GET['ctdh'];
			$sql="select * from donhang where tendonhang='$tdh'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
		}
	}
	else{
		echo "<script>alert('Không có')</script>";
	    }
		
	}
	function dhanghn(){
		$p=new ketnoiAD($ketnoi);
		if($p->ketnoi($ketnoi)){
			$sql="select distinct(tendonhang),tenkhac,ngaydat,tinhtrang,trangthai,sum(thanhtien) as tongtien from donhang 
			where date(now())-date(ngaydat)= 0
			group by tendonhang,tenkhac,ngaydat,tinhtrang,trangthai
			";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
		}
	else{
		echo "<script>alert('Không có')</script>";
	    }
		
	}
	function dhanghq(){
		$p=new ketnoiAD($ketnoi);
		if($p->ketnoi($ketnoi)){
			$sql="select distinct(tendonhang),tenkhac,ngaydat,tinhtrang,trangthai,sum(thanhtien) as tongtien from donhang 
			where date(now())-date(ngaydat)= 1
			group by tendonhang,tenkhac,ngaydat,tinhtrang,trangthai
			";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
		}
	else{
		echo "<script>alert('Không có')</script>";
	    }
		
	}
	function dhangtq(){
		$p=new ketnoiAD($ketnoi);
		if($p->ketnoi($ketnoi)){
			$sql="select distinct(tendonhang),tenkhac,ngaydat,tinhtrang,trangthai,sum(thanhtien) as tongtien from donhang 
			where date(now())-date(ngaydat)= 7
			group by tendonhang,tenkhac,ngaydat,tinhtrang,trangthai
			";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
		}
	else{
		echo "<script>alert('Không có')</script>";
	    }
		
	}
	//Trạng thái nút
	function trangthai1(){
		$p=new ketnoiAD($ketnoi);
		if($p->ketnoi($ketnoi)){
			if(isset($_GET['xn'])){
			$xn=$_GET['xn'];
			$sql="update donhang set trangthai=1 where tendonhang='$xn'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
		}
	else{
		echo "<script>alert('Không có')</script>";
	    }
		}
		
		
	}
	function trangthai2(){
		$p=new ketnoiAD($ketnoi);
		if($p->ketnoi($ketnoi)){
			if(isset($_GET['xn1'])){
			$xn1=$_GET['xn1'];
			$sql="update donhang set trangthai=2 where tendonhang='$xn1'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
		}
	else{
		echo "<script>alert('Không có')</script>";
	    }
		}
		
		
	}
	//Tải lên tài liệu
	function taitailieu(){
		$p=new ketnoiAD($ketnoi);
		if($p->ketnoi($ketnoi)){
		if(isset($_POST['submit'])&&isset($_GET['ttl'])){
			$ten=$_FILES['f']['name'];
			$sql="insert into tep(tentep) values ('$ten')";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
		}
	}
	else{
		echo "<script>alert('Không có')</script>";
	    }
		
	}
}


?>
</body>
</html>