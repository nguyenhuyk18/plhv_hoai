<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
include_once("ketnoiAD.php");
class mTKAD{
	


/*
C1:
function laytaikhoan(){
$p=new ketnoi($ketnoi);
if($p->ketnoi($ketnoi)){
	$sql="select *from taikhoan";
	$qr=mysql_query($sql);
	return $qr;
	$p->dongketnoi($ketnoi);
}
else{
	return false;
}
	}
*/
//Kiểm tra thông tin đăng nhập Khách Hàng

//Password Khach Hang(user 1),Nguoi Ban Hang (user 2),Admin (user 3),Shipper(user 4)
function taikhoanAD(){
	$p=new ketnoiAD($ketnoi);
	if($p->ketnoi($ketnoi)){
		if(isset($_POST['submit'])){
			$se=$_POST['se'];
			$mk=md5($_POST['pass']);
			$sql="select * from taikhoan where (SoDienThoai='$se' or Email='$se') && Password='$mk' && NguoiDung='3'";
			$qr=mysql_query($sql);
			return $qr;
		}
		else{
			echo "<script>alert('Không có submit')</script>";
		}
	}
	else{
		return false;
	}
}
function taikhoanQRAD(){
	$p=new ketnoiAD($ketnoi);
	if($p->ketnoi($ketnoi)){
		if(isset($_POST['dn'])){
			$ph=$_POST['Phone'];
			$e=$_POST['Email'];
			$p=$_POST['Pass'];
			$sql="select * from taikhoan where SoDienThoai='$ph' and Email='$e' and Password='$p' and NguoiDung='3'";
			$qr=mysql_query($sql);
			return $qr;
		}
		else{
			echo "<script>alert('Không có submit')</script>";
		}
	}
	else{
		return false;
	}
}
function quyenchucnang(){
	$p=new ketnoiAD($ketnoi);
	if($p->ketnoi($ketnoi)){
		if(isset($_GET['Ten'])){
			$ten=$_GET['Ten'];
			$sql="select * from taikhoan where Username='$ten'";
			$qr=mysql_query($sql);
			return $qr;
		}
		else{
			echo "<script>alert('Không có submit')</script>";
		}
	}
	else{
		return false;
	}
	
}
}
?>
</body>
</html>