<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
include_once("ketnoiKH.php");
class mCH{
	function XemCH(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$sql="select * from loai";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
		}
		else{
			return false;
		}
	}
	function laydanhmuctrangdiem(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$sql="select * from loai as l join loaichung as lc on l.id_loaichung=lc.id_loaichung where tenloaichung='Trang Điểm'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
		}
		else{
			return false;
		}
	}
		function chamsocda(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$sql="select * from loai as l join loaichung as lc on l.id_loaichung=lc.id_loaichung where tenloaichung='Chăm Sóc Da'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
		}
		else{
			return false;
		}
	}
		function chamsoctoc(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$sql="select * from loai as l join loaichung as lc on l.id_loaichung=lc.id_loaichung where tenloaichung='Chăm Sóc Tóc'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
		}
		else{
			return false;
		}
	}
		function phukien(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$sql="select * from loai as l join loaichung as lc on l.id_loaichung=lc.id_loaichung where tenloaichung='Phụ Kiện'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
		}
		else{
			return false;
		}
	}
		function nuochoa(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$sql="select * from loai as l join loaichung as lc on l.id_loaichung=lc.id_loaichung where tenloaichung='Nước Hoa'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
		}
		else{
			return false;
		}
	}
}


?>
</body>
</html>