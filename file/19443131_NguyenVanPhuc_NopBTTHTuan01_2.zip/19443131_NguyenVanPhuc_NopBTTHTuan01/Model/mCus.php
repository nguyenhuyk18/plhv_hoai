<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
include_once("ketnoiAD.php");
class mKH{
//Xem nhà cung cấp theo lưới
	function xemKH(){
			$p=new ketnoiAD($ketnoi);
			if($p->ketnoi($ketnoi)){
				if(isset($_GET['qlkh'])){
					$bangghimoitrang=!empty($_GET['per_page'])?$_GET['per_page']:5;
					$tranghientai=!empty($_GET['page'])?$_GET['page']:1;
					$start_from = ($tranghientai-1) * $bangghimoitrang;
					$sql="select *from taikhoan limit $start_from,$bangghimoitrang";
					$qr=mysql_query($sql);
					return $qr;
					$p->dongketnoi($ketnoi);
					
				}
				else{
					echo "<script>alert('Không có')</script>";
				}
			}
			else{
				return false;
}
}
	function sotrangcanthietKH(){
			$bangghimoitrang=!empty($_GET['per_page'])?$_GET['per_page']:5;
			$tranghientai=!empty($_GET['page'])?$_GET['page']:1;
			$sql ="SELECT COUNT(id_TK) FROM taikhoan";
			$qr=mysql_query($sql); 
    		$cot = mysql_fetch_row($qr);  
    		$tongbangghi = $cot[0];  
   		    $tongsotrang = ceil($tongbangghi / $bangghimoitrang); 
			include_once("Controller/cPageCus.php");
			return $tongsotrang;
	}
//Xóa khách hàng có email hoặc số điện thoại bị trùng lặp
	 function xoaKH(){
		 $p=new ketnoiAD($ketnoi);
			if($p->ketnoi($ketnoi)){
				if(isset($_GET['delkh'])){
					$id=$_GET['delkh'];
					$sql="delete from taikhoan where id_TK='$id'";
					$qr=mysql_query($sql);
					return $qr;
				}
				
			}
		 
	 }
	 //Gửi câu hõi hỗ trợ
	 function chph(){
		 $p=new ketnoiAD($ketnoi);
			if($p->ketnoi($ketnoi)){
				if(isset($_POST['ch'])){
					$chs=$_POST['chs'];
					$id=$_POST['id'];
					$sql="insert into hotro(cauhoi,id_TK,ngayguicauhoi) values ('$chs','$id',now())";
					$qr=mysql_query($sql);
					return $qr;
				}
				
			}
	 }
	 function hienchph(){
		  $p=new ketnoiAD($ketnoi);
			if($p->ketnoi($ketnoi)){
				$ten=$_GET['Ten'];
				$sql="select *from hotro ht join taikhoan tk on ht.id_TK=tk.id_TK where 
				Username='$ten'";
				$qr=mysql_query($sql);
				return $qr;
				
			}
	 }
	 }
?>
</body>
</html>