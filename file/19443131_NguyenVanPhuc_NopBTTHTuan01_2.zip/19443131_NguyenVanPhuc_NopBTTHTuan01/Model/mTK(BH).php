<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
include_once("ketnoiBH.php");
class mTKBH{
	


/*
C1:
function laytaikhoan(){
$p=new ketnoi($ketnoi);
if($p->ketnoi($ketnoi)){
	$sql="select *from taikhoan";
	$qr=mysql_query($sql);
	return $qr;
	$p->dongketnoi($ketnoi);
}
else{
	return false;
}
	}
*/
//Kiểm tra thông tin đăng nhập Khách Hàng

//Password Khach Hang(user 1),Nguoi Ban Hang (user 2),Admin (user 3),Shipper(user 4)
function taikhoanBH(){
	$p=new ketnoiBH($ketnoi);
	if($p->ketnoi($ketnoi)){
		if(isset($_POST['submit'])){
			$se=$_POST['se'];
			$mk=md5($_POST['pass']);
			$sql="select * from taikhoan where (SoDienThoai='$se' or Email='$se') && Password='$mk' && NguoiDung='2'";
			$qr=mysql_query($sql);
			return $qr;
		}
		else{
			echo "<script>alert('Không có submit')</script>";
		}
	}
	else{
		return false;
	}
}
function taikhoanQRBH(){
	$p=new ketnoiBH($ketnoi);
	if($p->ketnoi($ketnoi)){
		if(isset($_POST['dn'])){
			$ph=$_POST['Phone'];
			$e=$_POST['Email'];
			$p=$_POST['Pass'];
			$sql="select * from taikhoan where SoDienThoai='$ph' and Email='$e' and Password='$p' and NguoiDung='2'";
			$qr=mysql_query($sql);
			return $qr;
		}
		else{
			echo "<script>alert('Không có submit')</script>";
		}
	}
	else{
		return false;
	}
}
function xuatchht(){
	$p=new ketnoiBH($ketnoi);
	if($p->ketnoi($ketnoi)){
		$sql="select * from hotro ht join taikhoan tk on ht.id_TK=tk.id_TK";
		$qr=mysql_query($sql);
		return $qr;
	}
	
}
function id(){
	$p=new ketnoiBH($ketnoi);
	if($p->ketnoi($ketnoi)){
		$ten=$_GET['Ten'];
		$sql="select * from taikhoan where Username='$ten'";
		$qr=mysql_query($sql);
		return $qr;
	}
	
}
function tlht(){
	$p=new ketnoiBH($ketnoi);
	if($p->ketnoi($ketnoi)){
		if(isset($_POST['submit'])){
			$ph=$_POST['ph'];
			$id=$_POST['id'];
			$anh=$_POST['anh'];
			$ten=$_POST['ten'];
			$idkh=$_POST['idkh'];
			$idht=$_POST['idht'];
			$sql="update hotro set phanhoi='$ph', id_nvphanhoi='$id' , anhnv='$anh' , tennv='$ten' ,ngayphanhoi= now() where id_TK='$idkh' and id_hotro='$idht'";
			$qr=mysql_query($sql);
			return $qr;
		}
	}
	
}
function suatlht(){
	$p=new ketnoiBH($ketnoi);
	if($p->ketnoi($ketnoi)){
		if(isset($_POST['sua'])){
			$ph=$_POST['phi'];
			$id=$_POST['id'];
			$idkh=$_POST['idkh'];
			$idht=$_POST['idht'];
			$sql="update hotro set phanhoi='$ph', id_nvphanhoi='$id' where id_TK='$idkh' and id_hotro='$idht'";
			$qr=mysql_query($sql);
			return $qr;
		}
	}
	
}

function idaa(){
	$p=new ketnoiBH($ketnoi);
	if($p->ketnoi($ketnoi)){
			$TenDT=$_GET['TenDT'];
			$sql="select * from donhang dh join dienthoai dt on dt.tendt=dh.tendt where dt.tendt='$TenDT'";
			$qr=mysql_query($sql);
			return $qr;
	}
}

function thembl(){
	$p=new ketnoiBH($ketnoi);
	if($p->ketnoi($ketnoi)){
			$f=$_GET['f'];
			$id=$_GET['id'];
			$ten=$_GET['Ten'];
			$tendt=$_GET['TenDT'];
			$anh=$_GET['anh'];
			$sao=$_GET['sao'];
			$nd=$_GET['text'];
			$sl=$_GET['Soluong'];
			$sql="insert binhluan(noidungbinhluan, tendt , anhthucte,  tenkhachhang, anh , sosao, id_mypham ,ngaybinhluan, soluong ) values ('$nd', '$tendt' , '$f', '$ten','$anh','$sao','$id' , now() , '$sl')";
			$qr=mysql_query($sql);
			return $qr;
	}
}

function updg(){
	$p=new ketnoiBH($ketnoi);
	if($p->ketnoi($ketnoi)){
		$TenDT=$_GET['TenDT'];
		$Ten=$_GET['Ten'];
		$sao=$_GET['sao'];
		$nd=$_GET['text'];
		$f=$_GET['f'];
		$sql="update binhluan set sosao='$sao' , noidungbinhluan='$nd' , anhthucte='$f'  where tenkhachhang='$Ten' and tenmypham='$TenDT' ";
		$qr=mysql_query($sql);
		return $qr;
	}
}
function check(){
	$p=new ketnoiBH($ketnoi);
	if($p->ketnoi($ketnoi)){
		$TenDT=$_GET['TenDT'];
		$Ten=$_GET['Ten'];
		$sql="select * from binhluan where tenkhachhang='$Ten' and tenmypham='$TenDT'";
		$qr=mysql_query($sql);
		return $qr;
	}
}

function sosaosp(){
	$p=new ketnoiBH($ketnoi);
	if($p->ketnoi($ketnoi)){
		$id=$_GET['id'];
		$sql="select avg(sosao) as sosao from binhluan where id_mypham='$id'";
		$qr=mysql_query($sql);
		return $qr;
	}
}

function songuoibl(){
		  $p=new ketnoi($ketnoi);
			if($p->ketnoi($ketnoi)){
				if(isset($_GET['id'])){
				$id=$_GET['id'];
				$sql="select count(id_binhluan) as snbl from binhluan where id_mypham='$id' ";
				$qr=mysql_query($sql);
				return $qr;
				}
			}
	  }

function xuatbl(){
	$p=new ketnoi($ketnoi);
			if($p->ketnoi($ketnoi)){
				$id=$_GET['id'];
				$sql="select * from binhluan where id_mypham='$id' ";
				$qr=mysql_query($sql);
				return $qr;
				}
			
	
}

function tym(){
	$p=new ketnoiBH($ketnoi);
			if($p->ketnoi($ketnoi)){
				if(isset($_GET['tym'])){
				$id=$_GET['idbl'];
				$sql="update binhluan set luotyeuthich=luotyeuthich+1 where id_binhluan='$id'";
				$qr=mysql_query($sql);
				return $qr;
				}
			}
			
}

function xembinhluan(){
	$p=new ketnoiBH($ketnoi);
			if($p->ketnoi($ketnoi)){
				$sql="select *from binhluan";
				$qr=mysql_query($sql);
				return $qr;
			}
	
}
function phanhoibl(){
	$p=new ketnoiBH($ketnoi);
			if($p->ketnoi($ketnoi)){
				if(isset($_POST['guibl'])){
				$id=$_POST['idbl'];
				$nd=$_POST['ph'];
				$sql="update binhluan set picCH='dtt.jpg' , tenCH='Shop Mỹ Phẩm ViPu' , phanhoi='$nd' , ngayphanhoi=now() where id_binhluan='$id' ";
				$qr=mysql_query($sql);
				return $qr;
				}
			}
	
}
function suabl(){
	$p=new ketnoiBH($ketnoi);
			if($p->ketnoi($ketnoi)){
				if(isset($_POST['OK'])){
				$id=$_POST['idbl'];
				$phl=$_POST['phl'];
				$sql="update binhluan set phanhoi='$phl' where id_binhluan='$id'";
				$qr=mysql_query($sql);
				return $qr;
				}
			}
}
//Thêm sao điện thoại
/*function upsao(){
	$p=new ketnoiBH($ketnoi);
	if($p->ketnoi($ketnoi)){
		$sao=$_GET['sao'];
		$id=$_GET['id'];
		$sql="update dienthoai set sao='$sao' where id_dt='$id'";
		$qr=mysql_query($sql);
		return $qr;
	}
	
}
*/
	
//Shipper vận chuyển

function taikhoanShip(){
	$p=new ketnoiBH($ketnoi);
	if($p->ketnoi($ketnoi)){
		if(isset($_POST['submit'])){
			$se=$_POST['se'];
			$mk=md5($_POST['pass']);
			$sql="select * from taikhoan where (SoDienThoai='$se' or Email='$se') && Password='$mk' && NguoiDung='4'";
			$qr=mysql_query($sql);
			return $qr;
		}
		else{
			echo "<script>alert('Không có submit')</script>";
		}
	}
	else{
		return false;
	}
}

function taikhoanQRShip(){
	$p=new ketnoiBH($ketnoi);
	if($p->ketnoi($ketnoi)){
		if(isset($_POST['dn'])){
			$ph=$_POST['Phone'];
			$e=$_POST['Email'];
			$p=$_POST['Pass'];
			$sql="select * from taikhoan where SoDienThoai='$ph' and Email='$e' and Password='$p' and NguoiDung='4'";
			$qr=mysql_query($sql);
			return $qr;
		}
		else{
			echo "<script>alert('Không có submit')</script>";
		}
	}
	else{
		return false;
	}
}

function infoShip(){
	$p=new ketnoiBH($ketnoi);
	if($p->ketnoi($ketnoi)){
		$ten=$_GET['Ten'];
		$sql="select * from taikhoan where Username='$ten' ";
		$qr=mysql_query($sql);
		return $qr;
	}
}

function xemdhang(){
	$p=new ketnoiBH($ketnoi);
	if($p->ketnoi($ketnoi)){
		$ten=$_GET['Ten'];
		$sql="select distinct(tendonhang) , tinhtrang, trangthai,tenkhac from donhang where trangthai=2 or trangthai=3 or trangthai=4 ";
		$qr=mysql_query($sql);
		return $qr;
	}
}

function xemdhct(){
	$p=new ketnoiBH($ketnoi);
	if($p->ketnoi($ketnoi)){
		$tendonhang=$_GET['tendonhang'];
		$sql="select * from donhang where tendonhang='$tendonhang' ";
		$qr=mysql_query($sql);
		return $qr;
	}
	
}

function tongtien(){
	$p=new ketnoiBH($ketnoi);
	if($p->ketnoi($ketnoi)){
		$tendonhang=$_GET['tendonhang'];
		$sql="select sum(thanhtien) as tongtien from donhang where tendonhang='$tendonhang' ";
		$qr=mysql_query($sql);
		return $qr;
	}
	
}

function tiepnhangiaohang(){
		$p=new ketnoiBH($ketnoi);
		if($p->ketnoi($ketnoi)){
			if(isset($_GET['tiepnhan'])){
				$tendonhang=$_GET['tendonhang'];
				$sql="update donhang set trangthai=3 where tendonhang='$tendonhang' ";
				$qr=mysql_query($sql);
				return $qr;
			}
	}
}

function xuatdonhangthutien(){
	$p=new ketnoiBH($ketnoi);
		if($p->ketnoi($ketnoi)){
				$sql="select distinct(tendonhang),tenkhac , sum(thanhtien) as tongtien from donhang  
				where trangthai=3 and tinhtrang=0 group by tendonhang, tenkhac";
				$qr=mysql_query($sql);
				return $qr;
			
	}
}

function them(){
	$p=new ketnoiBH($ketnoi);
		if($p->ketnoi($ketnoi)){
			$tendonhang=$_GET['tendonhang'];
			$tenkhachhang=$_GET['tenkhac'];
			$sotientra=$_GET['sotientra'];
			$tongtienthu=$_GET['tongtienthu'];
			$sql="insert into hoadon(tenhoadon,tendonhang,tenkhachhang,tongtienthu,sotienthu , ngaythu)
			value('$tendonhang','$tendonhang','$tenkhachhang','$tongtienthu','$sotientra', now()) ";
			$qr=mysql_query($sql);
			return $qr;
		}
	
}

function sua(){
	$p=new ketnoiBH($ketnoi);
		if($p->ketnoi($ketnoi)){
			$sql="update hoadon set congno=tongtienthu-sotienthu where ngaythu= now() ";
			$qr=mysql_query($sql);
			return $qr;
		}
}
function sua1(){
	$p=new ketnoiBH($ketnoi);
		if($p->ketnoi($ketnoi)){
			$tendonhang=$_GET['tendonhang'];
			$sql="update donhang set tinhtrang=1 where tendonhang='$tendonhang' ";
			$qr=mysql_query($sql);
			return $qr;
		}
}
function hoantatgiaohang(){
	$p=new ketnoiBH($ketnoi);
		if($p->ketnoi($ketnoi)){
			$tendonhang=$_GET['tendonhang'];
			$sql="update donhang set trangthai=4 where tendonhang='$tendonhang' ";
			$qr=mysql_query($sql);
			return $qr;
		}
	
}
	  
}
?>
</body>
</html>