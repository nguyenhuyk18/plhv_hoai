<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
include_once("ketnoiKH.php");
class mSP{
	//Xem sản phẩm
	function XemSP(){
		$p=new ketnoi($ketnoi);
		$p->ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$bangghimoitrang=!empty($_GET['per_page'])?$_GET['per_page']:8;
			$tranghientai=!empty($_GET['page'])?$_GET['page']:1;
			$start_from = ($tranghientai-1) * $bangghimoitrang;
			$sql="select * from mypham limit $start_from,$bangghimoitrang";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
		
	}
	function sotrangcanthiet(){
			$bangghimoitrang=!empty($_GET['per_page'])?$_GET['per_page']:8;
			$tranghientai=!empty($_GET['page'])?$_GET['page']:1;
			$sql ="SELECT COUNT(id_mypham) FROM mypham";
			$qr=mysql_query($sql); 
    		$cot = mysql_fetch_row($qr);  
    		$tongbangghi = $cot[0];  
   		    $tongsotrang = ceil($tongbangghi / $bangghimoitrang); 
			include_once("Controller/cPage.php");
			return $tongsotrang;
	}
	//Xem sản phẩm khuyến mãi
	function XemSPKM(){
		$p=new ketnoi($ketnoi);
		$p->ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$start_from = ($tranghientai-1) * $bangghimoitrang;
			$sql="select *from mypham where giamgia>0";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
		
	}
	//Xem sản phẩm mới nhất
	function XemSPMN(){
		$p=new ketnoi($ketnoi);
		$p->ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$start_from = ($tranghientai-1) * $bangghimoitrang;
			$sql="select *from mypham where date(now())-date(thoidiemramat) < 10 ";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
		
	}
	//Xem sản phẩm theo thương hiệu
	function XemSPTheoTen(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$ten=$_GET['id_nhacungcap'];
			$bangghimoitrang=!empty($_GET['per_page'])?$_GET['per_page']:6;
			$tranghientai=!empty($_GET['page'])?$_GET['page']:1;
			$start_from = ($tranghientai-1) * $bangghimoitrang;
			$sql="select *from dienthoai where id_nhacungcap='$ten' limit $start_from,$bangghimoitrang";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
	}
	function sotrangcanthietten(){
			$ten=$_GET['id_nhacungcap'];
			$bangghimoitrang=!empty($_GET['per_page'])?$_GET['per_page']:6;
			$tranghientai=!empty($_GET['page'])?$_GET['page']:1;
			$sql ="SELECT COUNT(id_dt) FROM dienthoai where id_nhacungcap='$ten'";
			$qr=mysql_query($sql);  
    		$row =mysql_fetch_row($qr);  
			$tongbangghi=$row[0];
   		    $tongsotrang = ceil($tongbangghi / $bangghimoitrang); 
			include_once("Controller/cPageCT.php");
			return $tongsotrang;
		
	}
	//Chi tiết sản phẩm
	function chitiet(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$id=$_GET['id'];
			$sql="select * from mypham where id_mypham=$id";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
	}
	function chitietSaPham(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			if(isset($_GET['id'])){
				$idsp=$_GET['id'];
			$sql="select *from mypham mp join thuonghieu th on mp.id_thuonghieu=th.id_thuonghieu where id_mypham='$idsp'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			}
		}
		else{
			return false;
		}
	}
	//Tìm kiếm
	function TimKiemTheoTen(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$tk=$_GET['s'];
			$bangghimoitrang=!empty($_GET['per_page'])?$_GET['per_page']:6;
			$tranghientai=!empty($_GET['page'])?$_GET['page']:1;
			$start_from = ($tranghientai-1) * $bangghimoitrang;
			$sql="select * from mypham where tenmypham like '%$tk%' limit $start_from,$bangghimoitrang";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
	}
	function sotrangcanthiettk(){
			$tk=$_GET['s'];
			$bangghimoitrang=!empty($_GET['per_page'])?$_GET['per_page']:6;
			$tranghientai=!empty($_GET['page'])?$_GET['page']:1;
			$sql ="SELECT COUNT(id_mypham) FROM mypham where tenmypham like '%$tk%'";
			$qr=mysql_query($sql);  
    		$row =mysql_fetch_row($qr);  
			$tongbangghi=$row[0];
   		    $tongsotrang = ceil($tongbangghi / $bangghimoitrang); 
			include_once("Controller/cPageTimkiem.php");
			return $tongsotrang;
		
	}
	//Tìm kiếm giọng nói
	function TimKiemTheoTenVoice(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
				if(isset($_GET['gt'])){
					$tk=$_GET['gt'];
			$bangghimoitrang=!empty($_GET['per_page'])?$_GET['per_page']:6;
			$tranghientai=!empty($_GET['page'])?$_GET['page']:1;
			$start_from = ($tranghientai-1) * $bangghimoitrang;
			$sql="select * from mypham where tenmypham like '%$tk%' limit $start_from,$bangghimoitrang";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
	
		}
		}
		else{
			return false;
		}
	}
	function sotrangcanthiettkVoice(){
			if(isset($_GET['abc'])){
					$tk=$_GET['gt'];
			$bangghimoitrang=!empty($_GET['per_page'])?$_GET['per_page']:6;
			$tranghientai=!empty($_GET['page'])?$_GET['page']:1;
			$sql ="SELECT COUNT(id_mypham) FROM mypham where tenmypham like '%$tk%'";
			$qr=mysql_query($sql);  
    		$row =mysql_fetch_row($qr);  
			$tongbangghi=$row[0];
   		    $tongsotrang = ceil($tongbangghi / $bangghimoitrang); 
			include_once("Controller/cPageTimkiemVoice.php");
			return $tongsotrang;
			}
		
	}
	//Lọc
	function locSP(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$loc=$_GET['loc'];
			$bangghimoitrang=!empty($_GET['per_page'])?$_GET['per_page']:6;
			$tranghientai=!empty($_GET['page'])?$_GET['page']:1;
			$start_from = ($tranghientai-1) * $bangghimoitrang;
			$sql="select * from dienthoai dt where id_loai='$loc' limit $start_from,$bangghimoitrang";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
}
	function sotrangcanthietloc(){
			$loc=$_GET['loc'];
			$bangghimoitrang=!empty($_GET['per_page'])?$_GET['per_page']:6;
			$tranghientai=!empty($_GET['page'])?$_GET['page']:1;
			$sql ="SELECT COUNT(id_dt) FROM dienthoai where id_loai='$loc'";
			$qr=mysql_query($sql);  
    		$row =mysql_fetch_row($qr);  
			$tongbangghi=$row[0];
   		    $tongsotrang = ceil($tongbangghi / $bangghimoitrang); 
			include_once("Controller/cPageLoc.php");
			return $tongsotrang;
		
	}
	//Lọc sản phẩm theo giá và hệ điều hành
	function locSPGia(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
		if(isset($_GET['loc'])&&isset($_GET['mingia'])&&isset($_GET['maxgia'])){
			if($_GET['loc']!=null){
			$loc1=$_GET['loc'];
			$a=$_GET['mingia'];
			$b=$_GET['maxgia'];
			$bangghimoitrang=!empty($_GET['per_page'])?$_GET['per_page']:6;
			$tranghientai=!empty($_GET['page'])?$_GET['page']:1;
			$start_from = ($tranghientai-1) * $bangghimoitrang;
			$sql="select * from dienthoai dt where (id_loai='$loc1' and (gia-(gia*giamgia*0.01))> '$a'
			and (gia-(gia*giamgia*0.01))< '$b' ) limit $start_from,$bangghimoitrang";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			}
			else{
				$a=$_GET['mingia'];
				$b=$_GET['maxgia'];
				$bangghimoitrang=!empty($_GET['per_page'])?$_GET['per_page']:6;
				$tranghientai=!empty($_GET['page'])?$_GET['page']:1;
				$start_from = ($tranghientai-1) * $bangghimoitrang;
				$sql="select * from dienthoai dt where ((gia-(gia*giamgia*0.01))> '$a'
				and (gia-(gia*giamgia*0.01))< '$b' ) limit $start_from,$bangghimoitrang";
				$qr=mysql_query($sql);
				return $qr;
				$p->dongketnoi($ketnoi);
			}
			
		}
		}
		else{
			return false;
		}
}
	function sotrangcanthietlocGia(){
		if(isset($_GET['loc'])&&isset($_GET['mingia'])&&isset($_GET['maxgia'])){
			if($_GET['loc']!=null){
			$loc1=$_GET['loc'];
			$a=$_GET['mingia'];
			$b=$_GET['maxgia'];
			$bangghimoitrang=!empty($_GET['per_page'])?$_GET['per_page']:6;
			$tranghientai=!empty($_GET['page'])?$_GET['page']:1;
			$sql ="SELECT COUNT(id_dt) FROM dienthoai where (id_loai='$loc1' and (gia-(gia*giamgia*0.01))> '$a'
			and (gia-(gia*giamgia*0.01))< '$b' ) ";
			$qr=mysql_query($sql);  
    		$row =mysql_fetch_row($qr);  
			$tongbangghi=$row[0];
   		    $tongsotrang = ceil($tongbangghi / $bangghimoitrang); 
			include_once("Controller/cPageLoc1.php");
			return $tongsotrang;
			}
			else{
			$a=$_GET['mingia'];
			$b=$_GET['maxgia'];
			$bangghimoitrang=!empty($_GET['per_page'])?$_GET['per_page']:6;
			$tranghientai=!empty($_GET['page'])?$_GET['page']:1;
			$sql ="SELECT COUNT(id_dt) FROM dienthoai where ((gia-(gia*giamgia*0.01))> '$a'
			and (gia-(gia*giamgia*0.01))< '$b' ) ";
			$qr=mysql_query($sql);  
    		$row =mysql_fetch_row($qr);  
			$tongbangghi=$row[0];
   		    $tongsotrang = ceil($tongbangghi / $bangghimoitrang); 
			include_once("Controller/cPageLoc2.php");
			return $tongsotrang;
			}
		}
		
	}
	//Giỏ hàng
	function ThemSPvaoCSDL(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$tgh=$_GET['themgiohang'];
			$id_KH=$_GET['id_KH'];
			$sql="insert into giohang(tenmypham,anhurl,anh,gia,giamgia,id_mypham,NgayThemGioHang) select tenmypham,anhurl,anh,gia,giamgia,id_mypham,now() from mypham
			where id_mypham='$tgh' and mypham.id_mypham not in(select id_mypham from giohang where id_taikhoan='$id_KH')";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
	}
	function UpGH(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$id_KH=$_GET['id_KH'];
			$sql="update giohang set id_taikhoan='$id_KH' where NgayThemGioHang=now() ";
			$qr=mysql_query($sql);
			return $qr;
		}
	}
	function Xemgiohang(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$id_KH=$_GET['id_KH'];
			$sql="select * from giohang where id_taikhoan='$id_KH'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
	}
	function Xemgiohangvd(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$ten=$_GET['Ten'];
			$sql="select * from giohang where id_taikhoan='$ten'";
			$qr=mysql_query($sql);
			return $qr;
			
		}
		else{
			return false;
		}
		
	}
	function luongton(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$id_KH=$_GET['id_KH'];
			$sql="select * from mypham mp join giohang gh on mp.id_mypham=gh.id_mypham where id_taikhoan='$id_KH'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
		
	}
	function luongtonvd(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$id=$_GET['Ten'];
			$sql="select * from mypham mp join giohang gh on mp.id_mypham=gh.id_mypham where id_taikhoan='$id'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
		
	}
	function suasl(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$sl=$_GET['sl'];
			$id=$_GET['id'];
			$sql="update giohang set soluong='$sl' where id_giohang='$id'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
		
		
	}
	function Capnhatthanhtien(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$sl=$_GET['sl'];
			$id=$_GET['id'];
			$sql="update giohang set thanhtien=(gia-gia*(giamgia/100))*$sl where id_giohang='$id'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
	}
	function upthanhtien(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$id=$_GET['themgiohang'];
			$sql="update giohang set thanhtien=gia-gia*(giamgia/100) where id_mypham='$id'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
	}
	function Tongtien(){
			$p=new ketnoi($ketnoi);
			if($p->ketnoi($ketnoi)){
				    $id=$_GET['id_KH'];
					$sql="select sum(thanhtien) as tongtien from giohang where id_taikhoan='$id'";
					$qr=mysql_query($sql);
					return $qr;
					$p->dongketnoi($ketnoi);
				
		}
		else{
			return false;
		}
	}
	function Tongtienvd(){
			$p=new ketnoi($ketnoi);
			if($p->ketnoi($ketnoi)){
				    $id=$_GET['Ten'];
					$sql="select sum(thanhtien) as tongtien from giohang where id_taikhoan='$id'";
					$qr=mysql_query($sql);
					return $qr;
					$p->dongketnoi($ketnoi);
				
		}
		else{
			return false;
		}
	}
	function xoaspgh(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$id=$_GET['ma'];
			$sql="delete from giohang where id_giohang='$id'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
		
	}
	function xoatatca(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$id_KH=$_GET['id_KH'];
			$sql="delete from giohang where id_taikhoan='$id_KH'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
	}
	function xoatatcavd(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$id=$_GET['id_KH'];
			$sql="delete from giohang where id_taikhoan='$id'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
	}
	function soluong(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$id=$_SESSION['id_KH'];
			$sql="select count(gh.id_giohang) as soluong from giohang gh join taikhoan tk on tk.id_TK=gh.id_taikhoan
			where tk.id_TK='$id'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
		
	}
	function soluongghvd(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$id=$_GET['Ten'];
			$sql="select count(id_giohang) as soluong from giohang where id_taikhoan='$id'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
		
	}
	
	//Đơn hàng
	function ChenCSDLDH(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$id=$_GET['id_KH'];
			$tdh=$_POST['tdh'];
			$sql="insert into donhang(tenmypham,anhurl,soluong,thanhtien,ngaydat,anh,id_giohang)
  					select tenmypham,anhurl,soluong,thanhtien,now(),anh,id_giohang from giohang
					where id_taikhoan='$id'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
		
	}
	function capnhatDH(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$tdh=$_POST['tdh'];
			$ten=$_GET['Ten'];
			$a=$_POST['a'];
			$b=$_POST['b'];
			$c=$_POST['c'];
			$d=$_POST['d'];
			$e=$_POST['e'];
			$f=$_POST['f'];
			$sql="update donhang set tendonhang='$tdh',tenkhachhang='$ten',
			tenkhac='$a',diachi='$b',email='$c',sdt='$d',ghichu='$e',phuongthucthanhtoan='$f'
		    where ngaydat=now()";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
		
	}
	function Xoagiohang(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$id=$_GET['id_KH'];
			$sql="delete from giohang where id_taikhoan='$id'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
		
	}
	function cntonkho(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			if(isset($_POST['dh'])){
			$id=$_GET['id_KH'];
			$sql="update mypham mp join
			giohang gh on mp.id_mypham=gh.id_mypham
			join taikhoan tk on tk.id_TK=gh.id_taikhoan
			set mp.tonkho=mp.tonkho-gh.soluong
			where gh.id_taikhoan='$id'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
		}
	}
	//Xuất ra đơn hàng
	function Xuatdh(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$id_KH=$_GET['id_KH'];
			$sql="select * from giohang where id_taikhoan='$id_KH' ";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
		
	}
	//Xuất ra đơn hàng gửi gmail
	function Xuatdh1(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$ten=$_GET['Ten'];
			if(isset($_POST['dh'])){
			$tendonhang=$_POST['tdh'];
			$sql="select * from donhang where tenkhachhang='$ten' and ngaydat=now() ";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
		}
		
	}
	function moneydh(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$ten=$_GET['Ten'];
			$sql="select sum(thanhtien) as tongtien from donhang where tenkhachhang='$ten' and ngaydat=now() ";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
		
	}
	//Xem đơn hàng //Kiểm tra nút khi hủy đơn 
	function df(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$ten=$_GET['Ten'];
			$sql="select DISTINCT ngaydat,tendonhang,trangthai,tinhtrang from donhang where tenkhachhang='$ten' ";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
		}
		else{
			return false;
		
		}
		
	}
	//Xem chi tiết sản phẩm trong đơn hàng
	function kg(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$ten=$_GET['Ten'];
			$tdh=$_GET['TenDH'];
			$sql="select * from donhang where tenkhachhang='$ten' and tendonhang='$tdh' ";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
		}
		else{
			return false;
		
		}
		
	}
	//Tổng tiền đơn hàng
	function kh(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$ten=$_GET['Ten'];
			$tdh=$_GET['TenDH'];
			$sql="select sum(thanhtien) as tongtien from donhang where tenkhachhang='$ten' and tendonhang='$tdh' ";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
		}
		else{
			return false;
		
		}
		
	}
	//Xe, sản phẩm trong giỏ hàng chưa mới nhấn nút mua hàng( khách vãng lai)
	function kiemnutvl(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$idkh=$_GET['Ten'];
			$sql="select count(id_giohang) as slhang from giohang where id_taikhoan='$idkh'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
		
	}
	
	//Xem có sản phẩm trong giỏ hàng chưa mới được nhấn nút mua hàng
	
	function kiemnut(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$idkh=$_GET['id_KH'];
			$sql="select count(id_giohang) as slhang from giohang where id_taikhoan='$idkh'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
		
	}
	
	//Xem file Upload
	function xemfile(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
			$sql="select *from tep";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		else{
			return false;
		}
		
	}
	// Xóa đơn hàng
	function huydh(){
		$p=new ketnoi($ketnoi);
		if($p->ketnoi($ketnoi)){
		 if(isset($_GET['Ten'])&&isset($_GET['huydon'])){
			$iddh=$_GET['huydon'];
			$sql="delete from donhang where tendonhang='$iddh'";
			$qr=mysql_query($sql);
			return $qr;
			$p->dongketnoi($ketnoi);
			
		}
		}
		else{
			return false;
		}
		
	}
	
	function Tongtiendh(){
			$p=new ketnoi($ketnoi);
			if($p->ketnoi($ketnoi)){
				    $id=$_GET['id_KH'];
					$sql="select sum(thanhtien) as tongtien from giohang where id_taikhoan='$id'";
					$qr=mysql_query($sql);
					return $qr;
					$p->dongketnoi($ketnoi);
				
		}
		else{
			return false;
		}
	}
	function ab(){
		  $p=new ketnoi($ketnoi);
			if($p->ketnoi($ketnoi)){
				 if(isset($_GET['Ten'])&&isset($_GET['danhan'])){
				$tendonhang=$_GET['TenDH'];
				$sql="update donhang set trangthai=5 where tendonhang='$tendonhang'";
				$qr=mysql_query($sql);
				return $qr;
			}
			}
	  }
	  function daban(){
		  $p=new ketnoi($ketnoi);
			if($p->ketnoi($ketnoi)){
				
				$id=$_GET['id'];
				$sql="select tonkhobandau-tonkho as daban from mypham where id_mypham='$id' ";
				$qr=mysql_query($sql);
				return $qr;
			
			}
	  }
	
}

?>
</body>
</html>