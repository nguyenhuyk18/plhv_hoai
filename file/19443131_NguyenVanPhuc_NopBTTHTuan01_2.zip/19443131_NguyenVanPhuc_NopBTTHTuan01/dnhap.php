<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" href="css/bootstrap.css" />
<script type="text/javascript" src="http://webquangnam.com/jsShare/hoa-mai-roi.js"></script>
<br />

<style>
	h3{
		color:#696;
		font-family:Verdana, Geneva, sans-serif;
	}
	
	n{
		color:#9F0;
	}
	
	th{
		background-color:#9C0;
	}
	
	nh{
		color:#FF0;
	}
</style>
</head>

<body
</div class="container h-600">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
         <div class="row">
         <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 border">
           <div class="row">
           <div class="col-sm-12">
           		<div class="row">
                	<div class="col-xs-2 col-sm-2 col-md-2 col-ld-2">
                    	<center><h3><n><img src="http://static.ybox.vn/2020/6/0/1593335906326-bh-advisor-dribbble.gif"
                         height="100px" width="150px"/></n></h3></center>
                    </div>
                    <div class="col-xs-10 col-sm-10 col-md-10 col-ld-10">
                    	<center><h3><n><img src="img/sach.jpg" height="100px" width="100%"/></n></h3></center>
                    </div>
                </div>
              </div>
         <p></p>
         </div>
         <div class="row">
         <div class="col-sm-3">
         </div>
         <div class="col-sm-6">
         <form action="dntc.php" method="post">
         <br />
         <table class="table table-bordered">
         	<thead>
            	<tr>
       <th colspan="2"><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<nh>Mời bạn đăng nhập</nh></h3></th>
          		<tr>
                <tr>
                	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Username:</td>
                    <td><center><input type="text" name="name"/></center></td>
                </tr>
                <tr>
                	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Password:</td>
                    <td><center><input type="password" name="pass"/></center></td>
                </tr>
                <tr>
                	<td colspan="2"><center><input type="submit" name="submit" value="Đăng nhập"/></center></td>
                </tr>
               </thead>
           </table>
        </div>
        <div class="col-sm-3">
        </div>
        </div>
        </div>
        
       </form>
        
    </div>

</body>
</html>