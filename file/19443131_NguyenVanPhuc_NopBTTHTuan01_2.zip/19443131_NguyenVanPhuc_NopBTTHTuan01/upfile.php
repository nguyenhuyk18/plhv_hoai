<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<?php
<?php
if (isset($_FILES['uploaded_file'])) {
    $target_directory = "uploads/";
    $file_name = $_FILES["uploaded_file"]["name"];
    $target_file = $target_directory . basename($file_name);
    $upload_ok = 1;
    $file_size = $_FILES["uploaded_file"]["size"];

    // 1. Kiểm tra kích thước tệp tin
    if ($file_size > 5000000) { // Giới hạn kích thước tệp tin (ví dụ: 5 MB)
        echo "Kích thước tệp tin quá lớn.";
        $upload_ok = 0;
    }

    // 2. Kiểm tra loại MIME của tệp tin
    $allowed_mime_types = array("image/jpeg", "image/png", "image/gif", "application/pdf", "application/msword");
    $file_type = mime_content_type($_FILES["uploaded_file"]["tmp_name"]);
    if (!in_array($file_type, $allowed_mime_types)) {
        echo "Loại tệp tin không được phép.";
        $upload_ok = 0;
    }

    // 3. Kiểm tra xem tệp tin đã tồn tại hay chưa
    if (file_exists($target_file)) {
        echo "Tệp tin đã tồn tại.";
        $upload_ok = 0;
    }

    // 4. Kiểm tra xem $upload_ok có bị lỗi không
    if ($upload_ok == 0) {
        echo "Không thể tải lên tệp tin.";
    } else {
        // 5. Tạo tên tệp tin mới để tránh ghi đè
        $file_name = uniqid() . "." . pathinfo($file_name, PATHINFO_EXTENSION);
        $target_file = $target_directory . $file_name;

        // 6. Di chuyển tệp tin từ thư mục tạm lên thư mục đích
        if (move_uploaded_file($_FILES["uploaded_file"]["tmp_name"], $target_file)) {
            echo "Tệp tin " . $file_name . " đã được tải lên thành công.";
        } else {
            echo "Có lỗi xảy ra khi tải lên tệp tin.";
        }
    }
}
?>

    <!DOCTYPE html>
<html>
<head>
    <title>Tải lên tệp tin</title>
</head>
<body>
    <h1>Tải lên tệp tin</h1>
    <form method="POST" enctype="multipart/form-data">
        <label>Chọn tệp tin để tải lên:</label>
        <input type="file" name="uploaded_file">
        <input type="submit" value="Tải lên">
    </form>
</body>
</html>
</body>
</html>
