<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script type="text/javascript" src="js/jquery.zoom.min.js"></script>

<script src="https://unpkg.com/js-image-zoom@0.4.1/js-image-zoom.js" type="application/javascript"></script>
<title>Untitled Document</title>
<style>
tk{
	color:#C99;
	font-family:"Comic Sans MS", cursive;
	font-size:25px;
	
}
ps{
	color:#F33;
	font-size:18px;
}
</style>
</head>
<body>
<center>
<div class="container h-600">
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 border">
    <div class="row">
                	<div class="col-xs-2 col-sm-2 col-md-2 col-ld-2">
                    	<center><h3><n><img src="img/logo.png"
                         height="200px" width="200px"/></n></h3></center>
                    </div>
                    <div class="col-xs-10 col-sm-10 col-md-10 col-ld-10">
                    	<center><h3><n><img src="img/bne.jpg" height="265px" width="100%"/></n></h3></center>
                    </div>           
                 </div>
    	<div class="row">
                 	<div class="col-xs-3 col-sm-3 col-md-3 col-ld-3">
                    	
                    </div>  
                    <div class="col-xs-6 col-sm-6 col-md-6 col-ld-6 border">
                    <br />
                    	<center><tk>Tìm tài khoản ? <img src="img/sic.png" height="35px" width="35px" /></tk></center>
                        <br />
                        <form action="ReOTP.php" method="post">
                    	<center><ps>Nhập Email:&nbsp;&nbsp;<input type="text" name="pe" /></ps></center>
                        <br />
                        <center><input type="submit" name="tim" value="Tìm" required="required"/></center>
                        <br />
                    </form>
                     
                    </div>  
                    
                    <div class="col-xs-3 col-sm-3 col-md-3 col-ld-3">
                    	
                    </div>  
</div>
<br />
                        <center><a href="SignIn.php"><img src="img/back.jpg" height="35px" width="35px" /></a></center>
                        <br />
<br />
   <div class="footer col-xs-12 col-sm-12 col-md-12 col-ld-12 border">
	<div class="row">
    	<div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        <p></p>
        	<center><img src="img/logo.png" height="100px" width="100px" /></center>
            <p> <nx>Về Chúng Tôi</nx> </p>
            <p> <nx>Giới thiệu:</nx><a href="#"> Nhà bán lẻ Mỹ Phẩm VIPU</a></p>
            <p> <nx>Số điện thoại:</nx> <a href="tel:0325927624">0325927624</a></p>
            <p> <nx>Email:</nx> <a href="mailto:phucable@gmail.com">phucable@gmail.com</a></p>
            <p> <nx>Địa chỉ: </nx><rf> ..., Phường xxx, Quận xxx, TP.HCM </rf> </p>
        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        ... ( Nội dung )
        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 col-ld-4">
        ... ( Nội dung )
        </div>
    </div>
    
</div>
                 
    </div>
</div>
</center>
</body>
</html>